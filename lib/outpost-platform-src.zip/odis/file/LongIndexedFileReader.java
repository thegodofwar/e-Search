package odis.file;

import java.io.EOFException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.logging.Logger;

import odis.file.IndexedFile.OffsetAndLength;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import odis.serialize.IWritableComparable;
import odis.serialize.WritableRegistry;
import odis.serialize.lib.LongWritable;
import toolbox.misc.ArrayUtils;
import toolbox.misc.ClassUtils;
import toolbox.misc.LogFormatter;

/**
 * The indexed-file-reader specially for long-keyed indexed file.
 * 
 * The keys are stored as a long[], thus many small objects are not created.
 * 
 * @author David
 *
 */
public class LongIndexedFileReader {
    protected static final Logger LOG = LogFormatter.getLogger(
            LongIndexedFileReader.class.getName());
    
    private IFileSystem fs;
    private Path file;
    private Path dataFile;
    private Path indexFile;
    private Class keyClass;
    private Class valClass;

    private int count = -1;
    private long[] keys;
    private long[] positions;
    private int[] lengths;
    
    private LinkedList<Cursor> freeCursors = new LinkedList<Cursor> ();
    private LinkedList<Cursor> activeCursors = new LinkedList<Cursor> ();
    
    private int maxCursorCount = 0;
    
    private boolean closed = false;
    private boolean compressed = false; 
    /**
     * The constructor.
     * @param fs  the file-system
     * @param file  the path
     * @throws IOException  if an I/O error occurs
     */
    public LongIndexedFileReader(IFileSystem fs, Path file) throws IOException {
        this(fs, file, 0);
    }
    /**
     * The constructor.
     * 
     * @param fs  the file-system instance  
     * @param file  the path to the indexed-file
     * @param maxCursorCount  the maximum cursor count
     * @throws IOException  if an I/O error occurs
     */
    public LongIndexedFileReader(IFileSystem fs, Path file, int maxCursorCount)
            throws IOException {
        this.fs = fs;
        this.file = file;
        this.maxCursorCount = maxCursorCount;

        dataFile = file.cat(IndexedFile.DATA_FILE_NAME);
        Path compressedFile = file.cat(IndexedFile.COMPRESSED_DATA_FILE_NAME);
        indexFile = file.cat(IndexedFile.INDEX_FILE_NAME);

        if (!fs.exists(dataFile) && fs.exists(compressedFile)) {
            dataFile = compressedFile;
            compressed = true;
        }
        SequenceFile.Reader dataFileReader = new SequenceFile.Reader(fs, 
                dataFile);
        try {
            keyClass = dataFileReader.getKeyClass();
            valClass = dataFileReader.getValueClass();
        } finally {
            dataFileReader.close();
        }

        loadIndex();
    }
    /**
     * Load index part of the indexed-file into memory
     * 
     * @throws IOException  if an I/O error occurs
     */
    private void loadIndex() throws IOException {
        this.count = 0;
        SequenceFile.Reader indexReader = new SequenceFile.Reader(fs, 
                indexFile);

        try {
            if (!LongWritable.class.isAssignableFrom(
                    indexReader.getKeyClass())) {
                throw new IOException("bad index file key class "
                        + indexReader.getKeyClass());
            } // if

            int fixedKeyLength = indexReader.getFixedKeyLength();

            long indexSize = fs.getLength(indexFile);

            int guessEntryCount = (int) (indexSize / (fixedKeyLength > 0 ? 
                    (fixedKeyLength + WritableRegistry.getWritableSize(
                            OffsetAndLength.class))
                    : (WritableRegistry.getWritableSize(
                            OffsetAndLength.class) + 4)));

            this.keys = new long[guessEntryCount];
            this.positions = new long[guessEntryCount];
            this.lengths = new int[guessEntryCount];

            OffsetAndLength offsetAndLength = new OffsetAndLength();
            while (true) {
                LongWritable k = (LongWritable) ClassUtils.newInstance(
                        indexReader.getKeyClass());

                if (!indexReader.next(k, offsetAndLength))
                    break;

                if (count == keys.length) { // time to grow arrays
                    int newLength = (keys.length * 3) / 2;
                    keys = (long[]) ArrayUtils.expand(keys, newLength);
                    positions = ArrayUtils.expand(positions, newLength);
                    lengths = ArrayUtils.expand(lengths, newLength);
                }

                keys[count] = k.get();
                positions[count] = offsetAndLength.getOffset();
                lengths[count] = offsetAndLength.getLength();
                count++;
            }

        } catch (EOFException e) {
            LOG.warning("Unexpected EOF reading " + indexReader
                    + " at entry #" + count + ".  Ignoring.");
        } finally {
            indexReader.close();
        }

    }

    public Class getValueClass() {
        return valClass;
    }

    /**
     * Open a cursor for read, the cursor must be released by calling 
     * {@link #closeCursor(Cursor)} or Cursor.close().
     * The cursor in internally reused, and all the cursor is acturally closed 
     * when {@link #close()} called.
     * 
     * @return cursor  the cursor to be opened
     * @throws IOException  if an I/O error occurs
     */
    public synchronized Cursor openCursor() throws IOException {
        while (!closed) {
            if (!freeCursors.isEmpty()) {
                Cursor cursor = freeCursors.removeFirst();
                cursor.active = true;
                activeCursors.addFirst(cursor);
                return cursor;
            }

            if (maxCursorCount <= 0 || freeCursors.size() + 
                    activeCursors.size() < maxCursorCount) {
                Cursor cursor = new Cursor();
                cursor.active = true;
                activeCursors.addFirst(cursor);
                return cursor;
            }

            try {
                wait(1000);
            } catch(InterruptedException e) {}
        }
        
        throw new IOException("cannot get cursor because the indexed file " 
                + file + " was closed");
    }
    /**
     * Close a cursor
     * 
     * @param cursor  the cursor to be closed
     */
    public synchronized void closeCursor(Cursor cursor) {
        activeCursors.remove(cursor);
        cursor.active = false;
        freeCursors.addFirst(cursor);
        notify();
    }
    /**
     * Close this reader. All cursors are closed as well.
     *
     */
    public synchronized void close() {
        for (Cursor cursor : activeCursors) {
            try {
                cursor.internalClose();
            } catch(IOException e) {
            }
        }
        
        for (Cursor cursor : freeCursors) {
            try {
                cursor.internalClose();
            } catch(IOException e) {
            }
        }
        
        activeCursors.clear();
        freeCursors.clear();
        
        closed = true;
    }
    /**
     * The data-structure for a cursor
     * 
     * @author David
     *
     */
    public class Cursor {
        
        private SequenceFile.Reader data;
        private LongWritable tmpKey;
        private int currentIndex = 0;
        private boolean atBeginOfData = false;
        private boolean active = false;
        
        private Cursor() throws IOException {
            data = new SequenceFile.Reader(fs, dataFile);
            tmpKey = (LongWritable) ClassUtils.newInstance(keyClass);
        }
        
        private void at(int index) throws IOException {
            currentIndex = index;
            data.seek(positions[currentIndex]);
            if (compressed)
                data.skip(lengths[currentIndex]);
            else
                atBeginOfData = true;
        }

        private int binarySearch(long key) {
            int low = 0;
            int high = count - 1;

            while (low <= high) {
                int mid = (low + high) >> 1;
                long midVal = keys[mid];

                if (midVal < key)
                    low = mid + 1;
                else if (midVal > key)
                    high = mid - 1;
                else
                    return mid; // key found
            }
            return -(low + 1); // key not found.
        }
        /**
         * Seek the current possition of the cursor according to a specified 
         * key.
         * 
         * @param key  the key to be seeked to
         * @return  true if the key is found (and seeked to), false otherwise
         * @throws IOException if an I/O error occurs
         */
        public synchronized boolean seek(long key) throws IOException {
            assert keys != null;
            
            if (!active) {
                throw new IOException("cursor is closed");
            }
            
            int index = binarySearch(key);

            boolean found = index >= 0;

            if (!found) {
                index = index * (-1) - 1;
            }

            if (index < count) {
                at(index);
            }

            return found;
        }
        /**
         * Read the current key-value (may be moved by {@link #seek(long)}), and
         * move the current position to next key-value.
         * 
         * @param key  the instance for storing the key
         * @param value  the instance for storing the value
         * @return  true if the key-value is read, false otherwise
         * @throws IOException  if the cursor has been closed or other I/O error
         *                      occurs
         */
        public synchronized boolean next(IWritableComparable key,
                IWritable value) throws IOException {
            assert keys != null;

            if (!active) {
                throw new IOException("cursor is closed");
            }
            
            if (atBeginOfData && !compressed) {
                data.nextKeyAndValue(key, value, lengths[currentIndex]);
                atBeginOfData = false;
                return true;
            } else {
                return data.next(key, value);
            }
            
        }
        /**
         * Seek to the possition of the key and read the value.
         * NOTE the input key instance does not change. 
         * 
         * @param key  the key instance for posititioning.
         * @param value  the value for storing value
         * @return  the key is found and succefully read, false otherwise.
         * @throws IOException  if the cursor has been closed or othe I/O error
         *                      occurs
         */
        public synchronized boolean get(LongWritable key, IWritable value)
        throws IOException {
            assert keys != null;
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return seek(key.get()) && next(tmpKey, value);
        }
        /**
         * Seek to the possition of the key and read the value.
         * 
         * @param key  the key instance for posititioning.
         * @param value  the value for storing value
         * @return  the key is found and succefully read, false otherwise.
         * @throws IOException  if the cursor has been closed or othe I/O error
         *                      occurs
         */
        public synchronized boolean get(long key, IWritable value)
        throws IOException {
            assert keys != null;
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return seek(key) && next(tmpKey, value);
        }
        
        /**
         * Seek to the possition of the key and read the key and value.
         * 
         * @param key  the key instance for posititioning
         * @param sotredKey  the key for storing key. It is read with value
         * @param value  the value for storing value
         * @return  the key is found and succefully read, false otherwise
         * @throws IOException  if the cursor has been closed or other I/O error
         *                      occurs
         */
        public synchronized boolean get(LongWritable key, 
                IWritableComparable storedKey, 
                IWritable value) throws IOException {
            assert keys != null;
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return seek(key.get()) && next(storedKey, value);
        }
        /**
         * @return  the current position in bytes
         * @throws IOException  if the cursor has been closed of other I/O error
         *                      occurs
         */
        public long getPos() throws IOException {
            if (!active) {
                throw new IOException("cursor is closed");
            }
            return data.getPos();
        }
        /**
         * Close the cursor.
         *
         */
        public void close() {
            if (!active) return;
            closeCursor(this);
        }
        
        private void internalClose() throws IOException {
            data.close();
        }
        
    }
}
