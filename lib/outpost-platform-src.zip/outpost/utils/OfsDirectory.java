package outpost.utils;

import java.io.IOException;

import odis.io.FSDataInputStream;
import odis.io.FileInfo;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.io.IFileSystem.PathFilter;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.Lock;

/**
 * 
 * A lucene Directory which support reading from odis IFileSystem directly. 
 * 
 * @author why, David
 * 
 * @since 2007-03-25
 */
public class OfsDirectory extends Directory {

    private IFileSystem fs;
    private Path dir;
   
    /**
     * The constructor.
     * 
     * @param fs  the file-system
     * @param dir  the path to the data at the specified file-system
     */
    public OfsDirectory(IFileSystem fs, Path dir) {
        this.fs = fs;
        this.dir = dir;
    }
    
    @Override
    public void close() throws IOException {
       //fs.close();
    }

    @Override
    public void deleteFile(String name) throws IOException {
        fs.delete(dir.cat(name));
    }

    @Override
    public boolean fileExists(String name) throws IOException {
        return fs.exists(dir.cat(name));
    }

    @Override
    public long fileLength(String name) throws IOException {
        return fs.getLength(dir.cat(name));
    }

    @Override
    public long fileModified(String name) throws IOException {
        return fs.lastModified(dir.cat(name));
    }

    @Override
    public String[] list() throws IOException {
        FileInfo[] files = fs.listFiles(dir, new PathFilter() {
            public boolean accept(Path pathname) {
                // only accept file, not accept directory
                try {
                    return fs.isFile(pathname);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        String[] ret = new String[files.length];
        for (int i=0;i<files.length;i++) {
            ret[i] = files[i].getPath().getName();
        }
        
        return ret;
    }

    @Override
    public IndexOutput createOutput(String name) throws IOException {
        throw new RuntimeException("not support for write");
    }

    @Override
    public IndexInput openInput(String name) throws IOException {
        Path f = dir.cat(name);
        FSDataInputStream is = fs.open(f);
        long length = fs.getLength(f);

        return new OfsIndexInput(is,length);
    }

    @Override
    public Lock makeLock(String name) {
        return new DirectoryLock(fs, dir, dir.cat(name));
    }

    @Override
    public void renameFile(String from, String to) throws IOException {
        fs.rename(dir.cat(from), dir.cat(to));
    }

    @Override
    public void touchFile(String name) throws IOException {
        throw new RuntimeException("not supported");
    }

    /**
     * The Lock class for OfsDirectory.
     * 
     * @author Wang Huiyong, david
     *
     */
    public static class DirectoryLock extends Lock {
        private IFileSystem fs;
        private Path lock;
        private Path dir;

        /**
         * The constructor.
         * @param fs  the file-system
         * @param dir  the direcotory
         * @param lock  the path of the loc
         */
        public DirectoryLock(IFileSystem fs, Path dir, Path lock) {
            this.fs = fs;
            this.lock = lock;
            this.dir = dir;
        }

        @Override
        public boolean isLocked() {
            boolean locked = false;
            try {
                try {
                    fs.getLock(dir, FileSystem.EXCLUSIVE_LOCK);
                    locked = fs.exists(lock);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                
                return locked;
            } finally {
                try {
                    fs.releaseLock(dir);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public boolean obtain() throws IOException {
            fs.getLock(dir, FileSystem.EXCLUSIVE_LOCK);
            try {
                if (fs.exists(lock)) {
                    return false;
                } else {
                    fs.mkdirs(lock);
                    return true;
                }
            } finally {
                fs.releaseLock(dir);
            }
        }

        @Override
        public void release() {
            try {
                try {
                    fs.delete(lock);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } finally {
                try {
                    fs.releaseLock(dir);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
    
    /**
     * The implementation of IndexInput fo OfsDirectory.
     * 
     * @author why, david
     *
     */
    public static class OfsIndexInput extends IndexInput {
        private FSDataInputStream is;
        private long length = 0;
        /**
         * The constructor.
         * 
         * @param is  the input-stream
         * @param length  the length
         */
        public OfsIndexInput(FSDataInputStream is, long length) {
            this.is = is;
            this.length = length; 
        }
        
        @Override
        public void close() throws IOException {
            is.close();
            length = 0;
        }

        @Override
        public long getFilePointer() {
            try {
                return is.getPos();
            } catch (IOException e) {
                e.printStackTrace();
                return -1;
            }
        }

        @Override
        public long length() {
            return length;
        }

        @Override
        public byte readByte() throws IOException {
            return is.readByte();
        }

        @Override
        public void readBytes(byte[] b, int offset, int len) throws IOException {
            is.readFully(b, offset, len);
        }

        @Override
        public void seek(long pos) throws IOException {
            is.seek(pos);
        }
    }

}
