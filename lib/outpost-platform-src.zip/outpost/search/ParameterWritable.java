package outpost.search;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;

/**
 * A writable parameter data-structure. This can be used to hold the
 * parameters from a url. It is a map from String to String[].
 * 
 * @author David
 *
 */
public class ParameterWritable extends HashMap<String, String[]> 
        implements IWritable {
    private static final long serialVersionUID = 5772732113728498005L;

    /**
     * Read parameters from the DataInput
     * @param in  the DataInput instance
     * @param params  the output parameters
     * @throws IOException  if an I/O error occurs
     */
    public static void readParameters(DataInput in,
            Map<String, String[]> params) throws IOException {
        params.clear();
        int size = CDataInputStream.readVInt(in);
        for (int i = 0; i < size; i ++) {
            String key = StringWritable.readString(in);
            int numVals = CDataInputStream.readVInt(in);
            if (numVals > 0) {
                String[] value = new String[numVals];
                for (int j = 0; j < numVals; j ++) {
                    value[j] = StringWritable.readStringNull(in);
                } // for j
                params.put(key, value);
            } // else
        } // for i
    }
    /**
     * Write parameters into a DataOutput
     * @param out  the DataOutput instance
     * @param params  the parameters to be written
     * @throws IOException  if an I/O error occurs
     */
    public static void writeParameters(DataOutput out, 
            Map<String, String[]> params) throws IOException {
        CDataOutputStream.writeVInt(params.size(), out);
        for (String key: params.keySet()) {
            StringWritable.writeString(out, key);
            String[] val = params.get(key);
            if (val != null && val.length > 0) {
                CDataOutputStream.writeVInt(val.length, out);
                for (int i = 0; i < val.length; i ++)
                    StringWritable.writeStringNull(out, val[i]);
            } else {
                CDataOutputStream.writeVInt(0, out);
            } // else
        } // for key
    }
    
    public void readFields(DataInput in) throws IOException {
        readParameters(in, this);
    }
    
    public void writeFields(DataOutput out) throws IOException {
        writeParameters(out, this);
    }
    
    public IWritable copyFields(IWritable value) {
        ParameterWritable that = (ParameterWritable) value;
        this.clear();
        for (String key: that.keySet()) {
            String[] thatVal = that.get(key);
            if (thatVal != null && thatVal.length > 0) {
                String[] thisVal = new String[thatVal.length];
                for (int i = 0; i < thatVal.length; i ++)
                    thisVal[i] = thatVal[i];
            } // if
        } // for i
        
        return this;
    }
}
