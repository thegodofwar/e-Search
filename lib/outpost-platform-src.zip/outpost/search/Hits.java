package outpost.search;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.serialize.IWritable;
import odis.serialize.toolkit.WritableArrayList;
import toolbox.text.util.HexString;

/**
 * The data-structure containing searched results (hits list)
 * 
 * Fields (other than of WritableArrayList<Hits.Hit>)
 *   total  int  the total number of matched hits (we may only show part of
 *               these matched hits)
 *               
 * Overridable methods:
 *   writeUserData()   Overrides this if you have user-defined data to write 
 *                     out
 *   clearUserData()   Overrides this to prepare an empty buffer for receiving
 *                     user defined data
 *   appendUserData()  Overrides this so as to receive parts of the user-defined
 *                     data
 *                     
 *   writeUserData/clearUserData/appendUserData are mainly used to transfer
 *   extra data from the local-index-searcher to ds.
 *   NOTE: the user-data in Hits should be accumulated, since in DS
 *         appendUserData will be called more than once corresponding to each 
 *         local-searcher.
 *   
 *   
 * @author David
 *
 */
public class Hits extends WritableArrayList<Hits.Hit> {
    private static final long serialVersionUID = -909809331347234731L;
    
    private int total = 0;
    
    public int getTotal() {
        return total;
    }
    public void setTotal(int total) {
        this.total = total;
    }
    
    /**
     * Write extra fields (other than the array related data)
     * @param out  the output stream for writing
     * @throws IOException  if an I/O error occurs
     */
    protected void writeExtraFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(total, out);
    }
    /**
     * Read extra fields (other than the array related data)
     * @param in  the input stream for reading
     * @throws IOException  if an I/O error occurs
     */
    public void readExtraFields(DataInput in) throws IOException {
        total = CDataInputStream.readVInt(in);
    }
    
    @Override
    public void writeFields(DataOutput out) throws IOException {
        writeExtraFields(out);
        // write the array of Hit
        CDataOutputStream.writeVInt(this.size(), out);
        for (int i = 0; i < size(); i++)
            ((IWritable) this.get(i)).writeFields(out);
    }
    public void readFields(DataInput in) throws IOException {
        readExtraFields(in);
        // read the array of Hit
        final int inSize = CDataInputStream.readVInt(in);
        // read fields
        for (int i = 0; i < inSize; i++)
            if (i < this.size())
                this.get(i).readFields(in);
            else {
                Hit obj = newElementInstance();
                obj.readFields(in);
                this.add(obj);
            } // else, for i
        // remove extra elements
        if (this.size() > inSize)
            this.removeRange(inSize, this.size());
    }
    /**
     * A single search entry (hit).
     * 
     * Fields:
     *   docID  long   a 64-bit id (from URL) of the entry
     *   score  float  the ranking score of this hit. The higher the more
     *                 relevant.
     *   slice  int    the slice number of this hit
     * 
     * @author David
     *
     */
    public static class Hit implements IWritable {
        private long docID;
        private float score;
        private int slice;
        
        public void readFields(DataInput in) throws IOException {
            docID = in.readLong();
            score = in.readFloat();
            slice = CDataInputStream.readVInt(in);
        }
        public void writeFields(DataOutput out) throws IOException {
            out.writeLong(docID);
            out.writeFloat(score);
            CDataOutputStream.writeVInt(slice, out);
        }
        public IWritable copyFields(IWritable value) {
            Hit that = (Hit) value;

            this.docID = that.docID;
            this.score = that.score;
            this.slice = that.slice;
            
            return this;
        }
        @Override
        public String toString() {
            return HexString.longToPaddedHex(docID).toUpperCase() 
                + "(slice " + slice + "): score = " + score;
        }
        
        public float getScore() {
            return score;
        }
        public void setScore(float score) {
            this.score = score;
        }
        
        public long getDocID() {
            return docID;
        }
        public void setDocID(long docID) {
            this.docID = docID;
        }
        
        public int getSlice() {
            return slice;
        }
        public void setSlice(int slice) {
            this.slice = slice;
        }
    }

    @Override
    protected Hit newElementInstance() {
        return new Hit();
    }
    
    /**
     * Writes user-defined data out
     * @param out  the DataOutput for writing
     * @throws IOException  if an I/O error occurs
     */
    public void writeUserData(DataOutput out) throws IOException {
    }
    /**
     * Clears the user-defined data waiting for appending
     * @throws IOException  if an I/O error occurs
     */
    public void clearUserData() throws IOException {
    }
    /**
     * Appends new parts of user-defined data to the current user-data
     * @param in  the DataInput for reading from
     * @throws IOException  if an I/O error occurs
     */
    public void appendUserData(DataInput in) throws IOException {
    }
}
