package outpost.search;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import outpost.search.Hits.Hit;
import outpost.service.DataBuffer;
import outpost.service.IHandler;
import outpost.service.ServiceError;
import outpost.service.ServiceMaster;
import outpost.service.ServiceMaster.EntriesFuture;
import outpost.service.ServiceMaster.EntryFuture;

import odis.serialize.IWritable;
import odis.serialize.lib.StringWritable;
import toolbox.misc.LogFormatter;

/**
 * The adapter of the local-summary handler.
 * 
 * Two classes are defined: LocalSummaryServer and SummaryProvider.
 * The SummaryProvider will send a summary requests to the LocalSummaryServer(s)
 * according to the partition number of each hit. Each local-server returns the
 * summaries back to the provide, and the results are arranged and returned.
 * 
 * The data sent from SummaryProvider to LocalSummaryServer is in the 
 * following format:
 *   <query(StringWritable)> 
 *   <params(ParameterWritable)>
 *   <size(vint>
 *   <doc(long)> ... <doc(long)>
 *   
 * The data return from LocalIndexServer to IndexClientSearcher is in the 
 * following format:
 *   <code(vint)> 
 *   <size(vint)>
 *   <summary(T)> ... <summary(T)>
 * 
 * @author David
 *
 */
public class SummaryHandlerAdapters {
    private static final Logger LOG = 
        LogFormatter.getLogger(SummaryHandlerAdapters.class);
    
    /**
     * the code indicating a failed operation
     */
    public static int CODE_FAILED = 0;
    /**
     * the code indicating a successful operation
     */
    public static int CODE_SUCC   = 1;
    
    /**
     * A static DataBuffer representing a failure
     */
    public static final DataBuffer DB_FAILED = new DataBuffer();
    static {
        try {
            IndexSearchHandlerAdapters.DB_FAILED.writeVInt(CODE_FAILED);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * A handler that handles the summary requests. Set the provider property
     * before using.
     * 
     * Fields:
     *   provider  LocalSummaryProvider  the local summary provider
     * 
     * @author David
     *
     * @param <T>  the type of summary data-structure
     */
    public static class LocalSummaryServer<T extends IWritable> 
            implements IHandler {
        private LocalSummaryProvider<T> provider;
       
        public LocalSummaryProvider<T> getProvider() {
            return provider;
        }
        public void setProvider(LocalSummaryProvider<T> provider) {
            this.provider = provider;
        }

        public DataBuffer exec(DataBuffer in) {
            try {
                /*
                 * Read from master
                 */
                String query = StringWritable.readString(in);
                HashMap<String, String[]> params = 
                    new HashMap<String, String[]>();
                ParameterWritable.readParameters(in, params);
                
                int size = in.readVInt();
                if (size == 1) {
                    long doc = in.readLong();
                    T summ = provider.getSummary(query, doc, params);
                    /*
                     * Write back to master
                     */
                    DataBuffer res = new DataBuffer();
                    res.writeVInt(CODE_SUCC);
                    res.writeVInt(1);
                    if (summ == null) {
                        res.writeBoolean(false);
                    } else {
                        res.writeBoolean(true);
                        summ.writeFields(res);
                    } // else
                    
                    return res;
                } else {
                    long[] docs = new long[size];
                    for (int i = 0; i < size; i ++)
                        docs[i] = in.readLong();
                    /*
                     * lookup
                     */
                    T[] summs = provider.getSummaries(query, docs, 
                            params);
                    /*
                     * Write back to master
                     */
                    DataBuffer res = new DataBuffer();
                    res.writeVInt(CODE_SUCC);
                    res.writeVInt(summs.length);
                    for (int i = 0; i < summs.length; i ++) {
                        if (summs[i] == null) {
                            res.writeBoolean(false);
                        } else {
                            res.writeBoolean(true);
                            summs[i].writeFields(res);
                        } // else
                    } // for i
                    return res;
                } // else
            } catch (IOException e) {
                LOG.log(Level.WARNING, "Exception in exec()", e);
                return DB_FAILED;
            }
        }
    }
    
    /**
     * The abstract distributed summary provider class.
     * 
     * Field:
     *   master  ServiceMaster   the service-master instance controlling local
     *                           summary servers
     *   localSummaryCount  int  the number of local summary serviers           
     * 
     * @author David
     *
     * @param <T>  the type of summary data-structure
     */
    public static abstract class SummaryProvider<T extends IWritable> {
        protected ServiceMaster master;
        protected int serviceType;
        
        public ServiceMaster getMaster() {
            return master;
        }
        public void setMaster(ServiceMaster master) {
            this.master = master;
        }
        
        public int getServiceType() {
            return serviceType;
        }
        public void setServiceType(int serviceType) {
            this.serviceType = serviceType;
        }
        
        protected int localSummaryCount = 1;
        public int getLocalSummaryCount() {
            return localSummaryCount;
        }
        public void setLocalSummaryCount(int localSummaryCount) {
            this.localSummaryCount = localSummaryCount;
        }

        /**
         * Allocates a new instance of the summary data-structure.
         * 
         * @return  a new instance of the summary data-structure
         */
        protected abstract T newSummaryEntry();
        /**
         * Calculate the partition number (slice index) of a doc
         * 
         * @param docID  the 64-bits id of the doc
         * @return  the partition-number
         */
        protected abstract int getSlice(long docID);
        /**
         * Returns the slice number for a specified hits.
         * The default implementation returns hit.getSlice()
         * @param hit  the Hit instance
         * @return the slice number for a specified hits
         */
        protected int getSlice(Hit hit) {
            return hit.getSlice();
        }
        /**
         * prepare the DataBuffer[] and slices for summary querying.
         * 
         * @param query  the query string
         * @param hits  the hits
         * @param params  the parameters
         * @param slices  the output array for storing slices
         * @return  the DataBuffer array
         * @throws IOException  if an I/O error occurs
         */
        protected DataBuffer[] prepare(String query, Hits hits, 
                Map<String, String[]> params, int[] slices) throws IOException {
            ArrayList<Long>[] buckets = new ArrayList[localSummaryCount];
            /*
             * Initialize buckets
             */
            int aveCount = hits.size() / localSummaryCount + 1;
            for (int i = 0; i < localSummaryCount; i ++) {
                buckets[i] = new ArrayList<Long>(aveCount);
            } // for i
            /*
             * Assign hits to one of the buckets according to the its partition
             * number.
             */
            for (int i = 0; i < hits.size(); i ++) {
                Hit hit = hits.get(i);
                int slice = getSlice(hit);
                buckets[slice].add(hit.getDocID());
            } // for i
            DataBuffer[] in = new DataBuffer[localSummaryCount];

            /*
             * initialize the query,parameter parts
             */
            for (int i = 0; i < in.length; i ++) {
                slices[i] = i;
                in[i] = new DataBuffer();
                if (i == 0) {
                    StringWritable.writeString(in[i], query);
                    ParameterWritable.writeParameters(in[i], params);
                } else {
                    in[i].copyFields(in[0]);
                } // else
            } // for i
            /*
             * Put hits of each bucket
             */
            for (int i = 0; i < in.length; i ++) {
                in[i].writeVInt(buckets[i].size());
                for (Long doc: buckets[i])
                    in[i].writeLong(doc);
            } // for i
            
            return in;
        }
        /**
         * Takes out the returned summaries from the DataBuffer[] from local
         * summary servers.
         * 
         * @param hits  the hits
         * @param outs  the DataBuffer array from local summary servers
         * @return  the List of summaries
         * @throws IOException  if an I/O error occurs
         */
        protected ArrayList<T> takeOut(Hits hits, DataBuffer[] outs) 
                throws IOException {
            int[] cnts = new int[outs.length];
            for (int slice = 0; slice < outs.length; slice ++) {
                boolean succ = outs[slice] != null && 
                    outs[slice].readVInt() == CODE_SUCC;
                if (!succ) {
                    outs[slice] = null;
                } else {
                    cnts[slice] = outs[slice].readVInt();
                } // else
            } // for i
            
            ArrayList<T> res = new ArrayList<T>();
            for (int i = 0; i < hits.size(); i ++) {
                Hit hit = hits.get(i);
                int slice = getSlice(hit);
                if (outs[slice] != null && cnts[slice] > 0) {
                    boolean exist = outs[slice].readBoolean();
                    if (exist) {
                        T sum = newSummaryEntry();
                        sum.readFields(outs[slice]);
                        res.add(sum);
                    } // if
                    cnts[slice] --;
                } // if
            } // for i
            
            return res;
        }
        
        /**
         * Looks up the summaries of a set of hits. If success, the returned 
         * list has the same orders with the input hits, except some summary 
         * could be missing.
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param hits  the hits to be looked up
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summaries. Some summaries may be missing
         *          because some local server may timeout or some docid has no
         *          summary found
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public List<T> getSummaries(String query, Hits hits, 
                Map<String, String[]> params, int ttl, ServiceError error) 
                throws InterruptedException {
            try {
                // the slice nubmer for master.processForSome
                int[] slices = new int[localSummaryCount];
                DataBuffer[] in = prepare(query, hits, params, slices);
                /*
                 * Process
                 */
                DataBuffer[] outs = master.processForSome(
                        serviceType, in, slices, ttl, error);
                /*
                 * Take out returned summaries
                 */
                if (error.isSucc()) {
                    return takeOut(hits, outs);
                } // if
                
                return null;
            } catch (InterruptedException e) {
                throw e;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception in getSummaries()", e);
                error.setStatus(ServiceError.STATUS_FAILED);
                error.setReason(ServiceError.REASON_EXCEPTION);
                return null;
            }
        }
        /**
         * The future class for summaries.
         * 
         * @author david
         *
         */
        public class SummariesFuture {
            private EntriesFuture ents;
            private Hits hits;
            private ServiceError error;
            SummariesFuture(EntriesFuture ents, Hits hits, 
                    ServiceError error) {
                this.ents = ents;
                this.hits = hits;
                this.error = error;
            }
            /**
             * Waits and returns the summary instances.
             * 
             * @return the summary list
             * @throws InterruptedException  if the current thread was 
             *                               interrupted during waiting.
             */
            public List<T> get() throws InterruptedException {
                DataBuffer[] outs = ents.get();
                if (error.isSucc()) {
                    try {
                        return takeOut(hits, outs);
                    } catch (Exception e) {
                        LOG.log(Level.WARNING, "Exception in getSummaries()", 
                                e);
                        error.setStatus(ServiceError.STATUS_FAILED);
                        error.setReason(ServiceError.REASON_EXCEPTION);
                        return null;
                    }
                } // if
                return null;
            }
        }
        /**
         * Looks up the summaries of a set of hits in an asynchronized way. If 
         * success, the returned list has the same orders with the input hits, 
         * except some summary could be missing.
         * NOTE: all objects can not be reused until the request returns, i.e.
         *       calling to future.get().
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param hits  the hits to be looked up
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the future class for the looked up summaries.
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public SummariesFuture asyncGetSummaries(String query, Hits hits, 
                Map<String, String[]> params, int ttl, ServiceError error) {
            try {
                // the slice nubmer for master.processForSome
                int[] slices = new int[localSummaryCount];
                DataBuffer[] in = prepare(query, hits, params, slices);
                /*
                 * Process
                 */
                EntriesFuture ents = master.asyncProcessForSome(serviceType, in, 
                        slices, ttl, error);
                /*
                 * Take out returned summaries
                 */
                if (error.isSucc()) {
                    return new SummariesFuture(ents, hits, error);
                } // if
                
                return null;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception in getSummaries()", e);
                error.setStatus(ServiceError.STATUS_FAILED);
                error.setReason(ServiceError.REASON_EXCEPTION);
                return null;
            }
        }
        /**
         * The Future class for Summary.
         * 
         * @author david
         *
         */
        public class SummaryFuture {
            private EntryFuture ent;
            private ServiceError error;
            SummaryFuture(EntryFuture ent, ServiceError error) {
                this.ent = ent;
                this.error = error;
            }
            /**
             * Waits and returns the summary instance.
             * 
             * @return the summary instance.
             * @throws InterruptedException  if the current thread was 
             *                               interrupted during waiting.
             */
            public T get() throws InterruptedException {
                DataBuffer out = ent.get();
                try {
                    if (error.isSucc()) {
                        return takeOut(out, error);
                    } // if
                } catch (Exception e) {
                    LOG.log(Level.WARNING, "Exception in getSummary()", e);
                    error.setStatus(ServiceError.STATUS_FAILED);
                    error.setReason(ServiceError.REASON_EXCEPTION);
                }
                return null;
            }
        }
        /**
         * Looks up a summary for a doc under some specified context (query,
         * params). The slice the summary will be computed by calling
         * getSlice.
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param docID  the id of the doc
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public T getSummary(String query, long docID, 
                Map<String, String[]> params, int ttl, ServiceError error) 
                throws InterruptedException {
            return getSummary(query, docID, getSlice(docID), params, ttl, 
                    error);
        }
        /**
         * Looks up a summary for a doc under some specified context (query,
         * params) in an ascynchronized way. The slice the summary will be 
         * computed by calling getSlice.
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param docID  the id of the doc
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public SummaryFuture asyncGetSummary(String query, long docID, 
                Map<String, String[]> params, int ttl, ServiceError error) {
            return asyncGetSummary(query, docID, getSlice(docID), params, ttl, 
                    error);
        }
        
        /**
         * Prepares the DataBuffer and slices for summary querying.
         * 
         * @param query  the query string
         * @param docID  the id of the summary
         * @param params  the parameters
         * @return  the DataBuffer array
         * @throws IOException  if an I/O error occurs
         */
        protected DataBuffer prepare(String query, long docID, 
                Map<String, String[]> params) throws IOException {
            DataBuffer in = new DataBuffer();
            
            StringWritable.writeString(in, query);
            ParameterWritable.writeParameters(in, params);
            in.writeVInt(1);
            in.writeLong(docID);
            
            return in;
        }
        /**
         * Takes out the returned summary from the DataBuffer from the local
         * summary server.
         * 
         * @param out  the DataBuffer from the local summary server
         * @param error  the ServiceError instance
         * @return  the summary instance
         * @throws IOException  if an I/O error occurs
         */
        protected T takeOut(DataBuffer out, ServiceError error) 
            throws IOException {
            if (out.readVInt() == CODE_SUCC) {
                int len = out.readVInt();
                if (len <= 0)
                    return null;
                if (out.readBoolean()) {
                    T summ = newSummaryEntry();
                    summ.readFields(out);
                    return summ;
                } // if
            } else {
                error.setStatus(ServiceError.STATUS_FAILED);
                error.setReason(ServiceError.REASON_SERVERERROR);
            } // else
            return  null;
        }
        /**
         * Look up a summary for a doc under some specified context (query,
         * params) in a specified local-summary-server(slice is set).
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param docID  the id of the doc
         * @param slice  the slice where the summary of this doc can be found
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public T getSummary(String query, long docID, int slice, 
                Map<String, String[]> params, int ttl, ServiceError error) 
                throws InterruptedException {
            try {
                DataBuffer in = prepare(query, docID, params);
                // Process
                DataBuffer out = master.process(
                        slice, serviceType, in, ttl, error);
                // Take out
                if (error.isSucc()) {
                    return takeOut(out, error);
                } // if
                return null;
            } catch (InterruptedException e) {
                throw e;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception in getSummaries()", e);
                error.setStatus(ServiceError.STATUS_FAILED);
                error.setReason(ServiceError.REASON_EXCEPTION);
                return null;
            }
        }
        /**
         * Looks up a summary for a doc under some specified context (query,
         * params) in a specified local-summary-server(slice is set) in an
         * asynchronized way.
         * NOTE: all objects can not be reused until the request returns, i.e.
         *       calling to future.get().
         * 
         * @param query  the query for the hits. This is useful when 
         *               highlighting is also done during summary making
         * @param docID  the id of the doc
         * @param slice  the slice where the summary of this doc can be found
         * @param params  the parameters of this searching
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  The furture class for the looked up summary. If some error
         *          occurs before sending the request, null is returned with
         *          with detailed information in error.
         * @throws InterruptedException  if the thread is interrupted during
         *                               blocking
         */
        public SummaryFuture asyncGetSummary(String query, long docID, 
                int slice, Map<String, String[]> params, int ttl, 
                ServiceError error) {
            try {
                DataBuffer in = prepare(query, docID, params);
                // Process
                EntryFuture ent = master.asyncProcess(slice, serviceType, in, 
                        ttl, error);
                if (error.isSucc()) {
                    return new SummaryFuture(ent, error);
                } // if
                return null;
            } catch (Exception e) {
                LOG.log(Level.WARNING, "Exception in getSummaries()", e);
                error.setStatus(ServiceError.STATUS_FAILED);
                error.setReason(ServiceError.REASON_EXCEPTION);
                return null;
            }
        }
        /**
         * An empty parameter map instance
         */
        public static Map<String, String[]> EMPTY_PARAMS =
            new HashMap<String, String[]>();
        /**
         * Looks up a summary for a doc without a context. This is implemented
         * by calling getSummary("", docID, EMPTY_PARAMS, ttl, error)
         * 
         * @param docID  the id of the doc
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         */
        public T getSummary(long docID, int ttl, ServiceError error) 
                throws InterruptedException {
            return getSummary("", docID, EMPTY_PARAMS, ttl, error); 
        }
        /**
         * Looks up a summary for a doc without a context in an asyncronized 
         * way. This is implemented by calling getSummary("", docID, 
         * EMPTY_PARAMS, ttl, error)
         * 
         * @param docID  the id of the doc
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         */
        public SummaryFuture asyncGetSummary(long docID, int ttl, 
                ServiceError error) {
            return asyncGetSummary("", docID, EMPTY_PARAMS, ttl, error); 
        }
        /**
         * Looks up a summary for a doc without a context. This is implement
         * by calling getSummary("", docID, new Map<String, String[]> params,
         * ttl, error). The slice the summary will be computed by calling
         * getSlice.
         * 
         * @param docID  the id of the doc
         * @param slice  the slice where the summary of this doc can be found
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         */
        public T getSummary(long docID, int slice, int ttl, 
                ServiceError error) throws InterruptedException {
            return getSummary("", docID, slice, EMPTY_PARAMS, ttl, error); 
        }
        /**
         * Looks up a summary for a doc without a context in an asynchronized 
         * way. This is implement by calling getSummary("", docID, 
         * new Map<String, String[]> params, ttl, error). The slice the summary 
         * will be computed by calling getSlice.
         * 
         * @param docID  the id of the doc
         * @param slice  the slice where the summary of this doc can be found
         * @param ttl  the time-to-live in seconds
         * @param error  the instance to accept error message duing looking up
         * @return  the looked up summary. If the summary is not found, null is
         *          returned with SUCC status set in error.
         * @throws InterruptedException  if the thread is interrupted during
         */
        public SummaryFuture asyncGetSummary(long docID, int slice, int ttl, 
                ServiceError error) {
            return asyncGetSummary("", docID, slice, EMPTY_PARAMS, ttl, error); 
        }
    }
}
