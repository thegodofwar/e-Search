package outpost.search.utils;

import java.util.Map;

import odis.serialize.IWritable;
/**
 * A simple provider whose return instance is the same-typed as the value 
 * instance.
 * 
 * @author david
 *
 * @param <T>  the class of both return value and key value
 */
public abstract class LongIndexedFileSummaryProvider<T extends IWritable> 
        extends LongIndexedFileSummaryProvider2<T, T> {
    @Override
    protected T convert(T v, String query, long docID,
            Map<String, String[]> params) {
        return v;
    }

    @Override
    protected Class<T> getReturnClass() {
        return getValueClass();
    }
}
