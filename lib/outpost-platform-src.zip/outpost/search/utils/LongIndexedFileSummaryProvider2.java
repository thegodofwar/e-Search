package outpost.search.utils;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import odis.file.LongIndexedFileReader;
import odis.file.LongIndexedFileReader.Cursor;
import odis.io.FileSystem;
import odis.io.IFileSystem;
import odis.io.Path;
import odis.serialize.IWritable;
import outpost.search.LocalSummaryProvider;
import toolbox.misc.LogFormatter;

/**
 * An abstract summary provider which reads summaries from an indexed-file whose
 * key is a long.
 * Fields:
 *   fs    IFileSystem  the file-system
 *   dirs  Path[]       the paths to the indexed-files
 * 
 * Usage:
 *   provider = new LongIndexedFileSummaryProvider2<ValueSummary, 
 *              ReturnSummary>() {
 *      Class<V> getValueClass() {
 *              return ValueSummary.class;
 *      }
 *   };
 *   
 *   provider.setFiles(...)
 *   
 *   provider.init();
 *   ...
 *   ReturnSummary[] sums = provider.getSummaries(...);
 *   ReturnSummary sum = provider.getSummary(...);
 *   ...
 *   provider.done();
 *   
 * Overridable methods:
 *   getValueClass   returns the class of the value in the indexed-file
 *   getReturnClass  returns the class of the return value in getSummaries()
 *   convert         converts a value instance into a return instance
 *
 * @author david
 *
 * @param <V>  the class of the value in the indexed-file
 * @param <T>  the class of the returned summary instances
 */
public abstract class LongIndexedFileSummaryProvider2<V extends IWritable, 
        T extends IWritable> extends LocalSummaryProvider<T> {
    private static final Logger LOG = LogFormatter.getLogger(
            LongIndexedFileSummaryProvider.class.getName());
    protected LongIndexedFileReader[] readers;
    
    private Path[] files;
    private IFileSystem fs; {
        try {
            fs = FileSystem.getNamed("local");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void setFiles(Path[] files) {
        this.files = files;
    }
    public Path[] getFiles() {
        return files;
    }
    public void setFile(Path file) {
        this.setFiles(new Path[]{file});
    }
    
    public IFileSystem getFs() {
        return fs;
    }
    public void setFs(IFileSystem fs) {
        this.fs = fs;
    }

    
    private Class<V> valueClass;
    private Class<T> returnClass;
    
    /**
     * Initializes readers
     */
    public void init() throws Exception {
        valueClass = getValueClass();
        returnClass = getReturnClass();
        if (readers == null) {
            LOG.info("Initializing ...");
            readers = new LongIndexedFileReader[files.length];
            for (int i = 0; i < readers.length; i++) {
                LOG.info("  [" + i + "] " + files[i]);
                readers[i] = new LongIndexedFileReader(fs, files[i]);
            }
        }
    }
    /**
     * Returns the index in <files> of a specified docID
     * @param docID  the doc-ID
     * @returns the index
     */
    protected int calcIndex(long docID) {
        return 0;
    }
    
    @Override
    public T[] getSummaries(String query, long[] docIDs, 
            Map<String, String[]> params) {
        T[] res = (T[]) Array.newInstance(returnClass, docIDs.length);
        for (int i = 0; i < docIDs.length; i ++) {
            V v = fetchSummary(docIDs[i]);
            if (v == null)
                res[i] = null;
            else
                res[i] = convert(v, query, docIDs[i], params);
        } // for i
        return res;
    }

    /**
     * Returns the class of the value in the indexed-file
     * @return the class of the value in the indexed-file
     */
    protected abstract Class<V> getValueClass();
    /**
     * Allocates a new instance of the value
     * @return  the new instance of the value
     */
    protected V newValueIntance() {
        try {
            return valueClass.newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * Returns the class of the return summary
     * @return the class of the return summary
     */
    protected abstract Class<T> getReturnClass();
    /**
     * Fetches a single summary for a specified doc-ID.
     * @param docID  the docID of the summary
     * @return  the fetched summary if found, null if not found or any error
     *          occurs
     */
    protected V fetchSummary(long docID) {
        int index = calcIndex(docID);
        Cursor cur = null;
        try {
            cur = readers[index].openCursor();
            V res = newValueIntance();
            if (cur.get(docID, res)) {
                return res;
            } else {
                return null;
            } // else
        } catch (Exception e) {
            LOG.log(Level.WARNING, "Exception caught in fetchSummary()", e);
            return null;
        } finally {
            if (cur != null) {
                readers[index].closeCursor(cur);
            } // if
        }
    }
    /**
     * Converts a value instance to a return instance.
     * @param v  the value instance returned by fetchSummary
     * @param query  the query string
     * @param docID  the doc-ID of the summary
     * @param params  the parameters
     * @return  the converted return instance
     */
    protected abstract T convert(V v, String query, long docID, 
            Map<String, String[]> params);

    @Override
    public T getSummary(String query, long docID, 
            Map<String, String[]> params) {
        V v = fetchSummary(docID);
        if (v == null)
            return null;
        return convert(v, query, docID, params);
    }
    /**
     * Closes this provider
     */
    public void close() {
        if (readers != null) {
            for (LongIndexedFileReader reader: readers)
                reader.close();
        } // if
    }
}
