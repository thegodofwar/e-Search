package outpost.search;

import java.util.Map;

import odis.serialize.IWritable;
/**
 * The abstract local summary provider class
 * 
 * @author David
 *
 * @param <T>  the type of the summary data-structure
 */
public abstract class LocalSummaryProvider<T extends IWritable> {
    /**
     * Returns summaries of some docs.
     * NOTE: the implementation of this method should catch all exceptions
     * 
     * @param query  the query of this searching. This is useful when 
     *               highlighting is done during making summary
     * @param docIDs  the list of ids of the docs
     * @param params  the parameters
     * @return  the array of the summaries looked up. 
     *          NOTE: If some summaries were not found for some docs, leave
     *          corresponding elements null. the implementation MUST assure
     *          the length of the return array is the same as docIDs 
     */
    public abstract T[] getSummaries(String query, long[] docIDs, 
            Map<String, String[]> params);
    /**
     * Returns the single summary of a doc.
     * NOTE: the default implementation calls getSummaries by creating a
     * 1-element long-array, this could be overridden for optimization. 
     * 
     * @param query  the query of this searching. This is useful when 
     *               highlighting is done during making summary
     * @param docID  the id of the doc
     * @param params  the parameters
     * @return  the summary of the doc if found, null otherwise
     */
    public T getSummary(String query, long docID, 
            Map<String, String[]> params) {
        return getSummaries(query, new long[]{docID}, params)[0];
    }
}
