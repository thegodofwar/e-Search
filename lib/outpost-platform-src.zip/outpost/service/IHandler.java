package outpost.service;


/**
 * The interface for handling each request.
 * 
 * @author David
 *
 */
public interface IHandler {
    /**
     * Execute an handling request and returns the result.
     * 
     * @param in  the input data
     * @return  the output data
     */
    public DataBuffer exec(DataBuffer in);
}