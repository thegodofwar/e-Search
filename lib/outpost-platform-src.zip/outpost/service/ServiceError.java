package outpost.service;

/**
 * The data-structure for an error of one request to the service
 * 
 * Fields:
 *   status  int  the status of this request processing. Possible values 
 *                include: 
 *                  STATUS_SUCC     fully success
 *                  STATUS_PARTIAL  partially success. (some timeout may have 
 *                                  happened, and thus some results may be lost)
 *                  STATUS_FAILED   totally failed, no results returned
 *   reason  int  why this processing is failed. Possible values include:
 *                  REASON_NONE       no reason (because success)
 *                  REASON_NOSLAVE    no active slaves
 *                  REASON_EXCEPTION  exception caught
 *                  REASON_TIMEOUT    some or all processing timeout
 * 
 * @author David
 *
 */
public class ServiceError {
    public static final int STATUS_SUCC    = 0; 
    public static final int STATUS_PARTIAL = 1;
    public static final int STATUS_FAILED  = 2;
    
    public static final String[] STATUS_NAMES = {
        "SUCC",  "PARTIAL", "FAILED"
    };
    
    public static final int REASON_NONE        = 0;
    public static final int REASON_NOSLAVE     = 1;
    public static final int REASON_EXCEPTION   = 2;
    public static final int REASON_TIMEOUT     = 3;
    public static final int REASON_SERVERERROR = 4;
    
    public static final String[] REASON_NAMES = {
        "NONE", "NO-SLAVE", "EXCEPTION", "TIMEOUT", "SERVER-ERROR"
    };
    
    private int status = 0;
    private int reason = 0;
    
    public int getReason() {
        return reason;
    }
    public void setReason(int reason) {
        this.reason = reason;
    }
    
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
        if (status == STATUS_SUCC)
            reason = REASON_NONE;
    }
    
    /**
     * Whether this processing contains valid results.
     * 
     * @return  true if some or all of the results obtained, false otherwise
     */
    public boolean isSucc() {
        return status == STATUS_SUCC || status == STATUS_PARTIAL;
    }
    /**
     * Whether totally results are obtained.
     * 
     * @return true if all results are obtained, false otherwise
     */
    public boolean isFullSucc() {
        return status == STATUS_SUCC;
    }
    
    @Override
    public String toString() {
        if (status == STATUS_SUCC)
            return STATUS_NAMES[STATUS_SUCC];
        
        return STATUS_NAMES[status] + " - " + REASON_NAMES[reason];
    }
}
