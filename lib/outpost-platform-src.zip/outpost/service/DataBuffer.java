package outpost.service;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.CDataInputStream;
import odis.io.CDataOutputStream;
import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;
import odis.serialize.WritableRegistry;

/**
 * A writable object that implements data-input and data-output interfaces.
 * 
 * Calling the writeXxx methods, data is appended to the end of the buffer.
 * Calling the readXxx methods, data is exported from the front of the buffer.
 * You can call resetReader to reset the read pointer. 
 * 
 * Usage:
 *   1) Set and write
 *     DataBuffer buf = new DataBuffer();
 *     buf.writeInt(1);
 *     ...
 *     buf.writeFields(out);
 *     
 *   2) Read and get
 *     DataBuffer buf = new DataBuffer();
 *     buf.readFields(in);
 *     vl = buf.readInt();
 *     ...
 * 
 * @author David
 *
 */
public class DataBuffer extends DataOutputBuffer 
        implements IWritable, DataInput {
    static {
        WritableRegistry.registerAlias(DataBuffer.class, "buffer_v3");
    }
    
    private DataInputBuffer reader;

    public void readFields(DataInput in) throws IOException {
        this.reset(); // reset before setting size for avoiding data copy.
        this.setSize(CDataInputStream.readVInt(in));
        if (this.size() > 0)
            in.readFully(this.getData(), 0, this.size());
    }

    public void writeFields(DataOutput out) throws IOException {
        CDataOutputStream.writeVInt(this.size(), out);
        if (this.size() > 0)
            out.write(this.getData(), 0, this.size());
    }

    public IWritable copyFields(IWritable value) {
        DataBuffer that = (DataBuffer) value;
        
        this.reset();
        try {
            this.write(that.getData(), 0, that.size());
        } catch (IOException e) {
            new RuntimeException(e);
        }
        
        return this;
    }
    
    /**
     * Assure the reader is created and ready for readXXX
     *
     */
    protected void assureReader() {
        if (reader == null) {
            reader = new DataInputBuffer();
            reader.reset(getData(), 0, size());
        } // if
    }
    /**
     * Reset the reader for reading (create the reader if necessary)
     *
     */
    public void resetReader() {
        if (reader == null)
            reader = new DataInputBuffer();
        reader.reset(getData(), 0, size());
    }

    public boolean readBoolean() throws IOException {
        assureReader();
        return reader.readBoolean();
    }

    public byte readByte() throws IOException {
        assureReader();
        return reader.readByte();
    }

    public char readChar() throws IOException {
        assureReader();
        return reader.readChar();
    }

    public double readDouble() throws IOException {
        assureReader();
        return reader.readDouble();
    }

    public float readFloat() throws IOException {
        assureReader();
        return reader.readFloat();
    }

    public void readFully(byte[] b) throws IOException {
        assureReader();
        reader.readFully(b);
    }

    public void readFully(byte[] b, int off, int len) throws IOException {
        assureReader();
        reader.readFully(b, off, len);
    }

    public int readInt() throws IOException {
        assureReader();
        return reader.readInt();
    }
    
    /**
     * Read a v-int data from the input.
     * 
     * @return  the read integer number
     * @throws IOException  if an I/O error occurs. e.g. EOFException.
     */
    public int readVInt() throws IOException {
        assureReader();
        return reader.readVInt();
    }

    public String readLine() throws IOException {
        assureReader();
        return reader.readLine();
    }

    public long readLong() throws IOException {
        assureReader();
        return reader.readLong();
    }

    public short readShort() throws IOException {
        assureReader();
        return reader.readShort();
    }

    public String readUTF() throws IOException {
        assureReader();
        return reader.readUTF();
    }

    public int readUnsignedByte() throws IOException {
        assureReader();
        return reader.readUnsignedByte();
    }

    public int readUnsignedShort() throws IOException {
        assureReader();
        return reader.readUnsignedShort();
    }

    public int skipBytes(int n) throws IOException {
        assureReader();
        return reader.skipBytes(n);
    }
}
