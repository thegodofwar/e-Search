package outpost.service.mina;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.mina.common.IdleStatus;
import org.apache.mina.common.IoFilterAdapter;
import org.apache.mina.common.IoSession;

/**
 * A IoFilterAdapter that supports multi-threads.
 * 
 * @author david
 *
 */
public class MultiThreadFilter extends IoFilterAdapter {
//    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final Executor executor;

    /**
     * Creates a new instace with the default thread pool implementation
     * (<tt>new ThreadPoolExecutor(numThread, numThread, 60, TimeUnit.SECONDS, 
     * new LinkedBlockingQueue() )</tt>).
     * 
     * @param numThread  the number of threads
     */
    public MultiThreadFilter(int numThread) {
        this(new ThreadPoolExecutor(numThread, numThread, 60, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>()));
    }

    /**
     * Creates a new instance with the specified <tt>executor</tt>.
     * @param executor  the executor for performing actions
     */
    public MultiThreadFilter(Executor executor) {
        if (executor == null) {
            throw new NullPointerException("executor");
        } // if

        this.executor = executor;
    }

    /**
     * Returns the underlying {@link Executor} instance this filter uses.
     */
    public Executor getExecutor() {
        return executor;
    }

    private void fireEvent(NextFilter nextFilter, IoSession session,
            EventType type, Object data) {
        executor.execute(new ProcessEventsRunnable(nextFilter, session, type, data));
    }

    /**
     * The type of an event.
     * @author david
     *
     */
    protected static class EventType {
        public static final EventType OPENED = new EventType("OPENED");
        public static final EventType CLOSED = new EventType("CLOSED");
        public static final EventType READ = new EventType("READ");
        public static final EventType WRITTEN = new EventType("WRITTEN");
        public static final EventType RECEIVED = new EventType("RECEIVED");
        public static final EventType SENT = new EventType("SENT");
        public static final EventType IDLE = new EventType("IDLE");
        public static final EventType EXCEPTION = new EventType("EXCEPTION");

        private final String value;

        private EventType(String value) {
            this.value = value;
        }

        public String toString() {
            return value;
        }
    }

    public void sessionCreated(NextFilter nextFilter, IoSession session) {
        nextFilter.sessionCreated(session);
    }

    public void sessionOpened(NextFilter nextFilter, IoSession session) {
        fireEvent(nextFilter, session, EventType.OPENED, null);
    }

    public void sessionClosed(NextFilter nextFilter, IoSession session) {
        fireEvent(nextFilter, session, EventType.CLOSED, null);
    }

    public void sessionIdle(NextFilter nextFilter, IoSession session,
            IdleStatus status) {
        fireEvent(nextFilter, session, EventType.IDLE, status);
    }

    public void exceptionCaught(NextFilter nextFilter, IoSession session,
            Throwable cause) {
        fireEvent(nextFilter, session, EventType.EXCEPTION, cause);
    }

    public void messageReceived(NextFilter nextFilter, IoSession session,
            Object message) {
        fireEvent(nextFilter, session, EventType.RECEIVED, message);
    }

    public void messageSent(NextFilter nextFilter, IoSession session,
            Object message) {
        fireEvent(nextFilter, session, EventType.SENT, message);
    }

    /**
     * Process the event.
     * 
     * @param nextFilter  the next filter
     * @param session  the session instance
     * @param type  the type of the event
     * @param data  the data of the event (could be null for some type of event)
     */
    protected void processEvent(NextFilter nextFilter, IoSession session,
            EventType type, Object data) {
        if (type == EventType.RECEIVED) {
            nextFilter.messageReceived(session, data);
        } else if (type == EventType.SENT) {
            nextFilter.messageSent(session, data);
        } else if (type == EventType.EXCEPTION) {
            nextFilter.exceptionCaught(session, (Throwable) data);
        } else if (type == EventType.IDLE) {
            nextFilter.sessionIdle(session, (IdleStatus) data);
        } else if (type == EventType.OPENED) {
            nextFilter.sessionOpened(session);
        } else if (type == EventType.CLOSED) {
            nextFilter.sessionClosed(session);
        } // else if
    }

    public void filterWrite(NextFilter nextFilter, IoSession session,
            WriteRequest writeRequest) {
        nextFilter.filterWrite(session, writeRequest);
    }

    public void filterClose(NextFilter nextFilter, IoSession session)
            throws Exception {
        nextFilter.filterClose(session);
    }

    private class ProcessEventsRunnable implements Runnable {
        private NextFilter nextFilter;
        private IoSession session;
        private EventType type;
        private Object data;

        ProcessEventsRunnable(NextFilter nextFilter, IoSession session, EventType type, 
                Object data) {
            this.nextFilter = nextFilter;
            this.session = session;
            this.type = type;
            this.data = data;
        }

        public void run() {
            processEvent(nextFilter, session, type, data);
        }
    }
}
