package outpost.cache;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The ICache using jdk's LinkedHashMap.
 * 
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 */
public class HashCache<K, V> implements ICache<K, V> {
    private LinkedHashMap<K, V> map; 
    private int capacity;
    /**
     * The constructor.
     * 
     * @param capacity  the capacity of this cache. When the cache is full,
     *                  the oldest accessed entry will be removed.
     */
    public HashCache(int capacity) {
        this.capacity = capacity;
        map = new LinkedHashMap<K, V>(capacity + 1, 0.75F, true) {
            private static final long serialVersionUID = -8962262856575855860L;

            protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
                return this.size() > HashCache.this.capacity;
            }
        };
    }
    
    public synchronized void clear() {
        map.clear();
    }

    public synchronized V get(K key) {
        return map.get(key);
    }

    public synchronized void invalidate(K key) {
        map.remove(key);
    }

    public synchronized void put(K key, V data) {
        map.put(key, data);
    }
}
