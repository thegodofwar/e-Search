package outpost.cache;

import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;

/**
 * ICache implementation using JCS
 * 
 * @author caowei, David
 *
 * @param <K>  the type of the key
 * 
 */
public class JCSCache<K, V> implements ICache<K, V> {
    public static final String DEFAULT_REGION = "default_region"; 
    
    private JCS jcs = null;
    private String region;

    /**
     * The constructor.
     * @param region  the name of the region for this cach instance
     */
    public JCSCache(String region) {
        this.region = region;
    }

    public String getRegion() {
        return region;
    }
    public void setRegion(String region) {
        this.region = region;
    }
    
    public static void setConfigFilename(String file) {
        JCS.setConfigFilename(file);
    }
    
    /**
     * Initialize the JCSCache
     * 
     * @throws CacheException  if any cache error occurs
     */
    public void init() throws CacheException {
        if(region != null && region.length() != 0)
            jcs = JCS.getInstance(region);
        else
            jcs = JCS.getInstance(DEFAULT_REGION);
    }
    
    public void put(K key, V data) {
        try {
            jcs.put(key, data);
            return;
        } catch (CacheException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public V get(K key) {
        return (V) jcs.get(key);
    }

    public void invalidate(K key) {
        try {
            jcs.remove(key);
        } catch (CacheException e) {
            e.printStackTrace();
        }
    }

    public void clear() {
        try {
            jcs.clear();
        } catch (CacheException e) {
            e.printStackTrace();
        }
    }
}
