package outpost.cache;

import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;

import outpost.cache.ICache;

/**
 * A simple cache implementation use hash table in memory.
 * <p>
 * The implement is simple and can cause memory fragmentation further version
 * may prealloc space for cache
 * 
 * @author caowei
 * @param <Key>
 * @param <Value>
 */
public class HashMapCache<Key, Value> implements ICache<Key, Value> {
    private static final int bucketCount = 10;
    private int maxBucketSize;
    private int currentBucket = 0;
    private ConcurrentHashMap<Key, Value>[] buckets;
    /**
     * Measured in count, default is 50/s
     */
    private int maxObjects = 30000;
    /**
     * Measured in ms, default is 10 min
     */
    private long maxLifeSeconds = 600;
    /**
     * Measured in ms, default is 1 min
     */
    private long updateTime;
    private Timer timer;
    
    public int getMaxObjects() {
        return maxObjects;
    }

    public void setMaxObjects(int maxObjects) {
        this.maxObjects = maxObjects;
    }

    public long getMaxLifeSeconds() {
        return maxLifeSeconds;
    }

    public void setMaxLifeSeconds(long maxLifeSeconds) {
        this.maxLifeSeconds = maxLifeSeconds;
    }

    /**
     * Intialize the cache
     */
    @SuppressWarnings("unchecked")
    public void init() {
        maxBucketSize = maxObjects / bucketCount;
        updateTime = 1000 * (maxLifeSeconds / bucketCount);
        currentBucket = 0;
        // init index
        buckets = new ConcurrentHashMap[bucketCount];
        for (int i = 0; i < bucketCount; i++) {
            buckets[i] = new ConcurrentHashMap<Key, Value>();
        }
        timer = new Timer(true);
        timer.schedule(new java.util.TimerTask() {
            public void run() {
                updateIndex();
            }
        }, updateTime, updateTime);
    }

    private void updateIndex() {
        int nextBucket = (currentBucket + 1) % bucketCount;
        buckets[nextBucket].clear();
        currentBucket = nextBucket;
    }

    public void put(Key key, Value data) {
        if (buckets[currentBucket].size() > maxBucketSize)
            updateIndex();
        buckets[currentBucket].put(key, data);
    }
    
    public Value get(Key key) {
        int stop = currentBucket;
        int start = currentBucket + bucketCount;
        for (; start > stop; start--) {
            if (buckets[start % bucketCount].containsKey(key)) {
                return buckets[start % bucketCount].get(key);
            }
        }
        return null;
    }

    public void invalidate(Key key) {
        int stop = currentBucket;
        int start = currentBucket + bucketCount;
        for (; start > stop; start--) {
            if (buckets[start % bucketCount].containsKey(key)) {
                buckets[start % bucketCount].remove(key);
            }
        }
        return;
    }

    public void clear() {
        for (int i = 0; i < bucketCount; i++)
            buckets[i].clear();
    }
}
