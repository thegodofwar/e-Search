package outpost.cache;

/**
 * The interface of a cache system.
 * 
 * @author caowei, David
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the value
 * 
 */
public interface ICache<K, V> {
    /**
     * Add a key-value pair to the cache
     * 
     * @param key  the key of the pair
     * @param data  the value of the pair
     */
    public void put(K key, V data);
    
    /**
     * Fetch a value from cache
     * @param key  the key of the data to be fetched
     * @return  the value corresponding to the specified key. null if not found.
     */
    public V get(K key);
    
    /**
     * Make a cached item expired
     * 
     * @param key  the key of the pair to be expired
     */
    public void invalidate(K key);
    
    /**
     * Remove all data in the cache
     *
     */
    public void clear();
}