/**
 * @(#)JCSCache.java, 2007-6-10. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package outpost.cache;

import java.io.IOException;
import java.io.Serializable;

import odis.serialize.IWritable;

import org.apache.jcs.access.exception.CacheException;


/**
 *
 * A wrapper of the JCS. The elements of values are IWritable(s)
 * 
 * @author why, David, caowei
 *
 */
public class JCSWritableCache<K, V extends IWritable> implements ICache<K, V> {
        
    JCSCache<K, JCSWritableItem<V>> jcs;
    
    /**
     * Translate IWritable object to Serializable object
     *
     * @author why, David, caowei
     *
     */
    public static class JCSWritableItem<T extends IWritable> 
            implements Serializable {
        private static final long serialVersionUID = -6599975810634639540L;
        
        private T writable;
        //private BlobWritable blob = new BlobWritable();
        private Class<?> writableClass = null;

        /**
         * The default constructor.
         */
        public JCSWritableItem() {
        }
        
        /**
         * The constructor.
         * 
         * @param writable  the writable value 
         * @param writableClass  the writable class
         */
        public JCSWritableItem(T writable, Class<?> writableClass) {
            this.writableClass = writableClass;
            setWritable(writable);
        }
        
        private void writeObject(java.io.ObjectOutputStream out) 
                throws IOException {
            out.writeObject(writableClass);
            writable.writeFields(out);
            //blob.writeFields(out);
        }

        private void readObject(java.io.ObjectInputStream in) 
                throws IOException, ClassNotFoundException {
            Class<?> clazz;
            if (writableClass == null)
                clazz = (Class<?>) in.readObject();
            else
                clazz = writableClass; 
            try {
                writable = (T) clazz.newInstance();
                writable.readFields(in);
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }

        public T getWritable() {
            return writable;
        }

        public void setWritable(T writable) {
            if (writableClass != null && !writable.getClass().equals(writableClass))
                throw new RuntimeException("writableClass was specified to be " +
                        writableClass + ", while an instance of " + 
                        writable.getClass() + " is being set");
            
            this.writable = writable;
        }
    }

    private Class<? extends IWritable> valueClass = null;

    /**
     * The constructor.
     * @param region  the name of the region for this cache instance
     * @throws CacheException  if a cache error occurs
     */
    public JCSWritableCache(String region) 
            throws CacheException {
        this(region, null);
    }
    /**
     * The constructor with a specified value-class.
     * @param region  the name of the region for this cache instance
     * @param valueClass  the class of the value
     */
    public JCSWritableCache(String region, 
            Class<? extends IWritable> valueClass) {
        this.valueClass = valueClass;
        jcs = new JCSCache<K, JCSWritableItem<V>>(region);
    }
    
    /**
     * Initialize the JCSCache
     * 
     * @throws CacheException  if any cache error occurs
     */
    public void init() throws CacheException {
        jcs.init();
    }
    
    public void clear() {
        jcs.clear();
    }

    public V get(K key) {
        return jcs.get(key).getWritable();
    }

    public void invalidate(K key) {
        jcs.invalidate(key);
    }

    public void put(K key, V data) {
        if( valueClass != null)
            jcs.put(key, new JCSWritableItem<V>(data, valueClass));
        else
            jcs.put(key, new JCSWritableItem<V>(data, data.getClass()));
    }
}
