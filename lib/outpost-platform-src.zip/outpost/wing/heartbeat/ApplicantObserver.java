package outpost.wing.heartbeat;

/**
 * 监听Acceptor接收到的applicant连接、心跳、断开消息
 * 
 * @see Acceptor
 * @author caowei
 */
public interface ApplicantObserver {
    /**
     * 当一个applicant连接上时，调用这个函数
     */
    public void applicantConnect(String host, int port, int slice, long version);
    /**
     * 当一个applicant发送心跳时，调用这个函数
     */
    public void applicantHeartbeat(String host, int port, int slice, long version);
    /**
     * 当一个applicant断开时，调用这个函数
     */
    public void applicantDisconnect(String host, int port);
}