package outpost.wing.heartbeat;

/**
 * 一个<code>Applicant</code>可以向多个<code>Acceptor</code>发送
 * heartbeat信息，
 * 
 * @see ListenApplicant
 * @see PollingApplicant
 * 
 * @author caowei
 *
 */
abstract public class Applicant {
    
    /**
     * 初始化函数<p>
     * 添加一个shutdown钩子函数, 当jvm虚拟机关闭时，<code>Applicant</code>可以
     * 完成一些收尾工作，比如向Acceptor发送一条goodbye message。
     */
    public Applicant() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                Applicant.this.stop();
            }
        });
    }
    
    protected int servicePort;

    protected int slice;

    protected long version;

    public int getServicePort() {
        return servicePort;
    }

    public void setServicePort(int servicePort) {
        this.servicePort = servicePort;
    }

    public int getSlice() {
        return slice;
    }

    public void setSlice(int slice) {
        this.slice = slice;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }
    
    /**
     * 启动Applicant
     */
    abstract public void init() throws Exception;
    
    /**
     * 停止Applicant
     */
    abstract public void stop();
}