package outpost.wing.heartbeat.polling;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import org.apache.mina.common.CloseFuture;
import org.apache.mina.common.ConnectFuture;
import org.apache.mina.common.IoConnector;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.RuntimeIOException;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.common.WriteFuture;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.textline.TextLineEncoder;
import org.apache.mina.transport.socket.nio.SocketConnector;

import outpost.wing.heartbeat.Acceptor;
import outpost.wing.heartbeat.ApplicantObserver;
import outpost.wing.heartbeat.HeartbeatInfo;
import outpost.wing.io.protocol.MinaPacket;
import toolbox.misc.LogFormatter;

/**
 * PollingAcceptor和PollingApplicant配套使用。
 * <p>
 * PollingAcceptor定期ping一下PollingApplicant，PollingApplicant被
 * ping之后会返回heartbeat信息。
 * 通讯协议如下：
 * <ul>
 *      <li>PollingAcceptor定期ping一下PollingApplicant，PollingApplicant被
 *      ping之后会返回heartbeat信息。</li>
 *      <li>PollingApplicant会记录下最近ping过它的连接，当PollingApplicant断开时
 *      会向PollingAcceptor发送一条断开消息。</li>
 *      <li>为了减少网络错误可能性，PollingAcceptor断开时会向PollingApplicant
 *      发送goodbye message，这样PollingApplicant就会将其从记录里删掉。</li>
 * </ul>
 * 需要通过构造函数{@link #PollingAcceptor(String[], int[], int)}传入
 * PollingApplicant的地址与端口。
 * 
 * @author caowei
 */
public class PollingAcceptor extends Acceptor{
    public static final Logger LOG = LogFormatter
    .getLogger(PollingAcceptor.class.getName());
    
    /**
     * Applicant name or ip
     */
    protected String[] hosts;
    
    /**
     * Applicant port for ping
     */
    protected int[] ports;
    
    private int applicantNumber;
    
    /**
     * Interval between poolings
     */
    protected int pollingInterval = 1000;
    
    private IoConnector connector;
    
    private Poller[] workers;
    
    /**
     * Add applicant information
     * 
     * @param hosts applicant name list
     * @param ports applicant ping port list
     * @param serverPool
     */
    public PollingAcceptor(String[] hosts, int[] ports, int pollingInterval) {
        assert(hosts.length == ports.length);
        this.applicantNumber = hosts.length;
        this.hosts = hosts;
        this.ports = ports;
        this.pollingInterval = pollingInterval;
        Runtime.getRuntime().addShutdownHook(new ShutdownThread(this));
    }
    
    protected class ShutdownThread extends Thread {
        private Acceptor acceptor;
        public ShutdownThread(Acceptor acceptor) {
            this.acceptor = acceptor;
        }
        public void run() {
            this.acceptor.stop();
        }
    }
    
    /**
     * The message sent is a empty String; the message received is a
     * <code>HeartbeatInfo</code> object
     */
    static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolDecoder getDecoder() throws Exception {
            return MinaPacket.getDecoder();
        }
        public ProtocolEncoder getEncoder() throws Exception {
            return new TextLineEncoder();
        }
    };

    /**
     * Start several threads polling applicants.
     * 
     * @throws IOException 
     */
    public void init() {
        connector = new SocketConnector(8, Executors.newCachedThreadPool());
        connector.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        connector.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(CODEC_FACTORY));
        workers = new Poller[applicantNumber];
        for (int i = 0; i < applicantNumber; i++) {
            workers[i] = new Poller(hosts[i], ports[i]);
            workers[i].start();
        }
    }
    
    /**
     * Stop all threads and connections
     */
    public void stop() {
        for (int i = 0; i < applicantNumber; i++) {
            workers[i].close();
        }
    }
    
    /**
     * Working thread. Try to get a session first, then send applicant a empty
     * message to ask it send back a <code>HeartbeatInfo</code>, which means
     * the applicant is working.
     * 
     * @author caowei
     */
    private class Poller extends Thread {
        boolean alive;
        String host;
        int port;
        IoSession session;
        
        public Poller(String host, int port) {
            this.alive = true;
            this.host = host;
            this.port = port;
        }

        public void run() {
            while (alive) {
                boolean connected = false;
                ConnectFuture conn = null;
                while (alive && !connected) {
                    conn = connector.connect(new InetSocketAddress(host, port),
                            new HeartbeatInfoAcceptorHandler(observer));
                    conn.join();
                    connected = conn.isConnected();
                    if (!connected) {
                        try {
                            Thread.sleep(pollingInterval);
                        } catch (InterruptedException e) {}
                        continue;
                    }
                    try {
                        session = conn.getSession();
                    } catch (RuntimeIOException e) {
                        connected = false;
                        LOG.warning(e.getMessage());
                    }
                }
                LOG.info("connect to " + host + ":" + port + " successfully");

                while (alive && session.isConnected()) {
                    session.write("CaoWeiAiQianQian\n");
                    try {
                        Thread.sleep(pollingInterval);
                    } catch (InterruptedException e) {}
                }
            }
        }
        
        public void close() {
            this.alive = false;
            // wait until current threads stops
            try {
                this.join(2 * pollingInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (session != null && session.isConnected()) {
                WriteFuture writeFuture = session.write("goodbye");
                writeFuture.join();
                CloseFuture closeFuture = session.close();
                closeFuture.join();
            }
        }
    }
    
    /**
     * If a applicant reply, we think it has heartbeat
     * 
     * @author caowei
     *
     */
    private class HeartbeatInfoAcceptorHandler extends IoHandlerAdapter {
        boolean firstTimeConnect;
        ApplicantObserver observer;
        
        public HeartbeatInfoAcceptorHandler(ApplicantObserver observer) {
            this.firstTimeConnect = true;
            this.observer = observer;
        }
        
        public void messageReceived(IoSession session, Object message)
                throws Exception {
            MinaPacket packet = (MinaPacket) message;
            HeartbeatInfo info = (HeartbeatInfo) packet.getMessage();
            byte command = info.command;
            if (command == HeartbeatInfo.COMMAND_CLOSE) {
                firstTimeConnect = true;
                observer.applicantDisconnect(info.host, info.port);
            } else {
                if (firstTimeConnect) {
                    firstTimeConnect = false;
                    observer.applicantConnect(info.host, info.port, info.slice,
                            info.version);
                } else {
                    observer.applicantHeartbeat(info.host, info.port,
                            info.slice, info.version);
                }
            }
        }
        
        public void exceptionCaught(IoSession session, Throwable cause)
        throws Exception {
            LOG.warning(session.toString() + "," + cause.getMessage());
        }
    }
}