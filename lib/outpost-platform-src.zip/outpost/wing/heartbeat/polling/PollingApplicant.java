package outpost.wing.heartbeat.polling;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import org.apache.mina.common.CloseFuture;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.common.WriteFuture;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.textline.TextLineDecoder;
import org.apache.mina.transport.socket.nio.SocketAcceptor;

import outpost.wing.heartbeat.Applicant;
import outpost.wing.heartbeat.HeartbeatInfo;
import outpost.wing.io.protocol.MinaPacket;

import toolbox.misc.LogFormatter;

/**
 * PollingAcceptor和PollingApplicant配套使用。
 * <p>
 * PollingAcceptor定期ping一下PollingApplicant，PollingApplicant被
 * ping之后会返回heartbeat信息。
 * 通讯协议如下：
 * <ul>
 *      <li>PollingAcceptor定期ping一下PollingApplicant，PollingApplicant被
 *      ping之后会返回heartbeat信息。</li>
 *      <li>PollingApplicant会记录下最近ping过它的连接，当PollingApplicant断开时
 *      会向PollingAcceptor发送一条断开消息。</li>
 *      <li>为了减少网络错误可能性，PollingAcceptor断开时会向PollingApplicant
 *      发送goodbye message，这样PollingApplicant就会将其从记录里删掉。</li>
 * </ul>
 * 通过{@link #setListeningPort(int)}设置供PollingAcceptor来ping的端口
 * 
 * @author caowei
 */
public class PollingApplicant extends Applicant{
    public static final Logger LOG = LogFormatter
    .getLogger(PollingApplicant.class.getName());

    /**
     * Listening port
     */
    private int listeningPort;
    
    private SocketAcceptor acceptor;
    
    private HeartbeatInfoApplicantHandler handler;
    
    public int getListeningPort() {
        return listeningPort;
    }

    public void setListeningPort(int port) {
        this.listeningPort = port;
    }

    /**
     * The message received is a empty String; the message sent is a a
     * <code>HeartbeatInfo</code> object
     */
    static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolDecoder getDecoder() throws Exception {
            return new TextLineDecoder();
        }

        public ProtocolEncoder getEncoder() throws Exception {
            return MinaPacket.getEncoder();
        }
    };
    
    /**
     * Start listening
     */
    public void init() throws UnknownHostException, IOException {
        acceptor = new SocketAcceptor(8, Executors.newCachedThreadPool());
        acceptor.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        acceptor.getDefaultConfig().setReuseAddress(true);
        acceptor.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(CODEC_FACTORY));
        handler = new HeartbeatInfoApplicantHandler(InetAddress.getLocalHost()
                .getHostAddress(), servicePort, slice, version);
        acceptor.bind(new InetSocketAddress(listeningPort), handler);
    }
    
    /**
     * Stop listening
     */
    public void stop() {
        handler.close();
        acceptor.unbindAll();
    }
    
    /**
     * Sent back HeartbeatInfo whatever thing received.
     * 
     * @author caowei
     *
     */
    class HeartbeatInfoApplicantHandler extends IoHandlerAdapter {
        public String host;
        public int port;
        Map<IoSession,Long> sessionHistory;
        volatile boolean closed;
        /**
         * volatile type cannot be used a thread-safe counters
         */
        AtomicInteger counter;
        
        public HeartbeatInfoApplicantHandler(String host, int port, int slice,
                long version) {
            this.closed = false;
            this.counter = new AtomicInteger(0);
            this.host = host;
            this.port = port;
            sessionHistory = new HashMap<IoSession, Long>();
        }
        
        /**
         * Because {@link SocketAcceptor#unbindAll()} is called after
         * {@link #close()}, so there is a interval when a new session can be
         * created if Acceptor ask so, close new created session if
         * {@link #closed}} is true.
         */
        public void sessionCreated(IoSession session) throws Exception {
            if( this.closed == false)
                super.sessionCreated(session);
            else
                session.close();
        }

        public void messageReceived(IoSession session, Object message)
                throws Exception {
            if (this.closed == false) {
                try {
                    this.counter.getAndIncrement();
                    if (this.closed == false) {
                        if (session.isConnected())
                            session.write(new MinaPacket(new HeartbeatInfo(
                                    HeartbeatInfo.COMMAND_HEARTBEAT, this.host,
                                    this.port, slice, version, null)));
                        if (((String) message).equals("goodbye")) {
                            sessionHistory.remove(session);
                        } else {
                            if (sessionHistory.containsKey(session))
                                sessionHistory.remove(session);
                            sessionHistory.put(session, System
                                    .currentTimeMillis());
                        }
                    }
                } finally {
                    this.counter.getAndDecrement();
                }
            }
        }
        
        public void close() {
            this.closed = true;
            while (this.counter.get() != 0) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {}
            }
            for (IoSession session: sessionHistory.keySet()) {
                //LOG.info("close session " + session.toString());
                if (session.isConnected()) {
                    WriteFuture writeFuture = session.write(new MinaPacket(
                            new HeartbeatInfo(HeartbeatInfo.COMMAND_CLOSE,
                                    this.host, this.port, slice,
                                    -1, null)));
                    writeFuture.join();
                    //LOG.info("write session " + session.toString());
                    CloseFuture closeFuture = session.close();
                    closeFuture.join();
                    LOG.info("session " + session.toString() + " closed");
                }
            }
            sessionHistory.clear();
        }
    }
}
