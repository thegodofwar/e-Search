package outpost.wing.heartbeat;

/**
 * 一个<code>Acceptor</code>可以接收多个<code>Applicant</code>
 * 发送过来的heartbeat信息,并通知注册的<code>ApplicantObserver</code>。
 * 
 * @see ApplicantObserver
 * @see ListenAcceptor
 * @see PollingAcceptor
 * 
 * @author caowei
 */
abstract public class Acceptor {
    
    protected ApplicantObserver observer;
    
    /**
     * 注册一个<code>ApplicantObserver</code>,Acceptor会
     * 将从Applicant接收到的信息通知给observer
     * @param observer
     */
    public void setObserver(ApplicantObserver observer) {
        this.observer = observer;
    }
    
    /**
     * 在这个函数里实现初始化操作
     */
    abstract public void init() throws Exception;
    
    /**
     * 在这个函数里实现结束操作
     */
    abstract public void stop();
}