package outpost.wing.heartbeat.listen;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.textline.TextLineEncoder;
import org.apache.mina.transport.socket.nio.SocketAcceptor;

import outpost.wing.heartbeat.Acceptor;
import outpost.wing.heartbeat.ApplicantObserver;
import outpost.wing.heartbeat.HeartbeatInfo;
import outpost.wing.io.protocol.MinaPacket;

import toolbox.misc.LogFormatter;

/**
 * ListenAcceptor与ListenApplicant配套使用。
 * <p>
 * ListenAcceptor监听某个端口，ListenApplicant则定期向这个端口发送heartbeat消息。
 * 它们之间的协议如下：
 * <li>
 *      <ul>ListenApplicant初次连接一个ListenAcceptor，向其发送一条连接命令，
 *      直到连接成功为止</ul>
 *      <ul>ListenApplicant其后都是向这个ListenAcceptor发送心跳命令</ul>
 *      <ul>ListenApplicant被停止时，会向ListenAcceptor发送断开命令</ul>
 * </li>
 * 你需要通过构造函数传入ListenAcceptor所要监听的端口
 * 
 * @author caowei
 */
public class ListenAcceptor extends Acceptor {
    @SuppressWarnings("unused")
    private static final Logger LOG = LogFormatter
            .getLogger(ListenAcceptor.class.getName());

    protected int listeningPort;

    private SocketAcceptor acceptor;

    /**
     * 初始化函数
     *
     * @param listeningPort ListenAcceptor所要监听的端口
     */
    public ListenAcceptor(int listeningPort) {
        this.listeningPort = listeningPort;
    }

    /**
     * Receive <code>HeartbeatInfo</code>; nothing send back
     */
    protected static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolDecoder getDecoder() throws Exception {
            return MinaPacket.getDecoder();
        }

        public ProtocolEncoder getEncoder() throws Exception {
            return new TextLineEncoder();
        }
    };

    protected class HeartbeatInfoAcceptorHandler extends IoHandlerAdapter {
        ApplicantObserver observer;

        public HeartbeatInfoAcceptorHandler(ApplicantObserver observer) {
            this.observer = observer;
        }

        public void messageReceived(IoSession session, Object message)
                throws Exception {
            MinaPacket packet = (MinaPacket) message;
            HeartbeatInfo info = (HeartbeatInfo) packet.getMessage();
            byte command = info.command;
            if (command == HeartbeatInfo.COMMAND_CLOSE) {
                observer.applicantDisconnect(info.host, info.port);
            } else if (command == HeartbeatInfo.COMMAND_CONNECT) {
                observer.applicantConnect(info.host, info.port, info.slice,
                        info.version);
            } else if (command == HeartbeatInfo.COMMAND_HEARTBEAT){
                observer.applicantHeartbeat(info.host, info.port, info.slice,
                        info.version);
            }
        }
    }
    
    @Override
    public void init() throws UnknownHostException, IOException {
        acceptor = new SocketAcceptor(8, Executors.newCachedThreadPool());
        acceptor.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        acceptor.getDefaultConfig().setReuseAddress(true);
        acceptor.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(CODEC_FACTORY));
        acceptor.bind(new InetSocketAddress(listeningPort),
                new HeartbeatInfoAcceptorHandler(observer));
    }

    @Override
    public void stop() {
        acceptor.unbindAll();
    }

}
