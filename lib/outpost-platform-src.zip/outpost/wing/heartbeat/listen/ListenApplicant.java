package outpost.wing.heartbeat.listen;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import org.apache.mina.common.CloseFuture;
import org.apache.mina.common.ConnectFuture;
import org.apache.mina.common.IoConnector;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.RuntimeIOException;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.common.WriteFuture;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.textline.TextLineDecoder;
import org.apache.mina.transport.socket.nio.SocketConnector;

import outpost.wing.heartbeat.Applicant;
import outpost.wing.heartbeat.HeartbeatInfo;
import outpost.wing.io.protocol.MinaPacket;

import toolbox.misc.LogFormatter;


/**
 * ListenAcceptor与ListenApplicant配套使用。
 * <p>
 * ListenAcceptor监听某个端口，ListenApplicant则定期向这个端口发送heartbeat消息。
 * 它们之间的协议如下：
 * <ul>
 *      <li>ListenApplicant初次连接一个ListenAcceptor，向其发送一条连接命令，
 *      直到连接成功为止</li>
 *      <li>ListenApplicant其后都是向这个ListenAcceptor发送心跳命令</li>
 *      <li>ListenApplicant被停止时，会向ListenAcceptor发送断开命令</li>
 * </ul>
 * 需要通过{@link #setHosts(String[])}和{@link #setPorts(int[])}设置一组
 * ListenApplicant的地址
 * 
 * @author caowei
 */
public class ListenApplicant extends Applicant {
    public static final Logger LOG = LogFormatter
            .getLogger(ListenApplicant.class.getName());

    protected int heartBeatInterval = 3000;

    protected String[] hosts;

    protected int[] ports;

    private int acceptorNubmer;

    private IoConnector connector;

    private Worker[] workers;

    public int getHeartBeatInterval() {
        return heartBeatInterval;
    }

    public void setHeartBeatInterval(int heartBeatInterval) {
        this.heartBeatInterval = heartBeatInterval;
    }

    public String[] getHosts() {
        return hosts;
    }

    public void setHosts(String[] hosts) {
        this.hosts = hosts;
    }

    public int[] getPorts() {
        return ports;
    }

    public void setPorts(int[] ports) {
        this.ports = ports;
    }

    /**
     * Send <code>HeartbeatInfo</code>; never receive
     */
    static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolDecoder getDecoder() throws Exception {
            return new TextLineDecoder();
        }

        public ProtocolEncoder getEncoder() throws Exception {
            return MinaPacket.getEncoder();
        }
    };

    /**
     * Start threads and connections
     */
    public void init() {
        assert(hosts.length == ports.length);
        acceptorNubmer = hosts.length;
        connector = new SocketConnector(8, Executors.newCachedThreadPool());
        connector.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        connector.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(CODEC_FACTORY));
        workers = new Worker[acceptorNubmer];
        for (int i = 0; i < acceptorNubmer; i++) {
            workers[i] = new Worker(hosts[i], ports[i]);
            workers[i].start();
        }
    }

    /**
     * Stop all threads, close sessions, and send goodbye message to all
     * acceptors.
     */
    public void stop() {
        for (int i = 0; i < acceptorNubmer; i++) {
            workers[i].close();
        }
    }

    /**
     * Working thread. Try to get a session first, then send acceptor a
     * <code>HeartbeatInfo</code> message again and again until closed.
     * 
     * @author caowei
     */
    private class Worker extends Thread {
        boolean alive;
        String host;
        int port;
        IoSession heartbeatSession;

        public Worker(String host, int port) {
            this.alive = true;
            this.host = host;
            this.port = port;
        }

        public void run() {
            IoHandlerAdapter handler = new IoHandlerAdapter() {
                public void sessionClosed(IoSession session) 
                        throws Exception {
                    LOG.info("Heartbeat session closed!");
                }
                public void exceptionCaught(IoSession session, Throwable cause)
                throws Exception {
                    LOG.warning(cause.getMessage());
                }
            };
            
            while (this.alive) {
                boolean connected = false;
                ConnectFuture conn = null;
                LOG.info("try to connect " + this.host + ":" + this.port
                        + " for heartbeat");

                while (this.alive && !connected) {
                    conn = connector.connect(new InetSocketAddress(this.host,
                            this.port), handler);
                    conn.join();
                    connected = conn.isConnected();
                    if (!connected) {
                        try {
                            Thread.sleep(heartBeatInterval);
                        } catch (InterruptedException e) {}
                        continue;
                    }
                    try {
                        heartbeatSession = conn.getSession();
                    } catch (RuntimeIOException e) {
                        connected = false;
                        LOG.warning(e.getMessage());
                    }
                }
                LOG.info("successfully connect " + this.host + ":" + this.port
                        + " for heartbeat");

                String localhost = null;
                while (localhost == null) {
                    try {
                        localhost = InetAddress.getLocalHost().getHostAddress();
                    } catch (UnknownHostException e) {
                        localhost = null;
                        e.printStackTrace();
                    }
                }

                connected = false;
                while (connected == false) {
                    WriteFuture writeFuture = heartbeatSession
                            .write(new MinaPacket(new HeartbeatInfo(
                                    HeartbeatInfo.COMMAND_CONNECT, localhost,
                                    servicePort, slice, version, null)));
                    writeFuture.join();
                    connected = writeFuture.isWritten();
                    try {
                        Thread.sleep(heartBeatInterval);
                    } catch (InterruptedException e) {}
                }

                while (this.alive && heartbeatSession.isConnected()) {
                    heartbeatSession.write(new MinaPacket(new HeartbeatInfo(
                            HeartbeatInfo.COMMAND_HEARTBEAT, localhost,
                            servicePort, slice, version, null)));
                    try {
                        Thread.sleep(heartBeatInterval);
                    } catch (InterruptedException e) {}
                }
            }
        }

        /**
         * Stop a worker.
         * <p>
         * <ul>
         * <li>step 1: wait until the thread stop running</li>
         * <li>step 2: write a goodbye message to acceptor</li>
         * <li>step 3: close the session</li>
         * </ul>
         * 
         * @throws InterruptedException
         */
        public void close() {
            this.alive = false;
            // wait until current threads stops
            try {
                this.join(2 * heartBeatInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // write a close message to acceptor if connected
            if (heartbeatSession != null) {
                String localhost = null;
                try {
                    localhost = InetAddress.getLocalHost().getHostAddress();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }

                WriteFuture writeFuture = heartbeatSession
                        .write(new MinaPacket(new HeartbeatInfo(
                                HeartbeatInfo.COMMAND_CLOSE, localhost,
                                servicePort, slice, -1, null)));
                // wait until nio finished
                writeFuture.join();

                CloseFuture closeFuture = heartbeatSession.close();
                closeFuture.join();
            }
        }
    }
}
