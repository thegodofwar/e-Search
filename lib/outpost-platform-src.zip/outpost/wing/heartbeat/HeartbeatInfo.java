package outpost.wing.heartbeat;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.logging.Logger;

import odis.serialize.IWritable;
import odis.serialize.lib.UTF8Writable;

import toolbox.misc.LogFormatter;

/**
 * Applicant发送给Acceptor的heartbeat信息
 * 
 * @author caowei
 */
public class HeartbeatInfo implements IWritable{
    
    public static final Logger LOG = LogFormatter
    .getLogger(HeartbeatInfo.class.getName());

    /**
     * 连接命令
     */
    public static final byte COMMAND_CONNECT = (byte) 0xf0;
    /**
     * 心跳命令
     */
    public static final byte COMMAND_HEARTBEAT = (byte) 0xf1;
    /**
     * 断开命令
     */
    public static final byte COMMAND_CLOSE = (byte)0xff;
    /**
     * 命令类型
     */
    public byte command;
    /**
     * Applicant's host
     */
    public String host;
    /**
     * Applicant's port
     */
    public int port;
    /**
     * Applicant's slice ID
     */
    public int slice;
    /**
     * Applicant's version
     */
    public long version;
    /**
     * Application specific data
     */
    public byte[] content;
    
    private static byte[] EMPTY_CONTENT = new byte[0];
    
    /**
     * 此构造函数用于<code>MinaPacket</code>解码时生成对象
     */
    public HeartbeatInfo() {}
    
    /**
     * 初始化函数
     */
    public HeartbeatInfo(byte command, String host, int port, int slice,
            long version, byte[] content) {
        this.command = command;
        this.host = host;
        this.port = port;
        this.slice = slice;
        this.version = version;
        if (content == null)
            this.content = this.EMPTY_CONTENT;
        else
            this.content = content;
    }
    
    public void readFields(DataInput in)  throws IOException{
        try {
            command = in.readByte();
            host = UTF8Writable.readString(in);
            port = in.readInt();
            slice = in.readInt();
            version = in.readLong();
            int contentLength = in.readInt();
            byte[] content = new byte[contentLength];
            for( int i=0; i<contentLength; i++)
                content[i] = in.readByte();
        } catch (Exception e) {
            LOG.severe("HeartbeatMessage readFields fail for "
                    + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void writeFields(DataOutput out) throws IOException{
        try {
            out.writeByte(command);
            UTF8Writable.writeString(out, host);
            out.writeInt(port);
            out.writeInt(slice);
            out.writeLong(version);
            out.writeInt(content.length);
            for( int i=0; i<content.length; i++)
                out.writeByte(content[i]);
        } catch (Exception e) {
            LOG.severe("HeartbeatMessage writeFields fail for "
                    + e.getMessage());
            e.printStackTrace();
        }
    }

    public IWritable copyFields(IWritable value) {
        return null;
    }
}
