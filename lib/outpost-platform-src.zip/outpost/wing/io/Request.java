package outpost.wing.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * host node发送给service node的查询请求
 * 
 * @author caowei
 * @see {@link outpost.wing.io.protocol.MinaPacket}
 */
public class Request implements IWritable {
    
    protected int serial;
    
    protected DataBufferWritable body;
    
    /**
     * 此构造函数用于<code>MinaPacket</code>解码时生成对象
     */
    public Request() {}
    
    /**
     * 初始化函数
     * @param body 请求内容数据
     * @param serial 请求的序号
     */
    public Request(DataBufferWritable body, int serial) {
        this.body = body;
        this.serial = serial;
    }

    public IWritable getBody() {
        return body;
    }

    public int getSerial() {
        return serial;
    }
    
    public String toString() {
        return new String("Request#" + serial);
    }

    public void readFields(DataInput in) throws IOException {
        this.serial = in.readInt();
        this.body = new DataBufferWritable();
        this.body.readFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(serial);
        body.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        Request that = (Request) value;
        this.serial = that.serial;
        this.body = new DataBufferWritable();
        this.body.copyFields(that.body);
        return this;
    }
}