package outpost.wing.io.protocol;

import java.util.logging.Logger;

import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.CumulativeProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;

import toolbox.misc.LogFormatter;

/**
 * 这个类用于简化使用mina发送、接收数据包时需要对Encoder、Decoder进行编程的负担，
 * 你只需要编写一个<code>IWritable</code>类型即可。<code>MinaPackt</code>
 * 会帮助你完成这个<code>IWritable</code>与{@link org.apache.mina.common.ByteBuffer}
 * 之间的转换过程。
 * <p>
 * 使用示例:
 * <p>
 * 发送一个IWritable对象，比如说是UTF8Writable
 * <pre>
 * IoSession s = ...;//这是你获取到的mina的IoSession对象
 * 
 * // UTF8Writable可以替换成你的IWritable对像
 * IWritable message = new UTF8Writable("hello world"); 
 * MinaPacket packet = new MinaPacket(message);
 * s.write(packet);
 * </pre>
 * <p>
 * 接收一个IWritable对象，比如说是UTF8Writable
 * <p>
 * <pre>
 * // 这是你实现的mina的IoHandler里的messageReceived钩子函数，
 * // 当接收到消息时，这个函数会被调用
 * public void messageReceived(IoSession session, Object message)
 *     throws Exception {
 *     MinaPacket packet = (MinaPacket) message;
 *     // UTF8Writable可以替换成你的IWritable对像
 *     UTF8Writable message = (UTF8Writable) packet.getMessage();
 *     System.out.println(message.get());
 * }
 * </pre>
 * <p>
 * <b>注意：</b>你实现的IWritable类型需要包含一个空的构造函数
 * <p>
 * 发送消息的Encoder为{@link MinaPacket#getEncoder()}}，收取消息的Decoder为
 * {@link MinaPacket#getDecoder()}。
 * 
 * @author caowei
 *
 */
public class MinaPacket {
    
    public static final Logger LOG = LogFormatter
    .getLogger(MinaPacket.class.getName());

    protected static final long MAGIC_NUMBER = 0xababcdcd;

    protected IWritable content;
    
    /**
     * 设置IWritale类型的消息
     */
    public MinaPacket(IWritable content) {
        this.content = content;
    }
    
    /**
     * 获取IWritable类型的消息
     */
    public IWritable getMessage() {
        return content;
    }
    
    public String toString() {
        return content.toString();
    }

    private static class MinaPacketEncoder implements ProtocolEncoder {

        public void dispose(IoSession session) throws Exception {}

        public void encode(IoSession session, Object message,
                ProtocolEncoderOutput out) throws Exception {
            MinaPacket packet = (MinaPacket) message;

            byte[] writableClassTypeBuffer = null;
            try {
                String writableClassType = packet.content.getClass().getName();
                writableClassTypeBuffer = writableClassType.getBytes("utf-8");
            } catch (Exception e) {
                LOG.severe("serialize IWritable Object fail for "
                        + e.getMessage());
                e.printStackTrace();
            }

            DataOutputBuffer contentBuffer = new DataOutputBuffer();
            packet.content.writeFields(contentBuffer);

            ByteBuffer byteBuf = ByteBuffer.allocate(8 + 4
                    + writableClassTypeBuffer.length + 4
                    + contentBuffer.size(), false);
            byteBuf.putLong(MinaPacket.MAGIC_NUMBER);
            byteBuf.putInt(writableClassTypeBuffer.length);
            byteBuf.put(writableClassTypeBuffer);
            byteBuf.putInt(contentBuffer.size());
            byteBuf.put(contentBuffer.getData(), 0 ,contentBuffer.size());
            byteBuf.flip();
            out.write(byteBuf);
        }
    }

    private static class MinaPacketDecoder extends CumulativeProtocolDecoder {

        @Override
        protected boolean doDecode(IoSession session, ByteBuffer in,
                ProtocolDecoderOutput out) throws Exception {
            if (in.remaining() < (8 + 4 + 4))
                return false;
            int orgPos = in.position();
            
            long magic = in.getLong();
            if (magic != MinaPacket.MAGIC_NUMBER) {
                LOG.severe("Failed to parse heartbeat information"
                        + " due to bad magic number");
                session.close();
                return false;
            }
            
            int writableClassTypeLength = in.getInt();
            if(in.remaining() < writableClassTypeLength + 4) {
                in.position(orgPos);
                return false;
            }
            byte[] writableClassType = new byte[writableClassTypeLength];
            in.get(writableClassType);
            
            int contentBufferLength = in.getInt();
            if (in.remaining() < contentBufferLength) {
                in.position(orgPos);
                return false;
            }
            byte[] contentBuffer = new byte[contentBufferLength];
            in.get(contentBuffer);
            
            IWritable content = null;
            try {
                String messageClassType = new String(writableClassType,"utf-8");
                content = (IWritable) Class.forName(messageClassType)
                        .newInstance();
                DataInputBuffer dataBuffer = new DataInputBuffer(
                        contentBuffer, 0, contentBuffer.length);
                content.readFields(dataBuffer);
            } catch (Exception e) {
                LOG.severe("instantiate IWritable Object fail for "
                        + e.getMessage());
                e.printStackTrace();
                session.close();
            }
            
            MinaPacket packet = new MinaPacket(content);
            out.write(packet);
            return true;
        }
    }
    
    private static MinaPacketEncoder MINAPACKET_ENCODER =
        new MinaPacketEncoder(); 
    
    private static MinaPacketDecoder MINAPACKET_DECODER =
        new MinaPacketDecoder(); 
    
    /**
     * 获取发送消息类型的mina的Encoder
     */
    public static ProtocolEncoder getEncoder() {
        return MINAPACKET_ENCODER;
    }
    /**
     * 获取收取消息类型的mina的Decoder
     */
    public static ProtocolDecoder getDecoder() {
        return MINAPACKET_DECODER;
    }

}
