package outpost.wing.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.serialize.IWritable;

/**
 * service node对host node查询请求的应答
 * 
 * @author caowei
 * @see {@link outpost.wing.io.protocol.MinaPacket}
 */
public class Response implements IWritable {
    
    public static final int RT_OK = 1;

    public static final int RT_EXCEPTION = 2;
    
    public static final int RT_OVER_LOAD = 3;
    
    public static final int RT_TIME_OUT = 4;

    protected int serial;

    protected int status;

    protected DataBufferWritable body;
    
    /**
     * 此构造函数用于<code>MinaPacket</code>解码时生成对象
     */
    public Response() {}
    
    /**
     * 初始化函数
     * @param body 响应内容数据
     * @param serial 请求的序号
     * @param status 响应的状态
     */
    public Response(DataBufferWritable body, int serial, int status) {
        this.body = body;
        this.serial = serial;
        this.status = status;
    }

    public DataBufferWritable getBuffer() {
        return body;
    }

    public int getSerial() {
        return serial;
    }

    public int getStatus() {
        return status;
    }

    public void readFields(DataInput in) throws IOException {
        this.serial = in.readInt();
        this.status = in.readInt();
        this.body = new DataBufferWritable();
        this.body.readFields(in);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(serial);
        out.writeInt(status);
        body.writeFields(out);
    }

    public IWritable copyFields(IWritable value) {
        Response that = (Response) value;
        this.serial = that.serial;
        this.status = that.status;
        this.body = new DataBufferWritable();
        this.body.copyFields(that.body);
        return this;
    }
    
}
