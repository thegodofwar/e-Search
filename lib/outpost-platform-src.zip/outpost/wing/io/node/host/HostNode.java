package outpost.wing.io.node.host;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import outpost.wing.io.DataBufferWritable;
import outpost.wing.io.Request;
import outpost.wing.io.Response;
import toolbox.misc.LogFormatter;

/**
 * 使用<code>HostNode</code>可以一次向多个提供同一类型服务的service node发送请求
 * 并接收来自它们返回的数据。Service Node提供具体的服务，比如提供搜索结果的服务、或者
 * 提供summary的服务。出于多种原因，比如数据量大或者访问量大，会将同一种服务分布到多个
 * service node上，而<code>HostNode</code>就提供了分布式的发送请求/接收响应功能层。
 * <p>
 * 提供同种服务的service node被划分到不同的slice来进行区分。使用slice进行区分的一个
 * 典型例子就是当服务使用的数据量很大时，把数据分割为多份，每个slice分配到的都是不同的
 * 数据。一个slice上可以有多个service node，提供备份、或者是分担压力。
 * <p>
 * <code>HostNode</code>目前提供两种类型的发送/接收调用：
 * <ul>
 *   <li>对于所有slice，为每个slice选择一个service node，向它们群发同一条请求，
 *   并等待请求返回结果。见{@link #sendToAllSlices(DataBufferWritable, IoError)}。
 *   </li>
 *   <li>给定一组slice以及要发送到每个slice上的数据，为每个slice选择一个service node
 *   并向其发送请求，并等待请求返回结果。
 *   见{@link #sendToSomeSlices(DataBufferWritable[], int[], IoError)}。
 *   </li>
 * </ul>
 * 对于每种调用，要发送的数据都以<code>DataBufferWritable</code>对象的形式传入，
 * 返回给调用者的则是一个<code>DataBufferWritable</code>数组，数组的元素则是从各个
 * service node接收到的数据。
 * <p>
 * 调用还返回一个<code>IoError</code>对象，这个对象包含host node与service node进行
 * 分布式发送请求/接收响应操作时发生的错误，见{@link IoError}。
 * <p>
 * 
 * @see DataBufferWritable
 * @see IoError
 * 
 * @author caowei
 */
public class HostNode implements NodeEventHandler{

    public static final Logger LOG = LogFormatter
            .getLogger(HostNode.class.getName());

    private String nodeName = "unknown host";
    
    private ServiceNodeTable nodeTable;

    private int workThreadTimeOut = 5000;

    /**
     * keep intermediate data of each query
     */
    private class SerialRelatedData {

        public int serial;

        /**
         * used to wake up thread waiting the result of query #serial
         */
        public Semaphore sem;

        /**
         * used to record local servers that related with query #serial
         */
        public ArrayList<ServiceNodeProxy> sent;
        
        public int sentCount;
        /**
         * used to record local servers that response query #serial
         */
        public ArrayList<ServiceNodeProxy> succ;
        
        public ArrayList<ServiceNodeProxy> fail;
        
        public ArrayList<ServiceNodeProxy> timeout;
        
        public ArrayList<ServiceNodeProxy> closed;

        /**
         * used to record results
         */
        public ArrayList<DataBufferWritable> resultCollected;
        /**
         * gotCount may be less than results number in resultGot,
         * for some local servers may only return a failure message.
         */
        public volatile int gotCount;
        
        public SerialRelatedData(int serial) {
            this.serial = serial;
            sem = new Semaphore(0);
            sent = new ArrayList<ServiceNodeProxy>();
            sentCount = 0;
            succ = new ArrayList<ServiceNodeProxy>();
            fail = new ArrayList<ServiceNodeProxy>();
            timeout = new ArrayList<ServiceNodeProxy>();
            closed = new ArrayList<ServiceNodeProxy>();
            resultCollected = new ArrayList<DataBufferWritable>();
        }
    }

    private Map<Integer, SerialRelatedData> serialMap;

    /**
     * 初始化各种管理结构及线程
     */
    @SuppressWarnings("unchecked")
    public void init() {
        serialMap = new ConcurrentHashMap<Integer, SerialRelatedData>();
    }
    
    public ServiceNodeTable getNodeTable() {
        return nodeTable;
    }
    
    public void setNodeTable(ServiceNodeTable nodeTable) {
        this.nodeTable = nodeTable;
    }

    public String getPoolName() {
        return nodeName;
    }

    public void setPoolName(String poolName) {
        this.nodeName = poolName;
    }

    public int getWaitTimeOut() {
        return workThreadTimeOut;
    }

    public void setWaitTimeOut(int waitTimeOut) {
        this.workThreadTimeOut = waitTimeOut;
    }

    private Integer sequenceNumber = new Integer(0);

    // generate a serial number
    // the serial number should be distinct on a machine
    private int generateSerial() {
        int serial;

        synchronized (sequenceNumber) {
            // serial = (int) (System.currentTimeMillis() & Integer.MAX_VALUE) +
            // timeLock;
            serial = sequenceNumber++;
        }

        return serial;
    }

    /**
     * 对于所有slice，为每个slice选择一个service node，向它们群发同一条请求，
     * 并等待请求返回结果
     */
    public DataBufferWritable[] sendToAllSlices(DataBufferWritable obuf,
            IoError error) {
        int serial = generateSerial();

        LOG.info(getPoolName() + " send and receive: " + serial);

        SerialRelatedData serialData = new SerialRelatedData(serial);
        serialMap.put(serial, serialData);

        boolean isSucc = sendQuery(serialData, obuf, error);
        if (!isSucc) {
            error.setErrno(IoError.ERRNO_NONODE);
            serialMap.remove(serial);
            return new DataBufferWritable[0];
        }

        boolean isInterupted = false;

        long startTiming = System.currentTimeMillis();

        do {
            try {
                serialData.sem.tryAcquire(workThreadTimeOut, TimeUnit.MILLISECONDS);
                isInterupted = false;
            } catch (InterruptedException e) {

                // to be sure sem is released by frameTask
                serialData.sem.release();
                isInterupted = true;
            }
        } while (isInterupted);
        
        long stopTiming = System.currentTimeMillis();
        long takingTime = stopTiming - startTiming;
        LOG.info(getPoolName() + " query " + serial + " use " + takingTime
                + " ms");

        serialMap.remove(serial);
        DataBufferWritable[] bufs = collectResult(serialData, error);

        return bufs;
    }

    /**
     * 给定一组slice以及要发送到每个slice上的数据，为每个slice选择一个service node
     * 并向其发送请求，并等待请求返回结果。
     */
    public DataBufferWritable[] sendToSomeSlices(DataBufferWritable[] obufs,
            int[] indexSlices, IoError error) {
        int serial = generateSerial();

        LOG.info(getPoolName() + " send and receive: " + serial);

        SerialRelatedData serialData = new SerialRelatedData(serial);
        serialMap.put(serial, serialData);

        boolean isSucc = sendQuery(serialData, obufs, indexSlices, error);
        if (isSucc == false) {
            error.setErrno(IoError.ERRNO_NONODE);
            serialMap.remove(serial);
            return new DataBufferWritable[0];
        }

        boolean isInterupted = false;

        long startTiming = System.currentTimeMillis();

        do {
            try {
                serialData.sem.tryAcquire(workThreadTimeOut, TimeUnit.MILLISECONDS);
                isInterupted = false;
            } catch (InterruptedException e) {

                // to be sure sem is released by frameTask
                serialData.sem.release();
                isInterupted = true;
            }
        } while (isInterupted);

        long stopTiming = System.currentTimeMillis();
        long takingTime = stopTiming - startTiming;
        LOG.info(getPoolName() + " query " + serial + " use " + takingTime
                + " ms");

        // there should be only one entry
        serialMap.remove(serial);
        DataBufferWritable[] bufs = collectResult(serialData, error);

        return bufs;
    }

    /**
     * 使用RR策略
     */
    protected ServiceNodeProxy selectBestNode(int serial,
            ServiceNodeProxy[] nodes) {
        return nodes[serial % nodes.length];
    }

    // non-block
    // broadcast
    private boolean sendQuery(SerialRelatedData serialData,
            DataBufferWritable obuf, IoError error) {

        // check
        if (nodeTable.getSliceCount() == 0) {
            LOG.warning(getPoolName()
                    + " no active server, return with no result");
            return false;
        }
        
        int[] slices = nodeTable.getSlices();
        for (int slice: slices) {
            ServiceNodeProxy[] nodes = nodeTable.getNodes(slice);
            if (nodes.length == 0)
                continue;
            ServiceNodeProxy node = selectBestNode(serialData.serial, nodes);
            if (node.isActive()) {
                serialData.sent.add(node);
                serialData.sentCount++;
            }
        }

        // check
        if (serialData.sentCount == 0) {
            LOG.warning(getPoolName()
                    + " no active server, return with no result");
            return false;
        }
        
        Request r = new Request(obuf, serialData.serial);
        for (int i = 0; i < serialData.sentCount; i++) {
            serialData.sent.get(i).write(r, workThreadTimeOut, this);
        }
        return true;
    }

    // non-block send
    // unicast
    private boolean sendQuery(SerialRelatedData serialData,
            DataBufferWritable[] obufs, int[] indexSlices,
            IoError error) {

        // check
        if (indexSlices.length != obufs.length || indexSlices.length == 0)
            return false;
        
        for (int i = 0, oldIndex = 0; i < indexSlices.length; i++) {
            if (obufs[i] == null || obufs[i].size() == 0) {
                continue;
            }
            ServiceNodeProxy[] nodes = nodeTable.getNodes(indexSlices[i]);
            // there may be unrecognized sliceId
            if (nodes.length == 0) {
                continue;
            }
            ServiceNodeProxy node = selectBestNode(serialData.serial, nodes);
            if (node.isActive()) {
                serialData.sent.add(node);
                serialData.sentCount++;
            }
            if (i > oldIndex)
                obufs[oldIndex] = obufs[i];
            oldIndex++;
        }

        // check
        if (serialData.sentCount == 0) {
            LOG.warning(getPoolName()
                    + " no active server, return with no result");
            return false;
        }

        for (int i = 0; i < serialData.sentCount; i++) {
            Request r = new Request(obufs[i], serialData.serial);
            serialData.sent.get(i).write(r, workThreadTimeOut, this);
        }

        return true;
    }
    
    private DataBufferWritable[] collectResult(SerialRelatedData serialData,
            IoError error) {
        if (serialData == null)
            return new DataBufferWritable[0];

        synchronized (serialData) {

            // this should be occasional case
            // so much more steps perfomed here will not slow down system
            if (serialData.succ.size() < serialData.sentCount) {
                LOG.warning(getPoolName() + " some node error, expected "
                        + serialData.sentCount + " results , only received "
                        + serialData.succ.size() + " results, serial#"
                        + serialData.serial);

                if (error != null) {
                    if(serialData.succ.size() == 0)
                        error.setErrno(IoError.ERRNO_NONE);
                    else
                        error.setErrno(IoError.ERRNO_INCOMPLETE);
                }

                // check node
                for (int i = 0; i < serialData.sent.size(); i++) {
                    ServiceNodeProxy node = serialData.sent.get(i);
                    if (serialData.succ.contains(node)) {
                        //成功返回
                        continue;
                    } else if (serialData.fail.contains(node)) {
                        //node处理错误
                        if(error != null )
                            error.addNodeErrorDetail(node.toString(), IoError.NODE_ERROR_CODE_RETURN);
                    } else if( serialData.closed.contains(node)) {
                        //发生exception
                        if(error != null )
                            error.addNodeErrorDetail(node.toString(), IoError.NODE_CONNECTION_DOWN);
                    } else {
                        //超时
                        if (error != null)
                            error.addNodeErrorDetail(node.toString(), IoError.NODE_TIME_OUT);
                    }
                }
            } else {
                if( error != null)
                    error.setErrno(IoError.ERRNO_COMPLETE);
            }
            return (DataBufferWritable[]) serialData.resultCollected
                    .toArray(new DataBufferWritable[serialData.resultCollected.size()]);
        }
    }
    
    /**
     * 当node发送一条序号为serial的请求出去时，这个hook函数被调用
     */
    public void requestSent(ServiceNodeProxy node, int serial) {}
    
    /**
     * 当node发现序号为serial的请求响应超时，这个hook函数被调用。
     */
    public void requestTimeout(ServiceNodeProxy node, int serial) {
        SerialRelatedData serialData = (SerialRelatedData) serialMap
                .get(serial);
        if (serialData == null)
            return;

        LOG.info(getPoolName() + " " + node.toString()
                + ", serial#" + serial + " timeout");

        // several results may reach at the same time
        // so serialization is needed so that only the last returned
        // result will cause the waiting thread be waked up
        synchronized (serialData) {
            serialData.timeout.add(node);
            ++serialData.gotCount;

            // all results are returned from node, wake up wating thread
            if (serialData.gotCount == serialData.sentCount) {
                LOG.info(getPoolName()
                        + " wake up the thread waiting for serial#" + serial
                        + ", " + serialData.sentCount + " results got");
                serialData.sem.release();
            }
        }
    }
    
    /**
     * 当node接收到序号为serial的请求的响应结果时，这个hook函数被调用。
     */
    public void responseReceived(ServiceNodeProxy node, int serial, int status,
            DataBufferWritable result) {
        
        SerialRelatedData serialData = (SerialRelatedData) serialMap
                .get(serial);
        if (serialData == null)
            return;

        LOG.info(getPoolName() + " " + node.toString()
                + ", serial#" + serial + " return result");

        // several results may reach at the same time
        // so serialization is needed so that only the last returned
        // result will cause the waiting thread be waked up
        synchronized (serialData) {
            // add result into resultRecordTable
            if( status == Response.RT_OK) {
                serialData.resultCollected.add(result);
                serialData.succ.add(node);
            } else
                serialData.fail.add(node);
            
            ++serialData.gotCount;

            // all results are returned from node, wake up wating thread
            if (serialData.gotCount == serialData.sentCount) {
                LOG.info(getPoolName()
                        + " wake up the thread waiting for serial#" + serial
                        + ", " + serialData.sentCount + " results got");

                serialData.sem.release();
            }
        }
    }
    
    /**
     * 当node发现连接中断时，这个hook函数被调用。
     */
    public void connectionDown(ServiceNodeProxy node, int serial) {

        SerialRelatedData serialData = (SerialRelatedData) serialMap
                .get(serial);
        if (serialData == null)
            return;
        LOG.severe(getPoolName() + " " + node.toString()
                + ", serial#" + serial + " connection down");

        // several results may reach at the same time
        // so serialization is needed so that only the last returned
        // result will cause the waiting thread be waked up
        synchronized (serialData) {
            serialData.closed.add(node);
            ++serialData.gotCount;

            // all results are returned from node, wake up wating thread
            if (serialData.gotCount == serialData.sentCount) {
                LOG.info(getPoolName()
                        + " wake up the thread waiting for serial#" + serial
                        + ", " + serialData.sentCount + " results got");

                serialData.sem.release();
            }
        }
    }
}
