package outpost.wing.io.node.host;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import org.apache.mina.common.CloseFuture;
import org.apache.mina.common.ConnectFuture;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.RuntimeIOException;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.transport.socket.nio.SocketConnector;

import outpost.wing.io.Request;
import outpost.wing.io.Response;
import outpost.wing.io.protocol.MinaPacket;

import toolbox.misc.LogFormatter;

/**
 * 负责与单个service node的连接、数据发送与接收。
 * 
 * @author caowei
 */
class ServiceNodeProxy {
    public static final Logger LOG = LogFormatter
            .getLogger(ServiceNodeProxy.class.getName());
    
    /*
     * 基础信息及操作
     */
    private String host;

    private int port;

    private int slice;
    
    private long version;
    
    private volatile boolean active;
    
    public ServiceNodeProxy(String host, int port) {
        this.host = host;
        this.port = port;
        this.active = false;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public int getSlice() {
        return slice;
    }
    
    public void setSlice(int slice) {
        this.slice = slice;
    }
    
    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }
    
    public boolean isActive() {
        return this.active;
    }
    
    @Override
    public String toString() {
        return host + ":" + port;
    }
    
    /*
     * 与service node进行io操作相关的数据和操作
     */
    private static SocketConnector connector;
    
    static {
        connector = new SocketConnector(8, Executors.newCachedThreadPool());
        connector.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        connector.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(new ProtocolCodecFactory() {
                    public ProtocolDecoder getDecoder() throws Exception {
                        return MinaPacket.getDecoder();
                    }
                    public ProtocolEncoder getEncoder() throws Exception {
                        return MinaPacket.getEncoder();
                    }
                }));
    }
    
    private IoSession session;
    
    private Map<Integer, NodeEventHandler> handlerMap;
    
    private TreeMap<Long, Integer> timeoutMap;
    
    private Timer deleteTimeout;
    
    protected class IoHandler extends IoHandlerAdapter {

        @Override
        public void messageReceived(IoSession session, Object message)
                throws IOException {
            MinaPacket packet = (MinaPacket) message;
            Response response = (Response) packet.getMessage();
            synchronized (handlerMap) {
                NodeEventHandler handler = handlerMap.get(response.getSerial());
                // expired
                if (handler == null) {
                    expiredResponseGot++;
                    return;
                }
                inTimeResponseGot++;
                handler.responseReceived(ServiceNodeProxy.this, response.getSerial(), response
                        .getStatus(), response.getBuffer());
                handlerMap.remove(response.getSerial());
            }
        }
        
        public void sessionClosed(IoSession session) throws Exception {
            ServiceNodeProxy.this.active = false;
            LOG.info("slice " + slice + "@" + ServiceNodeProxy.this.toString()
                    + " mina report session closed ");
            synchronized (handlerMap) {
                for (Entry<Integer, NodeEventHandler> e: handlerMap.entrySet())
                    e.getValue().connectionDown(ServiceNodeProxy.this,
                            e.getKey());
                handlerMap.clear();
            }
        }

        @Override
        public void exceptionCaught(IoSession session, Throwable cause) {
            ServiceNodeProxy.this.active = false;
            LOG.info("slice " + slice + "@" + ServiceNodeProxy.this.toString()
                    + " mina report session exception");
            synchronized (handlerMap) {
                for (Entry<Integer, NodeEventHandler> e: handlerMap.entrySet())
                    e.getValue().connectionDown(ServiceNodeProxy.this,
                            e.getKey());
                handlerMap.clear();
            }
        }
    }
    
    private AtomicInteger counter;

    public void startConnection() throws IOException {
        ConnectFuture conn = connector.connect(
                new InetSocketAddress(host, port), new IoHandler());
        conn.join();
        try {
            session = conn.getSession();
        } catch (RuntimeIOException e) {
            session = null;
            throw new IOException(e.getMessage());
        }
        lastHbTime = System.currentTimeMillis();
        requestSent = 0;
        expiredResponseGot = 0;
        inTimeResponseGot = 0;
        
        handlerMap = new HashMap<Integer, NodeEventHandler>();
        // 按时间顺序从先到后排序，注意TreeMap不是线程安全的
        timeoutMap = new TreeMap<Long, Integer>();
        
        // 清除已经timeout的中间数据
        deleteTimeout = new Timer();
        deleteTimeout.schedule(new TimerTask() {
            @SuppressWarnings("unchecked")
            @Override
            public void run() {
                Integer[] serials = null;
                synchronized(timeoutMap) {
                    Map<Long,Integer> headMap = timeoutMap.headMap(System
                            .currentTimeMillis());
                    serials = headMap.values().toArray(new Integer[headMap.size()]);
                    headMap.clear();
                }
                for (Integer serial: serials) {
                    synchronized (handlerMap) {
                        NodeEventHandler handler = handlerMap.get(serial);
                        // a in-time result
                        if (handler == null)
                            continue;
                        handler.requestTimeout(ServiceNodeProxy.this, serial);
                        handlerMap.remove(serial);
                    }
                }
            }
        }, 0, 100);
        counter = new AtomicInteger(0);
        active = true;
    }

    public void closeConnection() {
        //设置开关为false,阻止这个时间点之后的write调用进入
        active = false;
        //让已经进入的write调用执行完毕
        while(counter.get()>0);
        //此处之后不会有write调用执行
        if (session != null) {
            CloseFuture closeFuture = session.close();
            closeFuture.join();
            session = null;
        }
        //此处之后不会有IoHandler里的函数被调用
        deleteTimeout.cancel();
        //因为session已经关闭，所以需要通知所有仍在等待结果的NodeEventHandler
        synchronized (handlerMap) {
            for (Entry<Integer, NodeEventHandler> e: handlerMap.entrySet()) {
                e.getValue().connectionDown(this, e.getKey());
            }
            handlerMap.clear();
        }
        synchronized (timeoutMap) {
            timeoutMap.clear();
        }
    }

    /**
     * 发送一条请求
     * @return 如果请求被发送出去，则返回true；否则，返回false
     */
    public boolean write(Request r, int timeout, NodeEventHandler handler) {
        if (active) {
            try {
                counter.incrementAndGet();
                synchronized (handlerMap) {
                    handlerMap.put(r.getSerial(), handler);
                }
                synchronized (timeoutMap) {
                    timeoutMap.put(System.currentTimeMillis() + timeout, r
                            .getSerial());
                }
                this.requestSent++;
                session.write(new MinaPacket(r));
                handler.requestSent(this, r.getSerial());
                return true;
            } finally {
                counter.decrementAndGet();
            }
        } else {
            handler.connectionDown(this, r.getSerial());
            return false;
        }
    }
    
    /*
     * 与服务器服务质量相关的数据及操作
     */
    private int requestSent;

    private int inTimeResponseGot;
    
    private int expiredResponseGot;
    
    public int getIntimeResponseGot() {
        return inTimeResponseGot;
    }

    public int getExpiredResponseGot() {
        return expiredResponseGot;
    }

    public int getRequestSent() {
        return requestSent;
    }

    /**
     * 返回这个node的健康指数
     */
    public float healthIndex() {
        if (requestSent < 100)
            return 1.0f;
        return ((float) inTimeResponseGot + 0.5f * ((float) expiredResponseGot))
                / (float) requestSent;
    }
    
    private long lastHbTime;
    
    /**
     * 更新最新一次heartbeat发生的时间
     */
    public void updateLastHeartBeatTime(long heartBeatTime) {
        if (heartBeatTime > this.lastHbTime)
            this.lastHbTime = heartBeatTime;
    }

    /**
     * 返回上一次heartbeat发生的时间
     */
    public long getLastHbTime() {
        return lastHbTime;
    }

    /**
     * 返回自从上一次heartbeat到现在的时间间隔
     */
    public long getTimeSinceLastHb() {
        return (System.currentTimeMillis() - lastHbTime);
    }
}
