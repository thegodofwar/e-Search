package outpost.wing.io.node.host;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 记录<code>HostNode</code>处理请求时发生的错误信息
 * 
 * @author caowei
 */
public class IoError {
    
    /**
     * 所有node返回结果
     */
    public static final int ERRNO_COMPLETE = 0;
    
    /**
     * 返回的结果不完全，部分node未返回结果
     */
    public static final int ERRNO_INCOMPLETE = 1;
    
    /**
     * 所有node都未返回结果
     */
    public static final int ERRNO_NONE = 2;
    
    /**
     * 一种特殊的情况，没有node连接上
     */
    public static final int ERRNO_NONODE = 3;
    
    /**
     * 上面这些Status code对应的名字
     */
    public static final String[] ERRNO_NAME = {
        "complete", "incomplete", "none", "no node"
    };

    private int errno;

    /*
     * 有哪些Node出错，以及每个Node的错误 
     */
    
    /**
     * 向node发出的请求超时未响应
     */
    public static final int NODE_TIME_OUT = 1;
    
    /**
     * node返回一个错误码，表示处理请求时出错
     */
    public static final int NODE_ERROR_CODE_RETURN = 2;
    
    /**
     * 与node的io连接出现异常
     */
    public static final int NODE_CONNECTION_DOWN = 3;
    
    /**
     * node已经关闭
     */
    public static final int NODE_CLOSED = 4;
    
    /**
     * 上面那些Node status的名字
     */
    public static final String[] NODE_ERROR_DETAIL_NAME = {
        "time out" , "error code return" , "exception caught" ,"closed"
    };
    
    /**
     * 记录出错node的错误详细信息
     */
    private Map<String, Integer> nodeErrorDetails;

    /**
     * 返回错误码
     */
    public int getErrno() {
        return errno;
    }

    /**
     * 设置错误码
     */
    public void setErrno(int errno) {
        this.errno = errno;
    }
    
    /**
     * 将整型错误码转换为对应的文字描述
     */
    static public String errnoName(int errno) {
        if(errno <0 || errno >= ERRNO_NAME.length )
            throw new RuntimeException("invalid errno code");
        return ERRNO_NAME[errno];
    }

    /**
     * 添加一条出错详细信息，包括哪个node发生了什么错误
     */
    public void addNodeErrorDetail(String node, int errno) {
        if( nodeErrorDetails == null )
            nodeErrorDetails = new HashMap<String,Integer>();
        nodeErrorDetails.put(node, errno);
    }
    
    /**
     * 返回所有出错的node
     */
    public String[] getErrorNodes() {
        if( nodeErrorDetails == null )
            return new String[0];
        return nodeErrorDetails.keySet().toArray(new String[0]);
    }
    
    /**
     * 返回指定node的错误详情
     */
    public int getNodeErrorDetail(String node) {
        if( nodeErrorDetails == null )
            return -1;
        return nodeErrorDetails.get(node);
    }
    
    /**
     * 将整型node错误码详情转换为文字描述
     */
    static public String nodeErrorDetailName(int nodeError) {
        if(nodeError <0 || nodeError >= NODE_ERROR_DETAIL_NAME.length )
            throw new RuntimeException("invalid node error code");
        return NODE_ERROR_DETAIL_NAME[nodeError];
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer();
        if (nodeErrorDetails != null) {
            for (Entry<String, Integer> errornode: nodeErrorDetails.entrySet())
                buf.append(errornode.getKey() + " "
                        + NODE_ERROR_DETAIL_NAME[errornode.getValue()] + ";");
        }
        return "errno " + ERRNO_NAME[errno] + ", details "
                + buf.toString();
    }
}
