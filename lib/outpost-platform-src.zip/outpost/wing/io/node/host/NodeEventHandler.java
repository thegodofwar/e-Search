package outpost.wing.io.node.host;

import outpost.wing.io.DataBufferWritable;

/**
 * 处理ServiceNodeProxy发出的所有事件
 * 
 * @author caowei
 *
 */
interface NodeEventHandler {
    
    /**
     * 当请求被发送出去后，这个函数会被调用
     * @param node 向这个node发送请求
     * @param serial 请求的ID
     */
    public void requestSent(ServiceNodeProxy node, int serial);
    
    /**
     * 处理请求的node超时
     * @param node 向这个node发送请求
     * @param serial 请求的ID
     */
    public void requestTimeout(ServiceNodeProxy node, int serial);
    
    /**
     * 当接收到Response后，这个函数会被调用
     * @param node 从这个node接收Response
     * @param serial 请求的ID
     * @param status Response的状态
     * @param result Response的数据内容
     */
    public void responseReceived(ServiceNodeProxy node, int serial, int status,
            DataBufferWritable result);

    /**
     * 发送Request的过程中与node的连接断开时，这个函数会被调用
     * @param node 向这个node发送请求
     * @param serial 请求的ID
     */
    public void connectionDown(ServiceNodeProxy node, int serial);
}
