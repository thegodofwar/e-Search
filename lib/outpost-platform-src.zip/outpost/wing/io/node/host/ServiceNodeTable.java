package outpost.wing.io.node.host;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;

import outpost.wing.heartbeat.ApplicantObserver;
import toolbox.misc.LogFormatter;

/**
 * 记录host node连接的所有service node的表格，当新的service node连接，
 * 已有的service node断开，已有的service node发送heart beat信息过来的
 * 时候都会更新该表格。此外，当service node超过两个heart beat周期没有发送
 * heart beat消息的话，会将其在表格里标记为不可用状态。
 * 
 * @author caowei
 *
 */
public class ServiceNodeTable implements ApplicantObserver {
    
    public static final Logger LOG = LogFormatter
    .getLogger(ServiceNodeTable.class.getName());

    /**
     * 名字，用于在Log里区别各个table的信息
     */
    private String name = "unknow type node table";
    
    /**
     * 这个读写锁用来保护下列的数据结构，使用读写锁的目的:<ul>
     * <li>多线程进行并发读操作的时候不会互相等待锁</li>
     * <li>发生写操作是数据是线程安全的，不会出现</li>
     * </ul>
     */
    private ReadWriteLock bigLock;

    /**
     * 记录所有service node的表格，用slice和version找到所有对应的
     * <code>ServiceNodeProxy</code>（<slice, <version, node[]>>）
     */
    private SortedMap<Integer, SortedMap<Long, ArrayList<ServiceNodeProxy>>> lookupMap;

    /**
     * 用service node的地址与端口寻找<code>ServiceNodeProxy</code>的反向表
     */
    private Map<String, ServiceNodeProxy> revertMap;

    /**
     * 记录每个slice上有几个service node处于ACTIVE状态
     */
    private SortedMap<Integer, Integer> countMap;
    /**
     * 有几个slice上有处于ACTIVE状态的服务器
     */
    private volatile int sliceCount = 0;
    
    /**
     * 处于ACTIVE状态的service node的数量
     */
    private volatile int nodeCount = 0;
    
    /**
     * 初始化关键数据结构
     */
    public void init() {
        bigLock = new ReentrantReadWriteLock();
        lookupMap = new TreeMap<Integer, SortedMap<Long, ArrayList<ServiceNodeProxy>>>();
        revertMap = new HashMap<String, ServiceNodeProxy>();
        countMap = new TreeMap<Integer, Integer>();
        sliceCount = 0;
        nodeCount = 0;
        
        checkNodeAliveTimer = new Timer();
        checkNodeAliveTimer.schedule(new TimerTask() {
            public void run() {
                checkLsState();
            }
        }, 0, checkNodeAliveInterval);
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    private static final int VERSION_BIT = 16;
    
    private static final int MAX_VERSION = 1 << VERSION_BIT;
    
    private static String formatVersion(long version) {
        if(version <= 0)
            return String.valueOf(version);
        
        long ver = version;
        Stack<Integer> versions = new Stack<Integer>();
        int validVersionNum = 0;
        int i = 0;
        while (ver != 0) {
            int v = (int) ver % MAX_VERSION - 1;
            versions.push(v);
            ver = ver >> VERSION_BIT;
            i++;
            if (v >= 0) {
                validVersionNum = i;
            }
        }

        StringBuffer sb = new StringBuffer();
        sb.append(version);
        while (versions.size() > 0) {
            if (versions.size() <= validVersionNum) {
                sb.append("[" + versions.pop() + "]");
            }
        }
        return sb.toString();
    }
    
    /**
     * 打印出连接上的service node的数量及各自状态
     * TODO： use StringBuffer
     */
    public void dumpNodes() {

        bigLock.readLock().lock();

        String msg = "#dump nodes# " + name + "\n"
                + "#dump nodes# " + sliceCount + " slices are alive\n"
                + "#dump nodes# " + nodeCount + " servers are alive\n";

        for (Entry<Integer, Integer> e: countMap.entrySet()) {
            if (e.getValue() > 0)
                msg = msg + "#dump nodes# " + e.getKey() + "\t" + e.getValue()
                        + "\n";
        }

        msg = msg + "#dump nodes# details\n";

        for (Entry<Integer, SortedMap<Long, ArrayList<ServiceNodeProxy>>> e: lookupMap
                .entrySet()) {
            msg = msg + "#dump nodes# " + e.getKey();
            for (Entry<Long, ArrayList<ServiceNodeProxy>> f: e.getValue()
                    .entrySet()) {
                for (int i = 0; i < f.getValue().size(); i++) {
                    msg = msg + "\t[" + f.getValue().get(i).toString() + "\t"
                            + formatVersion(f.getKey()) + "\t" + "]";
                }
            }
            msg = msg + "\n";
        }

        bigLock.readLock().unlock();

        LOG.info(msg);
    }
    
    /**
     * 返回连接上的所有service node的数量
     * @return 连接上的所有service node的数量
     */
    public int getNodeCount() {
        return nodeCount;
    }

    /**
     * 返回连接上的所有slice的数量
     * @return 连接上的所有slice的数量
     */
    public int getSliceCount() {
        return sliceCount;
    }
    
    private static int[] EMPTY_INTARRAY = new int[0];
    
    /**
     * 返回所有连接上的slice，按从小到大的顺序排序
     * @return 所有连接上的slice，按从小到大的顺序排序
     */
    public int[] getSlices() {
        int[] slices = EMPTY_INTARRAY;
        try {
            bigLock.readLock().lock();
            slices = new int[sliceCount];
            int point = 0;
            for(Entry<Integer, Integer> e : countMap.entrySet() ) {
                if(e.getValue() > 0)
                    slices[point++] = e.getKey();
            }
        } finally {
            bigLock.readLock().unlock();
        }
        return slices;
    }
    
    private static long[] EMPTY_LONGARRAY = new long[0];
    
    /**
     * 返回一个slice上所有的版本号，按从小到大的顺序
     * @param slice 指定的slice
     * @return slice上所有的版本号，按从小到大的顺序
     */
    public long[] getVersions(int slice) {
        long[] versions = EMPTY_LONGARRAY;
        try {
            bigLock.readLock().lock();
            SortedMap<Long, ArrayList<ServiceNodeProxy>> tmp = lookupMap.get(slice);
            if(tmp == null )
                return versions;
            Set<Long> set = tmp.keySet();
            versions = new long[set.size()];
            int point = 0;
            for(long v:set)
                versions[point++] = v;
        } finally {
            bigLock.readLock().unlock();
        }
        return versions;
    }
    
    private static ServiceNodeProxy[] EMPTY_NODEARRAY = new ServiceNodeProxy[0];
    
    /**
     * 返回一个slice上所有的service node
     * @param slice 指定的slice
     * @return slice上所有的service node
     */
    public ServiceNodeProxy[] getNodes(int slice) {
        ServiceNodeProxy[] nodes = EMPTY_NODEARRAY;
        try {
            bigLock.readLock().lock();
            SortedMap<Long, ArrayList<ServiceNodeProxy>> mid = lookupMap.get(slice);
            if(mid == null )
                return nodes;
            ArrayList<ServiceNodeProxy> tmp = new ArrayList<ServiceNodeProxy>();
            for( long version: mid.keySet())
                tmp.addAll(mid.get(version));
            nodes = tmp.toArray(new ServiceNodeProxy[tmp.size()]);
        } finally {
            bigLock.readLock().unlock();
        }
        return nodes;
    }
    
    /**
     * 返回一个slice上某个版本号的所有service node
     * @param slice 指定的slice
     * @param version 指定的版本号
     * @return slice上指定版本的所有service node
     */
    public ServiceNodeProxy[] getNodes(int slice, long version) {
        ServiceNodeProxy[] nodes = EMPTY_NODEARRAY;
        try {
            bigLock.readLock().lock();
            SortedMap<Long, ArrayList<ServiceNodeProxy>> mid = lookupMap.get(slice);
            if(mid == null )
                return nodes;
            ArrayList<ServiceNodeProxy> list = mid.get(version);
            nodes = list.toArray(new ServiceNodeProxy[list.size()]);
        } finally {
            bigLock.readLock().unlock();
        }
        return nodes;
    }
    
    /**
     * 更新activeSliceCount和activeServerCount
     * @param proxy 新增service node,proxy必须为ACTIVE状态
     */
    private void incCount(ServiceNodeProxy proxy) {
        try {
            bigLock.writeLock().lock();
            Integer count = countMap.get(proxy.getSlice());
            count++;
            countMap.put(proxy.getSlice(), count);
            // from 0 to 1
            if (count == 1)
                sliceCount++;
            nodeCount++;
        } finally {
            bigLock.writeLock().unlock();
        }
    }

    /**
     * 更新activeSliceCount和activeServerCount
     * @param proxy 新增service node,proxy必须为非ACTIVE状态
     */
    private void decCount(ServiceNodeProxy proxy) {
        try {
            bigLock.writeLock().lock();
            Integer count = countMap.get(proxy.getSlice());
            count--;
            countMap.put(proxy.getSlice(), count);
            // from 1 to 0
            if (count == 0)
                sliceCount--;
            nodeCount--;
        } finally {
            bigLock.writeLock().unlock();
        }
    }

    private String getKey(String host, int port) {
        return host + ":" + port;
    }

    private ServiceNodeProxy getNode(String key) {
        ServiceNodeProxy node = null;
        try {
            bigLock.readLock().lock();
            node = revertMap.get(key);
        } finally {
            bigLock.readLock().unlock();
        }
        return node;
    }

    /**
     * 将一个service node加入table中
     */
    public synchronized boolean addNode(String host, int port, int slice, long version) {
        deleteNode(host, port);

        ServiceNodeProxy newNode = new ServiceNodeProxy(host, port);
        newNode.setSlice(slice);
        newNode.setVersion(version);
        //首先启动node
        try {
            newNode.startConnection();
        } catch (IOException ex) {
            LOG.warning("Caught Exception \"" + ex + "\" When add server "
                    + newNode.toString() + " to server pool");
            newNode.closeConnection();
            return false;
        }

        try {
            bigLock.writeLock().lock();
            
            // 分级将newNode添加到sliceToAgentMap中
            SortedMap<Long, ArrayList<ServiceNodeProxy>> versionList;
            if (lookupMap.containsKey(slice)) {
                versionList = lookupMap.get(slice);
            } else {
                versionList = new TreeMap<Long, ArrayList<ServiceNodeProxy>>();
                lookupMap.put(slice, versionList);
                countMap.put(slice, 0);
            }
            ArrayList<ServiceNodeProxy> lsList;
            if (versionList.containsKey(version)) {
                lsList = versionList.get(version);
            } else {
                lsList = new ArrayList<ServiceNodeProxy>();
                versionList.put(version, lsList);
            }
            lsList.add(newNode);
            
            //将newNode添加到revertMap中
            revertMap.put(getKey(host, port), newNode);
            
            //增加计数
            incCount(newNode);
        } finally {
            bigLock.writeLock().unlock();
        }

        LOG.info("add node " + newNode.toString() + " version is "
                + formatVersion(version));
        dumpNodes();
        reportVersion(host, port, version);
        return true;
    }


    /**
     * 从table中删除service node
     */
    public synchronized void deleteNode(String host, int port) {
        String key = getKey(host, port);
        ServiceNodeProxy ls = getNode(key);
        if (ls == null)
            return;

        LOG.info("delete node " + ls.toString());
        int slice = ls.getSlice();
        long version = ls.getVersion();
        try {
            bigLock.writeLock().lock();
            // 减少计数
            decCount(ls);
            
            // 从addrToAgentMap中删去node
            revertMap.remove(key);
            
            // 从sliceToAgentMap中逐层删去node
            SortedMap<Long, ArrayList<ServiceNodeProxy>> versionList = lookupMap
                    .get(slice);
            ArrayList<ServiceNodeProxy> lsList = versionList.get(version);
            lsList.remove(ls);
            if (lsList.size() == 0)
                versionList.remove(version);
            if (versionList.size() == 0) {
                LOG.warning("slice " + slice + " has no node left after deleteNode "
                        + ls.toString());
                lookupMap.remove(slice);
                countMap.remove(slice);
            }
        } finally {
            bigLock.writeLock().unlock();
        }
        //最后停止node
        ls.closeConnection();
    }
    
    /**
     * 当ls发送heartbeat信息时调用该函数
     */
    public void heartBeatNode(String host, int port, int slice, long version) {
        String key = getKey(host, port);
        ServiceNodeProxy ls = getNode(key);
        
        if (ls == null) {
            LOG.warning("unknown ls " + key + " heartbeat me");
            addNode(host, port, slice, version);
        } else {
            LOG.fine("known ls " + ls.toString() + " heartbeat me");
            ls.updateLastHeartBeatTime(System.currentTimeMillis());
            reportVersion(host, port, version);
        }
    }

    private void reportVersion(String host, int port, long version) {
        String key = getKey(host, port);
        if (version <= 0) {
            LOG.severe("ls " + key + " ,should not report version  "
                    + version);
            return;
        }

        ServiceNodeProxy node = getNode(key);
        if (node == null)
            return;

        // version of this ls should be update
        if (node.getVersion() < version) {
            long oldVersion = node.getVersion();
            long newVersion = version;
            
            LOG.info("ls " + node.toString() + " version will be updated "
                    + formatVersion(node.getVersion()) + "->"
                    + formatVersion(newVersion));

            try {
                bigLock.writeLock().lock();
                
                // remove node from old version list
                SortedMap<Long, ArrayList<ServiceNodeProxy>> versionList = lookupMap
                        .get(node.getSlice());
                if (versionList == null) {
                    LOG.warning(node.toString() + " update version "
                            + formatVersion(oldVersion) + "->"
                            + formatVersion(newVersion)
                            + " fail, no slice");
                    return;
                }
                ArrayList<ServiceNodeProxy> oldList = versionList.get(oldVersion);
                if (oldList == null) {
                    LOG.warning(node.toString() + " update version "
                            + formatVersion(oldVersion) + "->"
                            + formatVersion(newVersion)
                            + " fail, no old version");
                    return;
                }
                oldList.remove(node);
                if (oldList.size() == 0)
                    versionList.remove(oldVersion);
                
                // update node version
                node.setVersion(newVersion);

                // insert node into new version list
                ArrayList<ServiceNodeProxy> newList = versionList.get(newVersion);
                if (newList == null) {
                    newList = new ArrayList<ServiceNodeProxy>();
                    versionList.put(newVersion, newList);
                }
                newList.add(node);
            } finally {
                bigLock.writeLock().unlock();
            }
            
            dumpNodes();
        }
    }

    public void applicantConnect(String host, int port, int slice, long version) {
        this.addNode(host, port, slice, version);
    }

    public void applicantDisconnect(String host, int port) {
        this.deleteNode(host, port);
    }
    
    public void applicantHeartbeat(String host, int port, int slice,
            long version) {
        this.heartBeatNode(host, port, slice, version);
    }
    
    /**
     * 如果一个node超过heartbeatTimeout时间没有更新，则认为这个node已经死掉
     */
    private int heartbeatTimeout = 30000; 
    
    /**
     * 每隔checkNodeAliveInterval时间检查一遍所有service node的状态
     */
    private int checkNodeAliveInterval = 30000;

    private Timer checkNodeAliveTimer;
    
    public int getCheckNodeAliveInterval() {
        return checkNodeAliveInterval;
    }
    
    public void setCheckNodeAliveInterval(int checkNodeAliveInterval) {
        this.checkNodeAliveInterval = checkNodeAliveInterval;
    }

    public int getHeartbeatTimeout() {
        return heartbeatTimeout;
    }

    public void setHeartbeatTimeout(int heartbeatTimeout) {
        this.heartbeatTimeout = heartbeatTimeout;
    }

    private void checkLsState() {
        
        ArrayList<ServiceNodeProxy> faultNodes = null;
        try {
            bigLock.readLock().lock();

            for (Entry<Integer, SortedMap<Long, ArrayList<ServiceNodeProxy>>> e: lookupMap
                    .entrySet()) {
                for (Entry<Long, ArrayList<ServiceNodeProxy>> f: e.getValue()
                        .entrySet()) {
                    ArrayList<ServiceNodeProxy> nodes = f.getValue();
                    for (ServiceNodeProxy node:nodes) {
                        if (node.getTimeSinceLastHb() > heartbeatTimeout) {
                            if (faultNodes == null)
                                faultNodes = new ArrayList<ServiceNodeProxy>();
                            LOG.warning("prepare to delete node " + node.toString() +
                                    " because heartbeat timeout, time since last heartbeat " +
                                    node.getTimeSinceLastHb());
                            faultNodes.add(node);
                        } else if( node.isActive() == false ) {
                            if (faultNodes == null)
                                faultNodes = new ArrayList<ServiceNodeProxy>();
                            LOG.warning("prepare to delete node " + node.toString() +
                                    " because node is not active");
                            faultNodes.add(node);
                        }
                    }
                }
            }
        } finally {
            bigLock.readLock().unlock();
        }
        
        if( faultNodes == null) 
            return;
        
        for( ServiceNodeProxy node: faultNodes)
            deleteNode(node.getHost(), node.getPort());
        
        dumpNodes();
    }
}