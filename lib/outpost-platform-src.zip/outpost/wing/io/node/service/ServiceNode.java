package outpost.wing.io.node.service;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.ThreadModel;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.transport.socket.nio.SocketAcceptor;

import outpost.wing.io.DataBufferWritable;
import outpost.wing.io.Request;
import outpost.wing.io.Response;
import outpost.wing.io.protocol.MinaPacket;
import toolbox.misc.LogFormatter;

/** 
 * 这个类用于启动service node端的服务，它调用mina监听host node发往本地端口 
 * {@link #servicePort}的请求，解析<code>Request</code>对象,从中取出
 * 请求数据(<code>DataBufferWritable</code>的形式)，为每一个请求
 * 从线程池里取出一个线程执行由你提供的<code>ServiceHandler</code>里定义的任务，
 * 并将返回的数据结果(<code>DataBufferWritable</code>的形式)，打包成
 * 一个<code>Response</code>对象,调用mina的{@link IoSession#write(Object)}，
 * 发送回host node端。
 * <p>
 * 使用示例：
 * <p>
 * <code>
 * class EchoService implements ServiceHandler {
 *     public void handleRequest(long version, DataBufferWritable ibuf,
 *          DataBufferWritable obuf) throws Exception {
 *          String s = UTF8Writable.readString(ibuf);
 *          UTF8Writable.writeString(obuf,s);
 *     }
 * }
 * ServiceNode node = new ServiceNode(new EchoService(), 8000, 8);
 * node.start();
 * ...
 * node.stop();
 * </code>
 * 
 * @author caowei
 */
public class ServiceNode {

    private static final Logger LOG = LogFormatter.getLogger(
            ServiceNode.class.getName());

    private ServiceHandler serviceHandler;

    private SocketAcceptor acceptor;

    private ExecutorService threadPool;

    private int servicePort;

    private int threadNumber;

    private long timeout;

    /**
     * 初始化函数
     * @param serviceHandler 自定义的服务处理流程
     * @param port 用于接收服务器端请求并返回结果的端口
     * @param threadNumber 并发处理请求执行服务处理流程的最大线程数量
     */
    public ServiceNode(ServiceHandler serviceHandler, int port, int threadNumber, long timeout) {
        this.serviceHandler = serviceHandler;
        this.servicePort = port;
        this.threadNumber = threadNumber;
        this.timeout = timeout;
    }

    private static ProtocolCodecFactory CODEC_FACTORY = new ProtocolCodecFactory() {
        public ProtocolDecoder getDecoder() throws Exception {
            return MinaPacket.getDecoder();
        }

        public ProtocolEncoder getEncoder() throws Exception {
            return MinaPacket.getEncoder();
        }
    };

    private static class IoHandler extends IoHandlerAdapter {
        private static final Logger LOG = LogFormatter
                .getLogger(IoHandler.class.getName());

        private static final DataBufferWritable EMPTY_BUFFER = new DataBufferWritable();

        private ServiceHandler serviceHandler;

        private ExecutorService threadPool;
        
        private ExecutorService futureTaskPool;

        private long timeout;

        public IoHandler(ServiceHandler serviceHandler,
                ExecutorService threadPool, int threadNum, long timeout) {
            this.serviceHandler = serviceHandler;
            this.threadPool = threadPool;
            this.timeout = timeout;
            futureTaskPool = Executors.newFixedThreadPool(threadNum);
        }

        /**
         * 在这里利用{@link #threadPool}进行负载调控
         */
        public void messageReceived(IoSession session, Object message)
                throws IOException {
            LOG.info(((ThreadPoolExecutor) threadPool).getActiveCount()
                    + " threads pooled");
            if (((ThreadPoolExecutor) threadPool).getActiveCount() 
                    == ((ThreadPoolExecutor) threadPool)
                    .getMaximumPoolSize()) {
                LOG.warning("threadPool is full, return overload warnning to host node");
                overload(session, message);
            } else
                threadPool.execute(new ProcessRequestTask(session, message));
        }
        
        public void exceptionCaught(IoSession session, Throwable cause)
        throws Exception {
            LOG.warning(cause.toString());
        }

        protected void overload(IoSession session, Object message) {
            MinaPacket packet = (MinaPacket) message;
            Request request = (Request) packet.getMessage();
            int serial = request.getSerial();
            session.write(new MinaPacket(new Response(EMPTY_BUFFER, serial,
                    Response.RT_OVER_LOAD)));
        }
        
        protected void timeout(IoSession session, Object message) {
            MinaPacket packet = (MinaPacket) message;
            Request request = (Request) packet.getMessage();
            int serial = request.getSerial();
            session.write(new MinaPacket(new Response(EMPTY_BUFFER, serial,
                    Response.RT_TIME_OUT)));
        }

        protected class ProcessRequestTask implements Runnable {
            private IoSession session;

            private Object message;

            public ProcessRequestTask(IoSession session, Object message) {
                this.session = session;
                this.message = message;
            }

            public void run() {
                processRequest(session, message);
            }
        }

        protected void processRequest(IoSession session, Object message) {
            FutureTask<Object> task = new FutureTask<Object>(
                    new FutureProcessRequestTask(session, message), null);
            futureTaskPool.execute(task);
            try {
                task.get(timeout, TimeUnit.MILLISECONDS);
            }
            catch(Exception e) {  
                LOG.info("request future task exception");
                e.printStackTrace();
            }

            if (!task.isDone()) {
                task.cancel(true);
                LOG.warning("request future task timeout! cancel it: "
                        + message.toString());
                timeout(session, message);
            }
        }
        
        private class FutureProcessRequestTask implements Runnable {
            private IoSession session;
            private Object message;

            public FutureProcessRequestTask(IoSession session, Object message) {
                this.session = session;
                this.message = message;
            }

            public void run() {
                MinaPacket packet = (MinaPacket) message;
                Request request = (Request) packet.getMessage();
                int serial = request.getSerial();
                DataBufferWritable ibuf = (DataBufferWritable) request.getBody();
                DataBufferWritable obuf = new DataBufferWritable();
                LOG.info("process request form host node, serial[" + serial + "]");
                try {
                    serviceHandler.handleRequest(ibuf, obuf);
                } catch (Exception e) {
                    // no process any more, no response
                    LOG.warning("cannot return request to host node, serial[" + serial
                            + "] " + " for " + e);
                    e.printStackTrace();
                    session.write(new MinaPacket(new Response(EMPTY_BUFFER, serial,
                            Response.RT_EXCEPTION)));
                    return;
                }
                LOG.info("return request to host node, serial[" + serial + "]");
                session.write(new MinaPacket(new Response(obuf, serial,
                        Response.RT_OK)));
            }
            
        }
    }
    
    /**
     * 调用mina开始监听服务端口，启动服务处理流程
     * 
     * @throws IOException
     */
    public void start() throws IOException {
        threadPool = Executors.newFixedThreadPool(threadNumber);
        LOG.info("Thread pool size is " + threadNumber);

        acceptor = new SocketAcceptor(8, Executors.newCachedThreadPool());
        acceptor.getDefaultConfig().setThreadModel(ThreadModel.MANUAL);
        acceptor.getDefaultConfig().setReuseAddress(true);
        acceptor.getFilterChain().addLast("codec",
                new ProtocolCodecFilter(CODEC_FACTORY));
        acceptor.bind(new InetSocketAddress(servicePort), new IoHandler(
                serviceHandler, threadPool, threadNumber, timeout));
    }

    /**
     * 停止服务处理流程，停止监听服务端口
     */
    public void stop() {
        threadPool.shutdown();
        acceptor.unbindAll();
    }

}
