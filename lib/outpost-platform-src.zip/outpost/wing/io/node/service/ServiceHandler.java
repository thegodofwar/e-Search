package outpost.wing.io.node.service;

import java.io.DataInput;
import java.io.DataOutput;


/**
 * <code>ServiceHandler</code>是定义一个service node上可提供服务的接口。
 * 下面的代码即定义了一个echo服务：
 * <p>
 * <code>
 * class EchoService implements ServiceHandler {
 *     public void handleRequest(long version, DataBufferWritable ibuf,
 *          DataBufferWritable obuf) throws Exception {
 *          String s = UTF8Writable.readString(ibuf);
 *          UTF8Writable.writeString(obuf,s);
 *     }
 * }
 * </code>
 * @see ServiceNode
 * @author caowei
 */
public interface ServiceHandler {

    /**
     * 处理host node发送来的一条查询请求，这条请求指定了数据版本信息，以及查询数据，
     * 本函数在处理完请求后，可以将结果写回。
     * 
     * @param in 查询数据
     * @param out 查询结果数据
     */
    public void handleRequest(DataInput in,
            DataOutput out) throws Exception;
}
