package outpost.wing.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import odis.io.DataInputBuffer;
import odis.io.DataOutputBuffer;
import odis.serialize.IWritable;

/**
 * 同时实现DataInput和DataOutput接口的一个IWritable,支持边写边读。
 * 实现继承了DataOutputBuffer类型，同时在每次读操作前更新读缓冲区。
 * 
 * @author caowei
 */
public class DataBufferWritable extends DataOutputBuffer implements IWritable,
        DataInput {
    
    protected DataInputBuffer inputBuffer;
    
    protected int offset;
    
    /**
     * 初始化函数
     * @see {@link #DataBufferWritable()}
     */
    public DataBufferWritable() {
        super();
        offset = 0;
        inputBuffer = new DataInputBuffer();
    }
    
    /**
     * 初始化函数
     * @see {@link #DataBufferWritable(int)}
     */
    public DataBufferWritable(int initialCapacity) {
        super(initialCapacity);
        offset = 0;
        inputBuffer = new DataInputBuffer();
    }

    /**
     * DataBufferWritable被reset后，buffer被清空
     */
    public DataBufferWritable reset() {
        super.reset();
        inputBuffer.reset();
        offset = 0;
        return this;
    }

    public void readFields(DataInput in) throws IOException {
        this.reset();
        int size = in.readInt();
        write(in, size);
    }

    public void writeFields(DataOutput out) throws IOException {
        out.writeInt(size());
        out.write(getData(), 0, size());
    }

    public IWritable copyFields(IWritable value) {
        DataBufferWritable that = (DataBufferWritable) value;
        this.reset();
        try {
            this.write(that.getData(), 0, that.size());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }
    
    /**
     * 更新读缓冲区
     */
    protected void up() {
        if(size() > offset) {
           inputBuffer.reset(getData(), inputBuffer.getPosition(), size()-offset);
           offset = size();
        }
    }
    
    /**
     * 返回读缓冲区可读字节数
     */
    public int getRemainingSize() {
        up();
        return inputBuffer.getSize();
    }

    public boolean readBoolean() throws IOException {
        up();
        return inputBuffer.readBoolean();
    }

    public byte readByte() throws IOException {
        up();
        return inputBuffer.readByte();
    }

    public char readChar() throws IOException {
        up();
        return inputBuffer.readChar();
    }

    public double readDouble() throws IOException {
        up();
        return inputBuffer.readDouble();
    }

    public float readFloat() throws IOException {
        up();
        return inputBuffer.readFloat();
    }

    public void readFully(byte[] b) throws IOException {
        up();
        inputBuffer.readFully(b);
    }

    public void readFully(byte[] b, int off, int len) throws IOException {
        up();
        inputBuffer.readFully(b, off, len);
    }

    public int readInt() throws IOException {
        up();
        return inputBuffer.readInt();
    }

    public String readLine() throws IOException {
        up();
        return inputBuffer.readLine();
    }

    public long readLong() throws IOException {
        up();
        return inputBuffer.readLong();
    }

    public short readShort() throws IOException {
        up();
        return inputBuffer.readShort();
    }

    public String readUTF() throws IOException {
        up();
        return inputBuffer.readUTF();
    }

    public int readUnsignedByte() throws IOException {
        up();
        return inputBuffer.readUnsignedByte();
    }

    public int readUnsignedShort() throws IOException {
        up();
        return inputBuffer.readUnsignedShort();
    }

    public int skipBytes(int n) throws IOException {
        up();
        return inputBuffer.skipBytes(n);
    }
}
