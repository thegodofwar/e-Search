package toolbox.misc;

import java.util.LinkedHashMap;
import java.util.LinkedList;

import toolbox.misc.sys.Clock;

/**
 * Event计数算法的实现.
 * @author river
 */
public class EventCounter<K> {
    private LinkedHashMap<K, IntCounter> entries = new LinkedHashMap<K, IntCounter>();
    private int capacity = 1024;
    private LinkedList<Event<K> > events = new LinkedList<Event<K> >();
    private long eventLife = 60000;
    private int threshold = 1;
    private boolean recordBandedAccess = false;

    public EventCounter() {
    }
    
    public EventCounter(int capacity, long eventLife, int threshold, boolean recordBandedAccess) {
        this.capacity = capacity;
        this.eventLife = eventLife;
        this.threshold = threshold;
        this.recordBandedAccess = recordBandedAccess;
    }

    /**
     * 设置系统最多容纳的数据项的个数. 为了防止占用系统过量的内存，当出现数据项过多的时候， 系统时钟会被加快.
     */
    public void setCapacity(int capacity) {
        entries = new LinkedHashMap<K, IntCounter>(capacity);
        events.clear();
        this.capacity = capacity;
    }

    /**
     * 设置一个event有效的时间，单位是毫秒.
     * @param life
     */
    public void setEventLife(long life) {
        this.eventLife = life;
    }

    /**
     * 设置阈值.
     * @param threshold
     */
    public void setThreshold(int threshold) {
        this.threshold = threshold;
    }

    public int getThreshold() {
        return threshold;
    }

    /**
     * checkAndVisit相当于checkAndVisit(o, getThreshold()).
     * 
     * @see #checkAndVisit(Object, int)
     * @param o
     * @return
     */
    public boolean checkAndVisit(K o) {
        return checkAndVisit(o, threshold);
    }

    private void elapse(long current) {
        Event event = events.peek();
        while (events.size()>=capacity || (event != null && event.time <= current)) {
            events.removeFirst();
            IntCounter c = entries.get(event.o);
            if (c != null) {
                c.decrease();
                if (c.getValue() <=0) {
                    entries.remove(event.o);
                }
            }
            event = events.peek();
        }
    }
    
    /**
     * 检查某个数据项的计数是否大于等于threshold，如果是，返回false；否则添加一次访问计数， 并且返回true.
     * @param o
     * @param threshold
     * @return
     */
    public boolean checkAndVisit(K o, int threshold) {
        long current = Clock.currentTimeMillis();
        elapse(current);
        
        boolean accessGranted = false;
        IntCounter counter = entries.get(o);
        if (counter == null) {
            counter = new IntCounter();
            entries.put(o, counter);
            accessGranted = true;
        } else if (threshold <= 0 || counter.value < threshold) {
            counter.increase();
            accessGranted = true;
        } else if (recordBandedAccess) {
            counter.increase();
        }

        if (recordBandedAccess || accessGranted) {
            events.addLast(new Event<K>(current + eventLife, o));
        }
        return accessGranted;
    }

    /**
     * 访问一个数据项，这里不检查计数是否越界.
     * @param o
     */
    public void visit(K o) {
        checkAndVisit(o, 0);
    }

    /**
     * 获取一个数据项的计数.
     * @param o
     * @return
     */
    public int getCount(K o) {
        elapse(Clock.currentTimeMillis());
        IntCounter counter = entries.get(o);
        return counter == null ? 0 : counter.value;
    }

    private static class IntCounter {
        private int value = 1;
        public void increase() {
            value++;
        }
        public void decrease() {
            value--;
        }
        public int getValue() {
            return value;
        }
    }

    private static class Event<K> {
        private long time;
        private K o;

        public Event(long time, K o) {
            this.time = time;
            this.o = o;
        }
    }

}
