package toolbox.misc;

import java.lang.reflect.Array;
import java.util.Arrays;

/**
 * Utilities to handle array.
 * 
 * @author river, David
 */
public class ArrayUtils {
    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param o
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] push(T[] arr, T o) {
        T[] newArr = (T[]) Array.newInstance(o.getClass(),
                arr.length + 1);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = o;
        return newArr;
    }

    public final static String[] push(String[] arr, String i) {
        String[] newArr = new String[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static int[] push(int[] arr, int i) {
        int[] newArr = new int[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    public final static byte[] push(byte[] arr, byte i) {
        byte[] newArr = new byte[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static boolean[] push(boolean[] arr, boolean i) {
        boolean[] newArr = new boolean[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static char[] push(char[] arr, char i) {
        char[] newArr = new char[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static short[] push(short[] arr, short i) {
        short[] newArr = new short[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static long[] push(long[] arr, long i) {
        long[] newArr = new long[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }
    
    public final static float[] push(float[] arr, float f) {
        float[] newArr = new float[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = f;
        return newArr;
    }
    
    public final static double[] push(double[] arr, double f) {
        double[] newArr = new double[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = f;
        return newArr;
    }
    
    public final static Object[] expand(Object[] arr, Class type, int size) {
        if (size <= arr.length)
            return arr;
        Object[] newArr = (Object[]) Array.newInstance(type, size);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    public final static String[] expand(String[] arr, int size) {
        if (size <= arr.length)
            return arr;
        String[] newArr = new String[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public final static int[] expand(int[] arr, int size) {
        if (size <= arr.length)
            return arr;
        int[] newArr = new int[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public final static boolean[] expand(boolean[] arr, int size) {
        if (size <= arr.length)
            return arr;
        boolean[] newArr = new boolean[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    public final static char[] expand(char[] arr, int size) {
        if (size <= arr.length)
            return arr;
        char[] newArr = new char[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    public final static long[] expand(long[] arr, int size) {
        if (size <= arr.length)
            return arr;
        long [] newArr = new long[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    public final static byte[] expand(byte[] arr, int size) {
        if (size <= arr.length)
            return arr;
        byte[] newArr = new byte[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    public final static short[] expand(short [] arr, int size) {
        if (size <= arr.length)
            return arr;
        short [] newArr = new short[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    public final static float[] expand(float[] arr, int size) {
        if (size <= arr.length)
            return arr;
        float[] newArr = new float[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;        
    }

    public final static double[] expand(double[] arr, int size) {
        if (size <= arr.length)
            return arr;
        double[] newArr = new double[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;        
    }
    
    /**
     * Extract a sub list from an array by a mask.
     * 
     * @param <T>  the type of the component of the array
     * @param src  the source array.
     * @param mask  the mask array. Only the components in src whose corresponding components in
     *              mask values true will be extracted to the results
     * @return  the extracted sub-list
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] extract(T[] src, boolean[] mask) {
        if (src == null)
            return null;
    	// count
    	int count = 0;
    	for (int i = 0; i < mask.length; i ++)
    		if (mask[i])
    			count ++;
    	// new
    	T[] res = (T[]) Array.newInstance(src.getClass().getComponentType(), count);
    	// copy
    	int j = 0;
    	for (int i = 0; i < mask.length; i ++)
    		if (mask[i])
    			res[j ++] = src[i];
    	// return
    	return res;
    }

    /**
     * Remove the first element of array.
     * 
     * @param arr
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] shift(T [] arr) {
        assert arr.length > 0;
        T [] newArr = (T[]) Array.newInstance(arr.getClass().getComponentType(),
                arr.length - 1);
        System.arraycopy(arr, 1, newArr, 0, arr.length - 1);
        return newArr;
    }

    private static class SortWrapper implements Comparable<SortWrapper> {
        Object[] objects;
        
        public SortWrapper(int size) {
            objects = new Object[size];
        }
        
        public void setObject(int index, Object o) {
            objects[index] = o;
        }
        
        public Object getObject(int index) {
            return objects[index];
        }

        @SuppressWarnings("unchecked")
        public int compareTo(SortWrapper o) {
            return ((Comparable)objects[0]).compareTo(o.objects[0]);
        }
    }
    
    /**
     * Sort arrays.
     * The input is a series of arrays. All the arrays will be sorted according 
     * to the first array's elements.
     * 
     * Usage:
     *   int[] keys = new int[]{1, 5, 4};
     *   int[] vals = new String[]{"A", "B", "C"};
     *   sortArrays(kyes, vals);
     * the sorted results are:
     *   keys: {1, 4, 5}
     *   vals: {"A", "C", "B"}
     *   
     * @param arrays  the arrays to be sorted
     */
    public static void sortArrays(Object ... arrays) {
        int arrayCount = arrays.length;
        int len = ((Object [])arrays[0]).length;
        SortWrapper[] wrappers = new SortWrapper[len];
        
        for (int i = 0; i < wrappers.length; i ++) {
            wrappers[i] = new SortWrapper(arrayCount);
            for (int j = 0; j < arrayCount; j ++)
                wrappers[i].setObject(j, ((Object [])arrays[j])[i]);
        } // for i
        
        Arrays.sort(wrappers);

        for (int i = 0; i < len; i ++) {
            for (int j = 0; j < arrayCount; j ++) {
                ((Object [])arrays[j])[i] = wrappers[i].getObject(j);
            } // for j
        } // for i
    }

    /**
     * Extract a contineous sub array.  The result is a new instance of array, 
     * and values are copied by calling System.arraycopy.
     * 
     * @param <T>  The type of the array.
     * @param arr  the source array
     * @param start  the start index of the sub array
     * @param len  the length of the sub array
     * @return  the copied sub array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] subArray(T[] arr, int start, int len) {
        T [] newArr = (T[]) Array.newInstance(arr.getClass().getComponentType(), 
                len);
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }
}
