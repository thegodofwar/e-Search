package toolbox.misc.channel;

import java.util.PriorityQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;


/**
 * The outputer is designed for multi-threaded processing and outputing. The 
 * main problem solved here is that we expect the output order is the same
 * as the putting order.
 * 
 * FLOW:
 *           inQ              outQ           outList (heap)
 * put() -> [...]       ,,,-> [...]       ,--> [...] ----> output()                             
 *          [...]      /C/    [...]      / [...]   [...]
 *          [...]     /O/     [...]     / [.] [.] [.] [.]     
 *          [...]    /R/      [...]    /  
 *          [...]   /P/       [...]   /  
 *          [...] -’’’        [...]--’  
 *                                      
 * FIXME When exception thrown in processing threads, the putting thread may
 *       wait for ever.
 * 
 * @author David
 *
 */
public class OrderedOutputPipe {
    public interface IProcCollector {
        public void update(boolean valid, Object... objects);
    }
    
    public interface IProcessor {
        public void process(IProcCollector collector, Object... objects) throws Exception;
    }
    
    public static class OutputEntry implements Comparable<OutputEntry> {
        long index;
        boolean valid;
        Object[] objs;
        
        public int compareTo(OutputEntry arg0) {
            return index < arg0.index ? -1 : index > arg0.index ? 1 : 0;
        }
    }
    
    ProcThread[] procThreads;
    OutputThread outThread;
    LinkedBlockingQueue<OutputEntry> inQ;
    LinkedBlockingQueue<OutputEntry> outQ;
    IProcessor processor;
    IObjectOutput output;
    Exception exception = null;
    boolean isShutting = false;
    
    public void checkException() throws Exception {
        if (exception != null)
            throw exception;
    }
    
    class ProcThread extends Thread {
        class ProcCollector implements IProcCollector {
            OutputEntry entry;

            public void update(boolean valid, Object... objects) {
                entry.valid = valid;
                entry.objs = objects;
            }
        }
        public ProcThread(int index) {
            super("Proc-Thread-" + index);
            setDaemon(true);
        }
        
        @Override
        public void run() {
            ProcCollector collector = new ProcCollector();
            while (!Thread.interrupted()) {
                try {
                    OutputEntry oe = inQ.poll(1, TimeUnit.SECONDS);
                    if (oe !=  null) {
                        collector.entry = oe;
                        processor.process(collector, oe.objs);
                        outQ.put(oe);
                    } else if (isShutting && outputIndex == inputIndex)
                        break;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    break;
                } catch (Exception e) {
                    exception = e;
                    e.printStackTrace();
                    break;
                }
            } // while
        }
    }
    
    long outputIndex = 0;
    long inputIndex = 0;
    public long getOutputIndex() {
        return outputIndex;
    }
    public class OutputThread extends Thread {
        PriorityQueue<OutputEntry> outList = new PriorityQueue<OutputEntry>(); 
        Exception exception = null;
        public OutputThread() {
            super("Output-Thread");
            this.setDaemon(true);
        }
        
        void collect(OutputEntry entry) throws Exception {
            if (entry.valid)
                output.output(entry.objs);
            outputIndex ++;
        }
        
        @Override
        public void run() {
            try {
                while (true) {
                    OutputEntry entry = outQ.poll(1, TimeUnit.SECONDS);
                    if (entry != null) {
                        if (entry.index == outputIndex) {
                            collect(entry);
                            /*
                             * Collect buffered entries.
                             */
                            while (!outList.isEmpty() && outList.peek().index == outputIndex)
                                collect(outList.poll());
                        } else {
                            outList.add(entry);
                        } // else
                    } else if (isShutting && outputIndex == inputIndex)
                        break;
                } // while
            } catch (InterruptedException e) {
                // ignored
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
                exception = e;
            }
        }
    }
    
    public OrderedOutputPipe(IProcessor processor, IObjectOutput output, 
            int numOfThreads, int inSize, int outSize) {
        this.processor = processor;
        this.output = output;
        
        inQ = new LinkedBlockingQueue<OutputEntry>(inSize);
        outQ = new LinkedBlockingQueue<OutputEntry>(outSize);
        
        procThreads = new ProcThread[numOfThreads];
        for (int i = 0; i < numOfThreads; i ++)
            procThreads[i] = new ProcThread(i);
        outThread = new OutputThread();
        
        for (int i = 0; i < procThreads.length; i ++)
            procThreads[i].start();
        outThread.start();
    }
    
    public void append(boolean needProcess, Object... objects) throws InterruptedException {
        OutputEntry oe = new OutputEntry();
        oe.valid = true;
        oe.objs = objects;
        oe.index = inputIndex ++;
        
        if (needProcess)
            inQ.put(oe);
        else
            outQ.put(oe);
    }
    
    public void shutdown() throws Exception {
        if (isShutting)
            return;
        isShutting = true;
        /*
         * Waiting for remained DNS request.
         */
        while (!Thread.interrupted() && exception == null && outputIndex < inputIndex) {
            Thread.sleep(2000);
        } // while
        
        if (exception != null)
            throw exception;
    }
}
