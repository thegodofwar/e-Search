/**
 * 
 */
package toolbox.misc.channel;

/**
 * Thrown when no running output-pipe is found during putting. 
 * 
 * @author David
 *
 */
public class NoOutputPipeException extends Exception {
    private static final long serialVersionUID = -2572548840356874547L;
}
