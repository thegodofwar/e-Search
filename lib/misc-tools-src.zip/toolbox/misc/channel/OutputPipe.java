package toolbox.misc.channel;

import toolbox.misc.INotifyEvent;

/**
 * The abstract output pipe object.
 * 
 * Fields:
 *     exception    Exception   the exception thrown during outputting
 *     onException  INotifyEvent<OutputPipe> 
 *                              a notify-event inteface, invoked when an 
 *                              exception is thrown in the output pipe.
 * 
 * 
 * @author David
 *
 */
public abstract class OutputPipe {
    protected boolean stopping = false;
    protected boolean stopNow = false;
    protected Exception exception = null;
    
    /**
     * Wait for the output thread(s) to end
     * @throws InterruptedException  if the current thread was interrupted
     */
    abstract public void join() throws InterruptedException;
    /**
     * Put a serial of objects for outputting.
     * 
     * @param objects  the serial of objects
     * @throws InterruptedException
     * @throws NoOutputPipeException
     */
    abstract protected void put(Object... objects) throws InterruptedException, 
            NoOutputPipeException;
    
    protected INotifyEvent<OutputPipe> onException = null;
    public void setOnException(INotifyEvent<OutputPipe> onException) {
        this.onException = onException;
    }
    public INotifyEvent<OutputPipe> getOnException() {
        return onException;
    }
    
    /**
     * Stop accepting inputs, all buffered objects will be outputted.
     * @throws InterruptedException  if the current thread was interrupted
     */
    public void stop() throws InterruptedException {
        this.stopping = true;
        join();
    }

    /**
     * Stop the current outputer ignoring the current data. 
     * @throws InterruptedException  if the current thread was interrupted
     */
    public void stopNow() throws InterruptedException {
        this.stopping = true;
        this.stopNow = true;
        join();
    }
    
    public Exception getException() {
        return exception;
    }
    
    public void output(Object... objects) throws InterruptedException, 
            NoOutputPipeException {
        if (!this.stopping)
            put(objects);
    }

}
