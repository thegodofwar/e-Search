package toolbox.misc.channel;

/**
 * The interface of outputting objects.
 * 
 * @author david
 *
 */
public interface IObjectOutput {
    /**
     * Output some objects.
     * 
     * @param objects  the objects to be output
     * @throws Exception  if any error occurs
     */
    public void output(Object... objects) throws Exception;
}