/**
 * @(#)KeyValPair.java, Oct 28, 2008. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import toolbox.misc.collection.Pair;

/**
 * a wrapper for key & value
 * @author guocz
 * @deprecated Use {@link Pair} instead.
 *
 */
public class KeyValPair<K, V> {

    private K key;
    private V val;
    
    /**
     * create a KeyValPair.
     * both kev & val are null
     */
    public KeyValPair() {}

    /**
     * create a KeyValPair
     * @param key the key
     * @param val the value
     */
    public KeyValPair(K key, V val) {
        this.key = key;
        this.val = val;
    }

    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public V getVal() {
        return val;
    }

    public void setVal(V val) {
        this.val = val;
    }
}
