package toolbox.misc.net;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;
import toolbox.misc.NumberUtils;

public class InetAddressUtils {
    
    private static final Logger LOG= LogFormatter.getLogger(InetAddressUtils.class);

    /**
     * Find the IP (v4) address of the local machine. If the machine has a
     * site-local network address (e.g. 192.168.*), it is returned. If not, then
     * the first public IP address is returned. This method NEVER returns
     * loop-back addresses (127.0.0.1). If no suitable address is found, an
     * error is printed (as this is probably a configuration error) and null is
     * returned.
     */
    static public String findLocalMachineName() throws IOException {
        String r = null;
        Enumeration en = NetworkInterface.getNetworkInterfaces();
        for (; en.hasMoreElements();) {
            NetworkInterface nic = (NetworkInterface) en.nextElement();
            for (Enumeration aa = nic.getInetAddresses(); aa.hasMoreElements();) {
                InetAddress ip = (InetAddress) aa.nextElement();
                if (!ip.isLoopbackAddress() && ip instanceof Inet4Address) {
                    if (ip.isSiteLocalAddress()) {
                        return ip.getHostAddress(); 
                    } else if (r == null)
                        r = ip.getHostAddress();
                } // if
            } // for aa
        } // for en
        if (r != null)
            return r;
        try {
            throw new Exception("Cannot find local IP address!");
        } catch (Exception e) {
            LOG.log(Level.WARNING, "No local IP address", e);
        }
        return null;
    }

    /** 
     * See if the given host name matches any of my local address.
     */
    static public boolean isLocalMachineName(String host) throws IOException {
        Enumeration en = NetworkInterface.getNetworkInterfaces();
        for (; en.hasMoreElements();) {
            NetworkInterface nic = (NetworkInterface) en.nextElement();
            for (Enumeration aa = nic.getInetAddresses(); aa.hasMoreElements();) {
                InetAddress ip = (InetAddress) aa.nextElement();
                if (!ip.isLoopbackAddress() && ip instanceof Inet4Address 
                    && ip.isSiteLocalAddress() && ip.getHostAddress().equals(host)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Parse host part of host:port pair. 
     */
    public static String getHostFromPair(String pair) {
        int i = pair.indexOf(':');
        return i == -1 ? pair : pair.substring(0, i);
    }
    
    public static int getPortFromPair(String pair) {
        int i = pair.indexOf(':');
        return Integer.parseInt(pair.substring(i+1));
    }

    /**
     * Util method to build socket addr from string
     */
    public static InetSocketAddress createSocketAddr(String s) {
    	String target = s;
    	int colonIndex = target.indexOf(':');
    	if (colonIndex < 0) {
    		throw new RuntimeException("Not a host:port pair: " + s);
    	}
    	String host = target.substring(0, colonIndex);
    	int port = Integer.parseInt(target.substring(colonIndex + 1));

    	return new InetSocketAddress(host, port);
    }
    

    /**
     * Transfer a Inet4Address to an integer
     * @param i4a  the Inet4Address
     * @return  the integer
     */
    public static int getInt(Inet4Address i4a) {
    	byte[] bs = i4a.getAddress();
    	assert bs.length == 4;
    	return NumberUtils.bytesToInt(bs);
    }

    /**
     * Transfer an array of Inet4Addresses to an array of integers
     * @param ias  an array Inet4Address
     * @return  an array of integers
     */
    public static int[] getInt(Inet4Address[] ias) {
    	if (ias == null)
    		return null;
    	int[] result = new int[ias.length];
    	for (int i = 0; i < ias.length; i++) {
    		result[i] = getInt(ias[i]);
    	}
    	return null;
    }

    /**
     * Create an Inet4Address from an integer represented ip
     * @param ip an integer represented ip
     * @return Inet4Address
     */
    public static Inet4Address getInetAddress(int ip) {
    	return getInetAddress(null, ip);
    }

    /**
     * Create an Inet4Address from host and an InetAddress
     * @param host hostname
     * @param ia InetAddress
     * @return the Inet4Address
     */
    public static Inet4Address getInetAddress(String host, InetAddress ia) {
    	try {
    	    return (Inet4Address) InetAddress.getByAddress(host, ia.getAddress());
    	} catch (UnknownHostException e) {
            return null;
    	}
    }

    /**
     * Create an InetAddress from the host and ip.
     * @param host
     * @param ip
     * @return
     */
    public static InetAddress createInetAddress(String host, int ip) {
        byte[] bs = new byte[4];
        for (int i = 0; i < 4; i++) {
            bs[3 - i] = (byte) (ip & 0xff);
            ip = ip >>> 8;
        }
        Inet4Address addr = null;
        try {
            addr = (Inet4Address) InetAddress.getByAddress(host, bs);
        } catch (UnknownHostException e) {
        }
        return addr;
    }
    
    /**
     * Create an Inet4Address from a pair of host and ip
     * @param host  The hostname
     * @param ip  The ip (integer)
     * @return  The Inet4Address
     */
    public static Inet4Address getInetAddress(String host, int ip) {
        byte[] bs = new byte[4];
        for (int i = 0; i < 4; i++) {
            bs[3 - i] = (byte) (ip & 0xff);
            ip = ip >>> 8;
        }
        try {
            return (Inet4Address) InetAddress.getByAddress(host, bs);
        } catch (UnknownHostException e) {
            return null;
        }
    }
    
    /**
     * Return the ipv4 addresses from all the addresses.
     * @param addrs  The array of all addresses
     * @return null if no ipv4 address found.
     */
    public static InetAddress[] extractIPv4Addrs(InetAddress[] addrs) {
        if (addrs == null) return null;
        int len = addrs.length;
        for (int i = 0; i < len; i++) {
            if (!(addrs[i] instanceof Inet4Address)) {
                for (int j = i + 1; j < addrs.length; j++)
                    addrs[j - 1] = addrs[j];
                len--;
                i--;
            }
        }
        if (len == 0) return null;
        if (len != addrs.length) {
            InetAddress[] addrs1 = new Inet4Address[len];
            System.arraycopy(addrs, 0, addrs1, 0, len);
            return addrs1;
        }
        return addrs;
    }
    
    /**
     * extract only public accessible address
     * @param addrs  the list of address
     * @return  the list of public accessible address
     */
    public static InetAddress[] extractOnlyPublicAddrs(InetAddress[] addrs) {
        List<InetAddress> list = new ArrayList<InetAddress>();
        for(InetAddress addr : addrs) {
            if(
                addr.isAnyLocalAddress()
                || addr.isLoopbackAddress()
                || addr.isLinkLocalAddress()
                || addr.isSiteLocalAddress()
                || addr.isMulticastAddress()
                || addr.isMCGlobal()
                || addr.isMCLinkLocal()
                || addr.isMCNodeLocal()
                || addr.isMCOrgLocal()
                || addr.isMCSiteLocal()
                )
                continue;
            else
                list.add(addr);
        }
        
        if(list.size() == 0)
            return null;
        else
            return list.toArray(new InetAddress[list.size()]);
    }
    
    public static String formatIPFromIntToText(int ip) {
        int[] bs = new int[4];
        for (int i = 0; i < 4; i++) {
            bs[3 - i] = (int) (ip & 0xff);
            ip = ip >>> 8;
        }
        return bs[0]+"."+bs[1]+"."+bs[2]+"."+bs[3];
    }

}
