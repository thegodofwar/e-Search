/**
 * @(#)ITaskFactory.java, 2008-6-21. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.net.socketserver;

/**
 * task factory
 * @author ares
 *
 */
public interface ITaskFactory {
    
    public ITask createTask();

}
