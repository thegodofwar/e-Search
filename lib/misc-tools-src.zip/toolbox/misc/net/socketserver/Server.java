/**
 * @(#)LogStorageService.java, 2008-6-21. Copyright 2008 Yodao, Inc. All rights
 *                             reserved. YODAO PROPRIETARY/CONFIDENTIAL. Use is
 *                             subject to license terms.
 */
package toolbox.misc.net.socketserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import toolbox.misc.LogFormatter;

/**
 * 一个基于socket连接服务
 * 
 * @author ares
 */
public class Server implements Runnable {
    public static Logger LOG = LogFormatter.getLogger(Server.class);

    private ServerSocket server;

    private ITaskFactory taskFactory;

    private ExecutorService socketExecutors;
    
    private int timeout;

    private static final int DEFAULT_CONNECTION_NUMBER = 50;
    
    private static final int DEFAULT_TIMEOUT = 0;

    public Server(int port, ITaskFactory taskFactory) throws IOException {
        this(port, DEFAULT_CONNECTION_NUMBER, taskFactory, DEFAULT_TIMEOUT);
    }
    
    public Server(int port, int connectionNumber, ITaskFactory taskFactory) throws IOException {
        this(port, DEFAULT_CONNECTION_NUMBER, taskFactory, DEFAULT_TIMEOUT);
    }

    public Server(int port, int connectionNumber, ITaskFactory taskFactory, int timeout)
            throws IOException {
        server = new ServerSocket(port);
        this.timeout = timeout;
        // 处理连接的线程池
        socketExecutors = new ThreadPoolExecutor(connectionNumber,
                connectionNumber * 2, 0, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>());
        this.taskFactory = taskFactory;
        LOG.info("Server initialized at port:" + port
                + " and max connection = " + connectionNumber);
    }

    private BlockingQueue<ITask> idleTasks = new LinkedBlockingQueue<ITask>();

    private class SocketHandler implements Runnable {

        private Socket socket;

        private ITask task;
        
        private int id;

        public SocketHandler(Socket socket, int id) {
            this.socket = socket;
            this.id = id;
            task = idleTasks.poll();
            if (task == null) {
                task = taskFactory.createTask();
            } else {
                task.reset();
            }
        }

        public void run() {
            DataInputStream input = null;
            DataOutputStream output = null;
            LOG.info("connection " + id + " start executing");
            try {           
                input = new DataInputStream(socket.getInputStream());
                output = new DataOutputStream(socket.getOutputStream());
                while (true) {
                    if (socket.isClosed() || socket.isInputShutdown())
                        break;
                    task.getRequest(input);
                    task.execute();
                    if (socket.isClosed() || socket.isOutputShutdown())
                        break;
                    task.sendResponse(output);
                    output.flush();
                }
            } catch (Exception e) {
                LOG.warning("connection " + id + " exec error");
                e.printStackTrace();
            } finally {
                idleTasks.add(task);
                try {
                    if (!socket.isClosed())
                        socket.close();
                    if (input != null)
                        input.close();
                    if (output != null)
                        output.close();
                    LOG.info("connection " + id + " closed");
                } catch (IOException e) {
                    LOG.warning("connection " + id + " close error");
                    e.printStackTrace();
                }
            }
        }
    }
    
    private Thread referThread;

    public void serve() {
        referThread = new Thread(this);
        referThread.start();
    }
    
    public void stop() {
        Thread t = referThread;
        referThread = null;
        t.interrupt();
        socketExecutors.shutdown();
    }

    public void run() {
        LOG.info("Server started.");
        Thread currentThread = Thread.currentThread();
        int id = 0; // use to track connection status
        while (referThread == currentThread) {
            Socket socket;
            try {
                socket = server.accept();
                socket.setSoTimeout(timeout);
            } catch (IOException e) {
                LOG.warning("socket accept error");
                e.printStackTrace();
                continue;
            }
            id ++;
            LOG.info("Get a connection from "
                    + socket.getRemoteSocketAddress() + ", connectionId=" + id);
            socketExecutors.execute(new SocketHandler(socket, id));
        }
    }

}
