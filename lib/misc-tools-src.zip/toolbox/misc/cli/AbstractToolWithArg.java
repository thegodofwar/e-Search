/**
 * @(#)AbstractToolWithArg.java, 2008-6-23. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.cli;

import java.io.PrintWriter;
import java.lang.reflect.Field;

/**
 * Base class for tool which implements {@link ITool} and supports
 * options using {@link Options}.
 * 
 * Most of the code is ported from AbstractCoWorkToolWithArg in odis-app package.
 * 
 * @author river
 *
 */
public abstract class AbstractToolWithArg implements ITool {
    protected Options options;
    private boolean optionsPrepared;
    
    protected PrintWriter out;
    protected PrintWriter err;
    
    public AbstractToolWithArg() {
        options = new Options();
        options.withSharedOption("help", "print this help information");
        optionsPrepared = false;
        out = new PrintWriter(System.out, true);
        err = new PrintWriter(System.err, true);
    }
    
    /**
     * Subclass should implement this method to return comment for this tool.
     */
    public abstract String comment();

    /**
     * Subclass should implement this method to do execution.
     * Arguments and options should be accessed by {@link #getOptions()}.
     * @return
     * @throws Exception
     */
    protected abstract boolean exec() throws Exception;
    
    /**
     * Subclass can override this method to add application's options.
     * This method is called in constructor of tool, so don't access any
     * field which is not initialized at this time.
     *  
     * @param options the options instance to be used in {@link #usage(PrintWriter)}
     * and {@link #processArgs(String[])}.
     */
    protected void prepareOptions(Options options) {
    }

    /**
     * Call {@link #prepareOptions(Options)} if it is not called before.
     */
    private void assureOptions() {
        if (!optionsPrepared) {
            prepareOptions(options);
            optionsPrepared = true;
        }
    }
    
    /**
     * Get the options which hold the parsed value after {@link #processArgs(String[])}
     * is called.
     * @return the {@link Options} instance.
     */
    protected final Options getOptions() {
        assureOptions();
        return options;
    }
    
    /**
     * Read the parsed value from options. Subclass can override this method
     * to process the parsed options.
     * 
     * @param options
     * @throws Exception any exception can be thrown in this method
     * @return
     */
    protected boolean processOptions(Options options) throws Exception {
        return true;
    }
    
    /**
     * This method is overrided to use the options prepared in {@link #prepareOptions(Options)}
     * to parse arguments.
     */
    protected final boolean processArgs(String[] args) {
        assureOptions();
        
        try {
            options.parse(args, 0, false);
        } catch(OptionParseException e) {
            err.println("Option processing failed: " + e.getMessage());
            this.usage(err);
            return false;
        }
        if (options.isOptSet("help")) {
            usage(err);
            return false;
        }
        try {
            options.validate();
        } catch(OptionParseException e) {
            err.println("option validation failed : " + e.getMessage());
            this.usage(err);
            return false;
        }

        try {
            if (!this.processOptions(options)) {
                this.usage(err);
                return false;
            }
        } catch(Exception e) {
            err.println("Exception thrown in option processing : " + e.getMessage());
            e.printStackTrace(err);
            this.usage(err);
            return false;
        }
        
        return true;
    }
    
    /**
     * Returns the name of the tool for printing usage information.
     * Override this method to supply your tool name.
     * 
     * The default implementation try to find the tool name in order :
     * <ul>
     * <li>use the value of static field "TOOL_NAME" or "TOOLNAME" if exists.
     * <li>use the simple name of class
     * </ul>
     */
    protected String getToolName() {
        try {
            Field field = this.getClass().getField("TOOL_NAME");
            return field.get(null).toString();
        } catch (Throwable t) {
            // ignored
        }
        try {
            Field field = this.getClass().getField("TOOLNAME");
            return field.get(null).toString();
        } catch (Throwable t) {
            // ignored
        }
        return this.getClass().getSimpleName();
    }
    
    /**
     * Implement {@link ITool#exec(String[])} by delegating call to
     * {@link #exec()}. Subclass should implement {@link #exec()}, and the options
     * and args should be accessed by {@link #getOptions()}.
     */
    public final boolean exec(String[] args) throws Exception {
        if (!processArgs(args)) {
            return false;
        }
        return exec();
    }

    /**
     * Print the usage information using options returned in
     * {@link #getOptions()}.
     */
    public void usage(PrintWriter out) {
        out.println(this.comment());
        assureOptions();
        options.printHelpInfo(out, getToolName(), 100);
    }

}
