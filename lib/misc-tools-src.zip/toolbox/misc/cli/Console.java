package toolbox.misc.cli;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 将一个对象的接口直接export在控制台的工具.
 * 
 * @author river
 * 
 */
public class Console {
    private Map<String, Method> methodMap = new HashMap<String, Method>();

    private Map<String, String> helpMap = new HashMap<String, String>();

    private BufferedReader reader;

    private PrintWriter writer;

    private boolean terminated = false;

    private Object target;

    public Console(Object target) {
        this.target = target;
        this.reader = new BufferedReader(new InputStreamReader(System.in));
        this.writer = new PrintWriter(new OutputStreamWriter(System.out), true);
        buildMap();
    }

    public Console(Object target, BufferedReader reader, PrintWriter writer) {
        this.target = target;
        this.reader = reader;
        this.writer = writer;
        buildMap();
    }

    private void buildMap() {
        try {
            methodMap.put("HELP", this.getClass().getMethod(
                    "cmd_help",
                    new Class[] { String.class, BufferedReader.class,
                            PrintWriter.class }));
            helpMap.put("HELP", HELP);
            methodMap.put("QUIT", this.getClass().getMethod(
                    "cmd_quit",
                    new Class[] { String.class, BufferedReader.class,
                            PrintWriter.class }));
            helpMap.put("QUIT", QUIT);
        } catch (Exception e) {
        }

        Method[] methods = target.getClass().getMethods();
        for (int i = 0; i < methods.length; i++) {
            Method method = methods[i];
            Class[] types = method.getParameterTypes();
            if (method.getName().startsWith("cmd_") && types.length == 3
                    && types[0] == String.class
                    && types[1] == BufferedReader.class
                    && types[2] == PrintWriter.class) {
                String name = method.getName().substring(4).toUpperCase();
                methodMap.put(name, method);
                try {
                    Field field = target.getClass().getField(name);
                    if (field != null) {
                        helpMap.put(name, (String) field.get(null));
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public static final String HELP = "help [command] | print the usage information";

    public void cmd_help(String param, BufferedReader reader, PrintWriter writer) {
        if (param.length() == 0) {
            List<String> namelist = new ArrayList<String>();
            namelist.addAll(methodMap.keySet());
            Collections.sort(namelist);

            for (Iterator<String> it = namelist.iterator(); it.hasNext();) {
                String name = it.next();
                String info = helpMap.get(name);
                if (info == null)
                    info = "";
                writer.println(name + "\t" + info);
            }
        } else {
            param = param.toUpperCase();
            if (methodMap.containsKey(param)) {
                String info = helpMap.get(param);
                if (info == null) {
                    writer.println("no help information for this command.");
                } else {
                    writer.println(info);
                }
            } else {
                writer.println("error: no such command ");
            }
        }
    }

    public static final String QUIT = "quit | terminate the console";

    public void cmd_quit(String param, BufferedReader reader, PrintWriter writer) {
        writer.println("Good bye.");
        terminated = true;
    }

    private void process(String cmd, String param) {
        cmd = cmd.toUpperCase();
        if (cmd.equals("HELP")) {
            cmd_help(param, reader, writer);
        } else if (cmd.equals("QUIT")) {
            cmd_quit(param, reader, writer);
        } else {
            Method method = methodMap.get(cmd);
            if (method == null) {
                writer.println("error: no such method " + cmd + " " + param);
            } else {
                try {
                    method.invoke(target,
                            new Object[] { param, reader, writer });
                } catch (InvocationTargetException e) {
                    e.getTargetException().printStackTrace(writer);
                } catch (Exception e) {
                    e.printStackTrace(writer);
                }
            }
        }
    }

    public void process(String line) {
        line = line.trim();
        int pos = line.indexOf(' ');
        String cmd, param;

        if (pos > 0) {
            cmd = line.substring(0, pos);
            param = line.substring(pos + 1).trim();
        } else {
            cmd = line;
            param = "";
        }

        process(cmd, param);

    }

    public void process(String[] args) {
        if (args.length == 0) {
            throw new NullPointerException("no command found");
        }
        String command = args[0];
        
        StringBuilder builder = new StringBuilder();
        for (int i=1; i<args.length; i++) {
            builder.append(args[i]).append(' ');
        }
        if (builder.length() > 0) builder.setLength(builder.length()-1);
        
        process(command, builder.toString());
    }

    public void run() throws IOException {
        String line;

        writer.print("$ ");
        writer.flush();
        while ((line = reader.readLine()) != null) {
            process(line);
            if (terminated) {
                break;
            }
            writer.println();
            writer.print("$ ");
            writer.flush();
        }
    }

}
