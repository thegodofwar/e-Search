package toolbox.misc.cli;

import java.io.PrintWriter;

/**
 * The interface for all app tools. 
 * 
 * @author rcai, David
 */
public interface ITool {
    
    /**
     * Prints the usage information. 
     */
    public void usage(PrintWriter out);

    /**
     * Returns a one-lined comment string.
     * 
     * @return the comment to the tool
     */
    public String comment();

    /**
     * Executes the main procedure.
     * 
     * @param args  the argument from the command line
     * @return  whether this tool is successfuly executed.
     * @throws Exception if an error occurs 
     */
    public boolean exec(String args[]) throws Exception;
    
}
