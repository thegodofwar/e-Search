/**
 * @(#)Options.java, 2008-4-14. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.cli;

import java.io.File;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Pattern;

import toolbox.misc.ArrayUtils;
import toolbox.misc.EmptyInstance;
import toolbox.misc.UnitUtils;

/**
 * Options process arguments mostly in the same rules of {@link ArgumentProcessor}.
 * The difference with {@link ArgumentProcessor} is :
 * <ul>
 * <li> We can set one option to be needed, and check the existance of such options
 * during parsing args.</li>
 * <li> We can call {@link #ignoreUnknownOption()} to ignore unknown options instead
 * of throwing {@link OptionParseException} during parsing.
 * <li> We don't support the format of multiple arguments for one option, such as "-i a b",
 * instead, we support multiple option declaration, such as "-i a -i b".
 * <li> We support option group declaration. Default group and shared group is auto included.
 * </ul>
 * Sample code :
 * <code>
 *   Options options = new Options();
 *   options.withOption("out", "set output directory").setDefault("snapshot");
 *   options.addParam("input1").addParam("input2").etcParam();
 *   
 *   // the reduce number option is not required
 *   options.withSharedOption("r", "set the reduce number").setArg("reduce number").hasDefault();
 *   
 *   ...
 *   // print the usage
 *   options.printHelpInfo(System.out, "test");
 *   
 *   ...
 *   // parse the args
 *   try {
 *       options.parse(args);
 *   } catch(OptionParseException e) {
 *       usage();
 *       return false;
 *   }
 *   
 *   // get the option value
 *   String outputName = options.getStringOpt("out");
 *   int reduceNumber = options.getIntOpt("r");
 *   String [] inputs = options.getRemains();
 *   ...
 *   
 * </code>
 * 
 * And this option with print the help information like:
 * <code>
 * Usage: 
 * test [-out <arg>] <input1> <input2> ...
 * Options:
 *     -out <arg>   Set output directory. DEFAULT: "snapshot".               
 * Parameters:
 * Shared options:
 *   -r <reduce number>   Set the reduce number.
 * </code>
 * 
 * Notes:
 * Most of the code is migrated from {@link ArgumentProcessor}.
 * 
 * @author David, river
 *
 */
public class Options {
    
    /**
     * Type of number, such as "123" or "0x0f".
     */
    public static final IArgType TYPE_NUMBER = new NumberType();
    
    /**
     * Type of float(float or double), such as "0.1".
     */
    public static final IArgType TYPE_FLOAT = new FloatType();
    
    /**
     * Type of time, such as "23"(23 milliseconds), "4h"(4 hour) or "3D"(3 day).
     */
    public static final IArgType TYPE_TIME = new TimeType();
    
    /**
     * Type of size, such as "1"(1 byte), "2k"(2k), "3g".
     */
    public static final IArgType TYPE_SIZE = new SizeType();
    
    /**
     * Type of boolean, true could be "yes", "true" or "on", and false could
     * be "no", "false", "off".
     */
    public static final IArgType TYPE_BOOL = new BoolType();
    
    private HashMap<String, Option> options = new HashMap<String, Option>();
    private ArrayList<OptionGroup> optionGroups = new ArrayList<OptionGroup>(2);
    
    private ArrayList<Param> params = new ArrayList<Param>();
    
    private String [] remains = null;
    
    private int minimalParamCount = 0;
    private boolean ignoreUnknownOption = false;
    
    private String [] args = null;
    
    /**
     * Create one empty options.
     */
    public Options() {
        optionGroups.add(new OptionGroup("", null));
        optionGroups.add(new OptionGroup("shared", null));
    }
    
    /**
     * Indicate this options should ignore unknown option during parsing.
     * It is impossible to know if one unknown option has argument, so
     * we ignore option by :
     * <ul>
     * <li>If the arg following unknown option is not started with "-", it 
     * is regarded as argument of this option and is ignored.
     * <li>Otherwise, ignore the option itself.
     * </ul>
     */
    public void ignoreUnknownOption() {
        this.ignoreUnknownOption = true;
    }
    
    /**
     * Add one option with name and description and return
     * the {@link Option} object.
     * The newly created option has no argument, and is not needed.
     * You can set the attributes of option like:
     * <code>
     *    options.withOption("a", "an option").setArg("arg").needed();
     * </code>
     * 
     * @param name name of option
     * @param description comment of option
     * @return
     */
    public Option withOption(String name, String description) {
        return withGroupOption(optionGroups.get(0), name, null, description);
    }
    
    /**
     * Add one option with name, argument and description. The newly created
     * option is returned. The newly created option is required, and we will
     * check if the value exists after parsing. Use {@link Option#hasDefault()
     * to set this option can be missed.
     * 
     * @param name name of option
     * @param argument argument name of option
     * @param description comment of option
     * @return
     */
    public Option withOption(String name, String argument, String description) {
        return withGroupOption(optionGroups.get(0), name, argument, description);
    }
    
    /**
     * Add one option with name and description to shared group and return
     * the {@link Option} object.
     * The newly created option has no argument, and is not needed.
     * You can set the attributes of option like:
     * <code>
     *    options.withSharedOption("a", "an option").setArg("arg").needed();
     * </code>
     * 
     * The options in shared group is not printed in usage line.
     * 
     * @param name name of option
     * @param description comment of option
     * @return
     */
    public Option withSharedOption(String name, String description) {
        return withGroupOption(optionGroups.get(optionGroups.size()-1), name, null, description);
    }
    
    /**
     * Add one option with name, argument and description to shared group and return
     * the {@link Option} object.
     * <code>
     *    options.withSharedOption("a", "an option").setArg("arg").needed();
     * </code>
     * 
     * The options in shared group is not printed in usage line.
     * 
     * @param name name of option
     * @param description comment of option
     * @return
     */
    public Option withSharedOption(String name, String argument, String description) {
        return withGroupOption(optionGroups.get(optionGroups.size()-1), name, argument, description);
    }
    
    /**
     * Add one param without description. Refer to {@link #addParam(String, String)}
     * for help.
     * Param without comment is only printed in usage line.
     * @see #addParam(String, String)
     * @param name name of param
     * @return
     */
    public Options addParam(String name) {
        return addParam(name, "");
    }
    
    /**
     * Add one param. Because {@link #addParam(String, String)} returns {@link Options},
     * we add multiple params like this :
     * <code>
     *   options.addParam("a", "a param").addParam("b", "b param").etcParam();
     * </code>
     * 
     * Param list do not affect parsing of args, all params(unprocessed args) are
     * returned by {@link #getRemains()}. We add params soly for printing help information.
     *  
     * @param name name of param
     * @param description comment of param
     * @return
     */
    public Options addParam(String name, String description) {
        params.add(new Param(name, description));
        return this;
    }
    
    /**
     * Add "..." to param list. Most of the time we call {@link #etcParam()} 
     * append "..." to the end of param list to indicate that we have more 
     * params which is not listed here.
     * @return
     */
    public Options etcParam() {
        return addParam("...", "");
    }
    
    /**
     * Indicates that this options should have at least min params.
     * We will check the param count in {@link #parse(String[])},
     * {@link #parse(String[], int)} and {@link #validate()}.
     */
    public void setMinimalParamCount(int min) {
        this.minimalParamCount = min;
    }
    
    /**
     * Create one option group with given name and description.
     * Options in non default option groups is not printed in usage line.
     * 
     * @param name name of group
     * @param description comment of group
     * @return
     */
    public OptionGroup addOptionGroup(String name, String description) {
        for (OptionGroup g : optionGroups) {
            if (g.name.equalsIgnoreCase(name)) {
                return g;
            }
        }
        OptionGroup g = new OptionGroup(name, description);
        optionGroups.add(optionGroups.size()-1, g);
        return g;
    }
    
    /**
     * Add option to named group. Refer to {@link #withOption(String, String)}
     * for information about option.
     * 
     * @param groupName name of group
     * @param name name of option
     * @param description comment of option
     * @return
     */
    public Option withGroupOption(String groupName, String name, String description) {
        OptionGroup group = null;
        for (OptionGroup g : optionGroups) {
            if (g.name.equalsIgnoreCase(groupName)) {
                group = g;
                break;
            }
        }
        if (group == null) {
            throw new RuntimeException("unknown group : " + group);
        }
        return withGroupOption(group, name, null, description);
    }
    
    /**
     * Internal implementation of adding option to option group.
     * @param group name of group
     * @param name name of option
     * @param argument argument name of option
     * @param description comment of option
     * @return
     */
    private Option withGroupOption(OptionGroup group, String name, String argument, String description) {
        if (options.containsKey(name)) {
            throw new RuntimeException("duplicate option declaration for " + name);
        }
        Option option;
        if (argument == null) 
            option = new Option(name, description);
        else
            option = new Option(name, argument, description);
        
        group.options.add(option);
        options.put(name, option);
        return option;
    }
    
    /**
     * Split the string by space and parse it.
     * @param s
     * @throws OptionParseException
     */
    public void parse(String s) throws OptionParseException {
        parse(s.split("\\s+"));
    }
    
    /**
     * Parse arguments from the begining. This method is the same to call
     * {@link #parse(String[], int)} with zero as the second param.
     * 
     * @param args the arguments to be parsed
     * @throws OptionParseException
     */
    public void parse(String [] args) throws OptionParseException {
        parse(args, 0);
    }

    /**
     * Parse arguments from given offset. It is safe to call this method twice
     * to parse different args, because we clear all the parsed values of last call
     * at the begining.
     * 
     * @param args the arguments to be parsed
     * @param off the offset from which to parse
     * @throws OptionParseException
     */
    public void parse(String [] args, int off) throws OptionParseException {
        parse(args, off, true);
    }
    
    /**
     * Parse arguments from given offset. It is safe to call this method twice
     * to parse different args, because we clear all the parsed values of last call
     * at the begining.
     * 
     * @param args the arguments to be parsed
     * @param off the offset from which to parse
     * @param validate If we should check the needed options, you can turn off
     * auto needed check by set this param to false, and call {@link #validate()}
     * later.
     *  
     * @throws OptionParseException
     */
    public void parse(String [] args, int off, boolean validate) throws OptionParseException {
        // clear the values
        for (Option option : options.values()) {
            option.value = null;
        }
        remains = null;
        this.args = args;

        // process the args
        int idx = off;
        LinkedList<String> unprocessed = new LinkedList<String>();
        while (idx < args.length) {
            String opt = args[idx ++];
            if (opt.startsWith("-")) {
                String optName = opt.substring(1);
                Option option = options.get(optName);
                if (option == null) {
                    // unknown option
                    if (ignoreUnknownOption) {
                        // ignore this option and the first param
                        if (idx < args.length && !args[idx].startsWith("-")) idx++;
                    } else {
                        throw new OptionParseException("unknown option \"" + 
                                opt + "\" found");
                    }
                } else {
                    if (option.hasArg) {
                        if (idx >= args.length) 
                            throw new OptionParseException("option \"" + opt + 
                                    "\" should have argument" + 
                                    (option.argName == null ? "" : " " + option.argName));
                        String arg = args[idx++];
                        if (option.value == null) {
                            option.value = new String[]{arg};
                        } else {
                            option.value = ArrayUtils.push(option.value, arg);
                        }
                    } else {
                        option.value = EmptyInstance.STRINGS;
                    }
                }
            } else {
                unprocessed.add(opt);
            }
        }
        remains = unprocessed.toArray(new String[unprocessed.size()]);

        // check needed options
        if (validate) {
            validate();
        }
        
    }
    
    /**
     * Check if all the options marked needed() are set.
     * This method is internally called when you call {@link #parse(String[])} or
     * {@link #parse(String[], int)} to parse arguments.
     * 
     * @throws OptionParseException
     */
    public void validate() throws OptionParseException {
        // check the needed options
        StringBuilder missBuf = new StringBuilder();
        StringBuilder badValueBuf = new StringBuilder();
        
        for (Option option : options.values()) {
            if (option.hasArg && !option.hasDefault && option.value == null) {
                missBuf.append(option.name).append(',');
            }
            if (option.value != null && option.hasArg && option.type != null) {
                for (String v : option.value) {
                    if (!option.type.validate(v)) {
                        badValueBuf.append("-").append(option.name).append(" ").append(v).append(",");
                    }
                }
            }
        }
        
        if (missBuf.length() > 0) {
            missBuf.setLength(missBuf.length()-1);
            throw new OptionParseException("some options are missed : " + missBuf);
        }
        if (badValueBuf.length() > 0) {
            badValueBuf.setLength(badValueBuf.length()-1);
            throw new OptionParseException("some option value is bad : " + badValueBuf);
        }
        
        // check the param
        if (minimalParamCount > 0) {
            if (remains.length < minimalParamCount) {
                throw new OptionParseException("no enough param");
            }
        }
        
    }
    
    /**
     * Return the unprocessed params.
     * @return
     */
    public String [] getRemains() {
        return remains;
    }

    /**
     * Return the original arguments parsed in {@link #parse(String[])}.
     * @return
     */
    public String [] getArgs() {
        return args;
    }
    
    /**
     * Return the values for option. If this option is not defined, we will throw runtime
     * exception because this could be caused by typo in code.
     * @param name
     * @return
     */
    public String [] getOpt(String name) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return option.def;
            } else {
                return option.value;
            }
        }
    }
    
    /**
     * Check if some options are set by processed arguments or have default values. 
     * @param opts the option name list
     * @return true if all the options is set
     */
    public boolean isOptSet(String ... opts) {
        for (String opt : opts) {
            if (getOpt(opt) == null) return false;
        }
        return true;
    }
    
    /**
     * Return the first value of option. When there is not value set for this
     * option : 
     * <ul>
     * <li>If this option is optional option({@link Option#hasDefault()} is called previously),
     * return null.
     * <li>Otherwise, throw RuntimeException.
     * </ul>
     * @param name
     * @return
     */
    public String getStringOpt(String name) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                if (option.hasDefault) {
                    if (option.def != null) 
                        return option.def[0];
                    else
                        return null;
                }
                else
                    throw new RuntimeException("cannot find value for option : " + option.name);
            } else {
                return option.value[0];
            }
        }
    }

    /**
     * Return the first value of option, or def if no value set for this option.
     * The default value set by {@link Option#setDefault(Object...)} is simply ignored.
     * 
     * @param name
     * @param def
     * @return
     */
    public String getStringOpt(String name, String def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return option.value[0];
            }
        }
    }
    
    /**
     * Return value of option as int. 
     * Remember to call {@link #isOptSet(String...)} before calling this method, 
     * or NullPointerException could be raised.
     * Call {@link #getIntOpt(String, int)} when you want to return the default
     * when no value set in options.
     * 
     * @param name
     * @return
     */
    public int getIntOpt(String name) {
        return NumberType.parseInt(getStringOpt(name));
    }

    /**
     * Return value of option as int, or the def value if this option is not set.
     * The default value in method params is used instead of default value in option
     * setting.
     * @param name
     * @param def
     * @return
     */
    public int getIntOpt(String name, int def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return NumberType.parseInt(option.value[0]);
            }
        }
    }

    /**
     * Return value of option as long. 
     * Remember to call {@link #isOptSet(String...)} before calling this method, 
     * or NullPointerException could be raised.
     * @param name
     * @return
     */
    public long getLongOpt(String name) {
        return NumberType.parseLong(getStringOpt(name));
    }

    /**
     * Return value of option as long, or the def value if this option is not set.
     * The default value in method params is used instead of default value in option
     * setting.
     * @param name
     * @param def
     * @return
     */
    public long getLongOpt(String name, long def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return NumberType.parseLong(option.value[0]);
            }
        }
    }
    
    /**
     * Return value of option as float. 
     * Remember to call {@link #isOptSet(String...)} before calling this method, 
     * or NullPointerException could be raised.
     * @param name
     * @return
     */
    public float getFloatOpt(String name) {
        return Float.parseFloat(getStringOpt(name));
    }

    /**
     * Return value of option as float, or the def value if this option is not set.
     * The default value in method params is used instead of default value in option
     * setting.
     * @param name
     * @param def
     * @return
     */
    public float getFloatOpt(String name, float def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return Float.parseFloat(option.value[0]);
            }
        }
    }
    
    /**
     * Return value of option as double. 
     * Remember to call {@link #isOptSet(String...)} before calling this method, 
     * or NullPointerException could be raised.
     * @param name
     * @return
     */
    public double getDoubleOpt(String name) {
        return Double.parseDouble(getStringOpt(name));
    }

    /**
     * Return value of option as double, or the def value if this option is not set.
     * The default value in method params is used instead of default value in option
     * setting.
     * @param name
     * @param def
     * @return
     */
    public double getDoubleOpt(String name, double def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return Double.parseDouble(option.value[0]);
            }
        }
    }
    
    /**
     * Return value of option as a file.
     * Remember to call {@link #isOptSet(String...)} before calling this method.
     * @param name
     * @return
     */
    public File getFileOpt(String name) {
        String f = getStringOpt(name);
        return f == null ? null : new File(f);
    }
    
    /**
     * Return time format argument, such as "1h", "3m".
     * 
     * @param name
     * @return  the time in milli-seconds
     */
    public long getTimeOpt(String name) {
        long r = UnitUtils.parseTime(getStringOpt(name), -1);
        if (r < 0) {
            throw new RuntimeException("bad value for option : " + name);
        }
        return r;
    }
    
    /**
     * Return time format argument, such as "1h", "3m".
     * @param name
     * @param def
     * @return
     */
    public long getTimeOpt(String name, long def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return UnitUtils.parseTime(option.value[0], def);
            }
        }
    }
    
    /**
     * Return size format argument, such as "1k", "2g".
     * @param name
     * @return
     */
    public long getSizeOpt(String name) {
        long r = UnitUtils.parseSize(getStringOpt(name), -1);
        if (r < 0) {
            throw new RuntimeException("bad value for option : " + name);
        }
        return r;
    }
    
    /**
     * Return size format argument, such as "1k", "2g".
     * @param name
     * @param def
     * @return
     */
    public long getSizeOpt(String name, long def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return UnitUtils.parseSize(option.value[0], def);
            }
        }
    }

    /**
     * Return switch format argument, such as "yes", "off", "false".
     * @param name
     * @return
     */
    public boolean getBooleanOpt(String name) {
        return BoolType.parse(getStringOpt(name));
    }
    
    /**
     * Return switch format argument, such as "yes", "off", "false".
     * @param name
     * @param def
     * @return
     */
    public boolean getBooleanOpt(String name, boolean def) {
        Option option = options.get(name);
        if (option == null) {
            throw new RuntimeException("unknown option : " + name);
        } else {
            if (option.value == null) {
                return def;
            } else {
                return BoolType.parse(option.value[0]);
            }
        }
    }
    
    /**
     * Layout a string given the size on each line and wrap methods
     * 
     * @param text  the string to layout
     * @param size  the wrap size of each line
     * @param wrap  one of "left", "right", or "ends"
     * @return  a list of string in each line
     */
    private static ArrayList<String> layout(String text, int size, String wrap) {
        ArrayList<String> res = new ArrayList<String>();
        if (text == null)
            text = "";
        String[] lines = text.split("\n");
        for (String srcLine : lines) {
            String[] words = srcLine.split(" +");
            int idx = 0;
            while (idx < words.length) {
                int len = words[idx].length();
                int idx_1 = idx + 1;
                while (idx_1 < words.length
                        && len + words[idx_1].length() + 1 <= size) {
                    len += words[idx_1].length() + 1;
                    idx_1++;
                } // while

                int remLen = size - len;
                if (remLen < 0)
                    remLen = 0;
                String line;
                if ("right".equals(wrap)) {
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (remLen > 0)
                        line = String.format("%" + remLen + "s", "") + line;
                } else if ("ends".equals(wrap) && idx_1 < words.length) {
                    line = words[idx];
                    int num_words = idx_1 - idx;
                    for (int i = idx + 1; i < idx_1; i++) {
                        int blank = 1 + remLen/(num_words - 1) + ((i - idx - 1) 
                                < (remLen % (num_words - 1)) ? 1 : 0);
                        line += String.format("%" + blank + "s", "")
                                + words[i];
                    } // for i
                } else {
                    // default is left
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (remLen > 0)
                        line += String.format("%" + remLen + "s", "");
                } // else
                res.add(line);

                idx = idx_1;
            } // while
        } // for srcLine
        return res;
    }

    /**
     * Prints the help infomation with 80 as max line width, like : 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintWriter
     * @param cmd  the name of the command
     */
    public void printHelpInfo(PrintStream out, String cmd) {
        printHelpInfo(out, cmd, 80);
    }
    
    /**
     * Prints the help infomation with 80 as max line width, like : 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintWriter
     * @param cmd  the name of the command
     */
    public void printHelpInfo(PrintWriter out, String cmd) {
        printHelpInfo(out, cmd, 80);
    }
    
    /**
     * Prints the help infomation like : 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintWriter
     * @param cmd  the name of the command
     * @param maxWidth  the maximum width
     */
    public void printHelpInfo(PrintStream out, String cmd, int maxWidth) {
        PrintWriter pw = new PrintWriter(out, true);
        printHelpInfo(pw, cmd, maxWidth);
        pw.flush();
    }
    
    private void printNameInfos(PrintWriter out, String[] names, String[] infos, 
            int maxWidth, String indent, int gap, int optLen) {
        for (int i = 0; i < infos.length; i ++) {
            ArrayList<String> lines = layout(infos[i], 
                    maxWidth - indent.length() - optLen - gap, "left");
            for (int j = 0; j < lines.size(); j ++) {
                out.print(indent);
                if (j == 0) {
                    if (names[i].length() <= optLen) {
                        out.format("%-" + optLen + "s", names[i]);
                    } else {
                        out.println(names[i]);
                        out.format("%s%" + optLen + "s", indent, "");
                    } // else
                } else {
                    out.format("%" + optLen + "s", "");
                } // else
                out.format("%" + gap + "s", "");
                out.println(lines.get(j));
            } // for j
        } // for i
    }
    
    /**
     * Prints the help infomation like : 
     *   
     *   Usage:
     *      cmd  [-a] -b <arg0> <input-file>
     *   Options:
     *      -a   comment for a
     *      -b   comment for b
     *   Parameters:
     *      input-file   The input file.  
     *      
     * @param out  the output PrintWriter
     * @param cmd  the name of the command
     * @param maxWidth  the maximum width
     */
    public void printHelpInfo(PrintWriter out, String cmd, int maxWidth) {
        String indent = "   ";
        int gap = 3;
        /*
         * Print usage infomation.
         */
        out.println("Usage: ");
        out.print("   " + cmd + " ");
        int leading = ("   " + cmd + " ").length();
        
        int pos = leading;
        String line;
        for (Option option : optionGroups.get(0).options) {
            line = "";
            boolean optional = !option.hasArg || option.hasDefault;
            if (optional)
                line = line + "[";
            
            line = line + "-" + option.name;
            if (option.hasArg) {
                line = line + " <" + (option.argName == null ? "arg" 
                        : option.argName) + ">";
            } // if
            
            if (optional)
                line = line + "]";
            
            if (pos == leading) {
                out.print(line);
                pos += line.length();
            } else if (pos + 1 + line.length() > maxWidth) {
                out.println();
                out.format("%" + leading + "s", "");
                out.print(line);
                pos = line.length();
            } else {
                out.print(" " + line);
                pos += 1 + line.length();
            } // else
        } // for opt

        for (int i = 0; i < params.size(); i ++) {
            String paramName = params.get(i).name;
            if (i == params.size() - 1 && "...".equals(paramName))
                line = "...";
            else
                line = "<" + paramName + ">";
            if (pos == leading) {
                out.print(line);
                pos += line.length();
            } else if (pos + 1 + line.length() > maxWidth) {
                out.println();
                out.format("%" + leading + "s", "");
                out.print(line);
                pos = line.length();
            } else {
                out.print(" " + line);
                pos += 1 + line.length();
            } // else
        } // for i
        
        out.println();
        int groupIdx = 0;

        /*
         * Print all the groups.
         */
        for (OptionGroup group: optionGroups) {
            if (group.options.isEmpty()) 
                continue;
            
            /*
             * Print group name.
             */
            StringBuilder groupNameBuf = new StringBuilder(group.name);
            if (groupNameBuf.length() > 0) 
                groupNameBuf.append(" options");
            else
                groupNameBuf.append("options");
            if (group.description != null && group.description.length() > 0) {
                groupNameBuf.append(" - ").append(group.description);
            }
            groupNameBuf.append(":");
            groupNameBuf.setCharAt(0, Character.toUpperCase(groupNameBuf.charAt(0)));
            
            out.println(groupNameBuf.toString());
        
            /*
             * Print comments for each option.
             */
            LinkedList<String> names = new LinkedList<String>();
            LinkedList<String> infos = new LinkedList<String>();
            
            int optLen = 0;
            for (Option option : group.options) {
                String name = "-" + option.name;
                if (option.hasArg) {
                    if (option.argName == null) {
                        name = name + " <arg>";
                    } else {
                        name = name + " <" + option.argName + ">";
                    } // else
                } // if
                if (name.length() > optLen)
                    optLen = name.length();
                
                String info = "";
                if (option.type != null) {
                    info = info + "[" + option.type.getName() + "]";
                }
                
                if (option.description != null) {
                    info = info + option.description.trim();
                    if (info.length() > 0) {
                        info = Character.toUpperCase(info.charAt(0)) 
                                + info.substring(1);
                    } // if
                    if (info.length() > 0 
                            && info.charAt(info.length()-1) != '.')
                        info = info + '.';
                } // if
                
                if (option.def != null && option.def.length > 0) {
                    if (info.length() > 0)
                        info = info + ' ';
                    info = info + "DEFAULT: ";
                    if (option.def.length == 1) {
                        info = info + "\"" + option.def[0] + "\".";
                    } else {
                        info = info + "[";
                        for (int i = 0; i < option.def.length-1; i ++) {
                            if (i > 0)
                                info = info + ", ";
                            info = info + "\""  + option.def[i] + "\"";
                        } // for i
                        info = info +  "].";
                    } // else 
                } // if
                names.add(name);
                infos.add(info);
            } // for opt
            
            if (optLen > 20) optLen = 20;
            
            if (maxWidth < optLen + 10)
                maxWidth = optLen + 10;
            
            printNameInfos(out, names.toArray(new String[names.size()]), 
                    infos.toArray(new String[infos.size()]), maxWidth, indent, gap, optLen);
            
            /*
             * Print remaining parameters (if any).
             */
            if (groupIdx == 0 && params.size() > 0) {
                names.clear();
                infos.clear();
                optLen = 0;
                for (int i = 0; i < params.size(); i++) {
                    Param param = params.get(i);
                    if (param.description == null || param.description.length() == 0)
                        continue;
                    
                    if (param.name.length() > optLen)
                        optLen = param.name.length();
                    
                    StringBuilder infoBuf = new StringBuilder();
                    if (param.description != null) infoBuf.append(param.description);
                    if (infoBuf.length() > 0) {
                        infoBuf.setCharAt(0, Character.toUpperCase(infoBuf.charAt(0)));
                        if (infoBuf.charAt(infoBuf.length()-1) != '.') {
                            infoBuf.append('.');
                        }
                    }
                    names.add(param.name);
                    infos.add(infoBuf.toString());
                } // for opt
                if (names.size() > 0) {
                    out.println("Parameters:");
                    printNameInfos(out, names.toArray(new String[names.size()]), 
                            infos.toArray(new String[infos.size()]), maxWidth, indent, gap, optLen);
                } // if
            } // if
            
            groupIdx ++;
        }
    }
    
    /**
     * Data structure to store all the attributes of option and the parsed result.
     *
     * @author river
     *
     */
    public class Option {
        private String name;
        private String [] value = null;
        private String [] def = null;
        
        private boolean hasArg = false;
        private boolean hasDefault = false;
        
        private String argName = null;
        private String description = null;
        private IArgType type = null;
        
        /**
         * Create option with given name and description.
         * The newly created option has no args.
         * @param name
         * @param description
         */
        Option(String name, String description) {
            if (name == null || name.length() == 0 || description == null)
                throw new NullPointerException("bad name or description");
            
            this.name = name;
            this.description = description;
        }
        
        /**
         * Create option with given name , argument, and description.
         * @param name
         * @param description
         */
        Option(String name, String argument, String description) {
            if (name == null || name.length() == 0 || description == null)
                throw new NullPointerException("bad name or description");
            
            this.name = name;
            this.description = description;
            this.hasArg = true;
            this.argName = argument;
        }

        /**
         * Set that this option should have arg.
         * @return
         */
        public Option hasArg() {
            this.hasArg = true;
            return this;
        }
        
        /**
         * Set the argument of this option, and indicates that this option should
         * has one arg.
         * @param argName
         * @return
         */
        public Option setArg(String argName) {
            this.hasArg = true;
            this.argName = argName;
            return this;
        }
        
        /**
         * Set the attribute that this option has default value, 
         * and is not required for check. This create one option without default value
         * but need not to be checked during parsing. 
         * 
         * @return
         */
        public Option hasDefault() {
            this.hasDefault = true;
            return this;
        }
        
        /**
         * Set the default value, which also indicates that this
         * option should have argument. 
         * @param defs
         * @return
         */
        public Option setDefault(Object ... defs) {
            this.hasArg = true;
            this.hasDefault = true;
            this.def = new String[defs.length];
            for (int i=0; i<defs.length; i++) {
                this.def[i] = defs[i].toString();
            }
            return this;
        }
        
        /**
         * Set the type of argument, and we can check the argument
         * when parsing args.
         * 
         * @param type
         * @return
         */
        public Option setType(IArgType type) {
            this.type = type;
            return this;
        }
        
        public static final int TYPE_INT = 0;
        public static final int TYPE_FLOAT= 1;
        public static final int TYPE_SIZE = 2;
        public static final int TYPE_TIME = 3;
        public static final int TYPE_BOOL = 4;
        
        /**
         * Sets the type by code.
         * Possible code definitions:
         *   TYPE_INT    interger number. e.g. 1, 2, 3
         *   TYPE_FLOAT  float number. e.g. 1.3, 4.5
         *   TYPE_SIZE   size. e.g. 1g, 2k, 3K, 4M
         *   TYPE_TIME   time. 1s, 2m, 3H, 4D
         *   TYPE_BOOL   boolean value. true/yes/on/false/no/off
         * @param type  the code
         * @return  the Option instance for training setting.
         */
        public Option setTypeCode(int type) {
            switch (type) {
                case TYPE_INT:
                    return setType(new NumberType());
                case TYPE_FLOAT:
                    return setType(new FloatType());
                case TYPE_SIZE:
                    return setType(new SizeType());
                case TYPE_TIME:
                    return setType(new TimeType());
                case TYPE_BOOL:
                    return setType(new BoolType());
            }
            throw new RuntimeException("Unknown type code!");
        }
    }

    /**
     * Group of option. The order of added options is reserved when printed.
     *
     * @author river
     *
     */
    public class OptionGroup {
        private String name;
        private String description;
        private LinkedList<Option> options = new LinkedList<Option>();
        
        OptionGroup(String name, String description) {
            this.name = name;
            this.description = description;
        }
        
        /**
         * Add option to this group. This method is the same to call 
         * {@link Options#withOption(String, String, String) with this group name 
         * as the first param.
         * @param name
         * @param description
         * @return
         */
        public Option withOption(String name, String description) {
            return Options.this.withGroupOption(this, name, null, description);
        }
        
        /**
         * Add option with argument to this group. 
         * @param name
         * @param argument
         * @param description
         * @return
         */
        public Option withOption(String name, String argument, String description) {
            return Options.this.withGroupOption(this, name, argument, description);
        }
    }
    
    /**
     * Data structure to store param attributes.
     *
     * @author river
     *
     */
    public class Param {
        private String name;
        private String description;
        
        public Param(String name, String description) {
            this.name = name;
            this.description = description;
        }
    }
    
    /**
     * Type checker.
     * @author river
     */
    public static interface IArgType {
        public String getName();
        public boolean validate(String s);
    }

    public static class NumberType implements IArgType {
        private static Pattern NUMBER = Pattern.compile("[\\-]?[\\d]+");
        private static Pattern HEX = Pattern.compile("0[xX][0-9a-zA-Z]+");
        
        public String getName() {
            return "number";
        }

        public boolean validate(String s) {
            return NUMBER.matcher(s).matches() || HEX.matcher(s).matches();
        }

        public static int parseInt(String s) {
            if (NUMBER.matcher(s).matches()) {
                return Integer.parseInt(s);
            } else if (HEX.matcher(s).matches()) {
                return Integer.parseInt(s.substring(2), 16);
            } else {
                throw new RuntimeException("bad int value : " + s);
            }
        }
        
        public static long parseLong(String s) {
            if (NUMBER.matcher(s).matches()) {
                return Long.parseLong(s);
            } else if (HEX.matcher(s).matches()) {
                return Long.parseLong(s.substring(2), 16);
            } else {
                throw new RuntimeException("bad long value : " + s);
            }
        }
    }
    
    public static class FloatType implements IArgType {
        private static Pattern FLOAT = Pattern.compile("[\\-]?([\\d+]*)(\\.[\\d]+)?([eE][\\-]?[\\d]+)?");
        
        public String getName() {
            return "float";
        }

        public boolean validate(String s) {
            return FLOAT.matcher(s).matches();
        }
        
    }
    
    public static class TimeType implements IArgType {
        private static Pattern TIME = Pattern.compile("[\\d]+[sSmMhHdD]?");
        
        public String getName() {
            return "time";
        }

        public boolean validate(String s) {
            return TIME.matcher(s).matches();
        }
        
    }
    
    public static class SizeType implements IArgType {
        private static Pattern SIZE = Pattern.compile("[\\d]+[gGkKmM]?");
        
        public String getName() {
            return "size";
        }

        public boolean validate(String s) {
            return SIZE.matcher(s).matches();
        }
        
    }

    public static class BoolType implements IArgType {
        
        private static final String [] VALID_TRUE = {
            "true",
            "yes",
            "on",
        };
        
        private static final String [] VALID_FALSE = {
            "false",
            "no",
            "off",
        };
        
        public String getName() {
            return "bool";
        }

        public boolean validate(String s) {
            if (NumberType.NUMBER.matcher(s).matches())
                return true;
            for (String t : VALID_TRUE) {
                if (s.equalsIgnoreCase(t)) return true;
            }
            for (String f : VALID_FALSE) {
                if (s.equalsIgnoreCase(f)) return true;
            }
            return false;
        }

        public static boolean parse(String s) {
            if (NumberType.NUMBER.matcher(s).matches()) {
                return Integer.parseInt(s) != 0;
            }
            for (String t : VALID_TRUE) {
                if (s.equalsIgnoreCase(t)) return true;
            }
            for (String f : VALID_FALSE) {
                if (s.equalsIgnoreCase(f)) return false;
            }
            throw new RuntimeException("bad boolean value : " + s);
        }
    }
    
}
