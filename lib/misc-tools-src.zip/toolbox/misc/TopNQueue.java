/**
 * 
 */
package toolbox.misc;

import java.lang.reflect.Array;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * A class exntending PriorityQueue which remains the Top-N largest objects.
 * 
 * The element either implements Comparable or a Comparator should be specified.
 * 
 * NOTE: the comparator should define in a natural way, i.e. 
 *    compare(a, b) returns -1 if a < b
 *                           0 if a == b
 *                           1 if a > b
 *    The polling order is INCREASING. Call toReverseArray to get a decreasing ordered array.
 * 
 * @author David
 */
@SuppressWarnings("serial")
public class TopNQueue<E> extends PriorityQueue<E> {
    protected int topN;
    /**
     * The constructor.
     * 
     * @param topN  the number of objects remained
     */
    public TopNQueue(int topN) {
        super(topN);
        this.topN = topN;
    }
    /**
     * The constructor with customized comparator
     * 
     * @param topN  the number of objects remained
     * @param comparator  the comparator for the minimum-heap
     */
    public TopNQueue(int topN, Comparator<E> comparator) {
        super(topN, comparator);
        this.topN = topN;
    }
    
    /**
     * Compares two elements.
     * 
     * @param a  the first element
     * @param b  the second element
     * @return  -1 if a < b, 0 if a == b, 1 if a > b
     */
    @SuppressWarnings("unchecked")
    public int objCompareTo(E a, E b) {
        if (this.comparator() == null)
            return ((Comparable<E>) a).compareTo(b);
        return this.comparator().compare(a, b);
    }
    
    /**
     * Adds an element into the queue. The instance of the object will be added, i.e. DO NOT reuse
     * the object.
     * 
     * @param o  The element to be added.
     * @return true  if this element replaces one of the element in the queue or was insterted into
     *               the queue. false otherwise. 
     */
    public boolean add(E o) {
        if (this.size() < topN || objCompareTo(this.peek(), o) < 0) {
            if (this.size() >= topN)
                poll();
            super.add(o);
            return true;
        } // if
        
        return false;
    }
    
    /**
     * Convert the whole topN queue in the reverse order as in the priority-queue, 
     * i.e., in the result array, they are from TOP to BOTTOM (large to small).
     * 
     *  The runtime type of the returned array is that of the specified array. 
     *  If the list fits in the specified array, it is returned therein. Otherwise, 
     *  a new array is allocated with the runtime type of the specified array and the 
     *  size of this list.
     *  
     *  If the list fits in the specified array with room to spare (i.e., the array 
     *  has more elements than the list), the element in the array immediately following 
     *  the end of the collection is set to null. This is useful in determining the 
     *  length of the list only if the caller knows that the list does not contain any 
     *  null elements.
     *  
     *  NOTE: after calling to this method, the queue is cleared.
     *  
     * @param a  the array into which the elements of the list are to be stored, if it 
     *           is big enough; otherwise, a new array of the same runtime type is 
     *           allocated for this purpose.
     * @return  an array containing the elements of the queue
     */
    @SuppressWarnings("unchecked")
    public E[] toReverseArray(E[] a) {
        int sz = this.size();
        if (a.length < sz) {
            a = (E[]) Array.newInstance(a.getClass().getComponentType(), sz);
        } // if
        int idx = 0;
        while (!this.isEmpty()) {
            a[sz - idx - 1] = this.poll();
            idx ++;
        } // while
        for (; idx < a.length; idx ++)
            a[idx] = null;
        return a;
    }
}
