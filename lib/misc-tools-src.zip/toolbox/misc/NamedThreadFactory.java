/**
 * @(#)NamedThreadFactory.java, 2008-6-26. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Thread factory with given name for each created threads.
 * @author river
 *
 */
public class NamedThreadFactory implements ThreadFactory {
    private String namePrefix;
    private AtomicInteger id = new AtomicInteger(0);
    private boolean daemon;
    
    /**
     * Create thread factory, specify the name and set if all the
     * created threads are daemon.
     * 
     * @param name
     * @param daemon
     */
    public NamedThreadFactory(String name, boolean daemon) {
        this.namePrefix = name;
        this.daemon = daemon;
    }
    
    /**
     * Create new thread.
     */
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, namePrefix + "-" + id.addAndGet(1));
        t.setDaemon(daemon);
        return t;
    }

}
