package toolbox.misc;

/**
 * The interface for an object generator.
 *  
 * @author David
 *
 * @param <E> The type of the object generated.
 */
public interface IObjectGenerator<E> {
    public E newInstance();
}