package toolbox.misc.collection;

import java.util.NoSuchElementException;

/**
 * An efficient long-long hash-map implementation that does not generate small
 * objects at all.
 * 
 * @author David
 *
 */
public class CompactLongLongHashMap {
    private static final int MAX_CAPACITY = 1 << 30;
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 2f;
    
    private static int CURR_EMPTY = 0;
    private static int NEXT_NULL = -1;
    
    private long[] keys;
    private long[] vals;
    private int[] nexts;
    
    private int size;
    private int freeTop;
    private int minHeap;
    
    private float loadFactor;
    private int expandSize;
    
    public CompactLongLongHashMap() {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
    }
    
    public CompactLongLongHashMap(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }
    
    public CompactLongLongHashMap(int capacity, float loadFactor) {
        int realSize = 1;
        while (realSize < capacity) {
            realSize = realSize << 1;
        } // while
        if (realSize > MAX_CAPACITY) 
            realSize = MAX_CAPACITY;
        
        keys = new long[realSize * 2];
        vals = new long[keys.length];
        nexts = new int[keys.length];
        freeTop = keys.length / 2;  minHeap = freeTop;
        expandSize = (int) (keys.length / 2 * loadFactor);
        size = 0;
        
        this.loadFactor = loadFactor;
    }
    
    private void resize(int capacity) {
        long[] newKeys = new long[capacity * 2];
        long[] newVals = new long[newKeys.length];
        int[] newNexts = new int[newKeys.length];
        int newFreeTop = capacity;
        
        int cnt = keys.length / 2;
        for (int i = 0; i < cnt; i ++) {
            if (nexts[i] != CURR_EMPTY) {
                int cur = i;
                while (cur != NEXT_NULL) {
                    int index = index(keys[cur], capacity);
                    
                    if (newNexts[index] == CURR_EMPTY) {
                        newKeys[index] = keys[cur];
                        newVals[index] = vals[cur];
                        newNexts[index] = NEXT_NULL;
                    } else {
                        newKeys[newFreeTop] = keys[cur];
                        newVals[newFreeTop] = vals[cur];
                        newNexts[newFreeTop] = newNexts[index];
                        
                        newNexts[index] = newFreeTop;
                        
                        newFreeTop ++;
                    } // else
                    
                    cur = nexts[cur];
                } // while
            }
        } // for entry

        keys = newKeys;  vals = newVals;
        nexts = newNexts;
        freeTop = newFreeTop;
        minHeap = newFreeTop;
        expandSize = (int) (keys.length / 2 * loadFactor);
    }
    
    /**
     * Calculate the index of a given long key. This code is migrated from 
     * jdk source.
     * @param key
     * @param size
     * @return
     */
    protected int index(long key, long size) {
        int h = (int) (key ^ (key >>> 32));
        h += ( h << 9);
        h ^= ( h >>> 14);
        h += ( h << 4);
        h ^= ( h >> 10);
        return (int)(h & (size-1));
    }
    
    public boolean containsKey(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            return false;
        while (index != NEXT_NULL) {
            if (keys[index] == key)
                return true;
            
            index = nexts[index];
        } // while

        return false;
    }
    
    public long get(long key, long def) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            return def;
        while (index != NEXT_NULL) {
            if (keys[index] == key)
                return vals[index];
            
            index = nexts[index];
        } // while

        return def;
    }
    public void put(long key, long val) {
        if ((size > expandSize || freeTop == keys.length) && 
                keys.length < MAX_CAPACITY) {
            resize(keys.length);
        } // if
        
        int head = index(key, keys.length / 2);
        if (nexts[head] == CURR_EMPTY) {
            /*
             * Head position is empty, put it here
             */
            keys[head] = key;  vals[head] = val;
            nexts[head] = NEXT_NULL;
            size ++;
            return;
        } // if
        int cur = head;
        while (cur != NEXT_NULL) {
            if (keys[cur] == key) {
                vals[cur] = val;
                return;
            } // if
            
            cur = nexts[cur];
        } // while
        /*
         * Not found, allocate a new position
         */
        int newIndex = freeTop;
        if (freeTop == minHeap) {
            freeTop ++;  minHeap ++;
        } else {
            freeTop = nexts[freeTop];
        } // else
        /*
         * Insert the key to the node following head
         *   before:
         *     tail = nexts[index];
         *     [index] -> [tail]
         *   after:
         *     [index] -> [newIndex] -> [tail] 
         */
        keys[newIndex] = key;  vals[newIndex] = val;
        nexts[newIndex] = nexts[head];
        nexts[head] = newIndex;
        /*
         * increase the size
         */
        size ++;
    }
    private void freeEntry(int index) {
        nexts[index] = freeTop;
        freeTop = index;
    }
    public void remove(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            /*
             * No entries for this hash-index
             */
            return;
        
        int next = nexts[index];
        if (keys[index] == key) {
            /*
             * First entry is the one
             */
            if (next == NEXT_NULL) {
                /*
                 * Only one entry, simply set it to be empty
                 */
                nexts[index] = CURR_EMPTY;
            } else {
                /*
                 * Otherwise, copy <next> entry to head,
                 */
                keys[index] = keys[next];  vals[index] = vals[next];
                nexts[index] = nexts[next];
                /*
                 * and free <next> entry
                 */
                freeEntry(next);
            } // else

            size --;
            return;
        }
        /*
         * Try find the entry in non-head entries
         */
        while (next != NEXT_NULL) {
            if (keys[next] == key) {
                /*
                 * Found it, skip it and free it
                 */
                nexts[index] = nexts[next];
                freeEntry(next);
                size --;
                return;
            } // if
            
            index = next;
            next = nexts[index];
        } // while
    }
    
    public LongLongHashMapIterator iterator() {
        return new LongLongHashMapIterator();
    }
    /**
     * @return  the number of key-value pairs in this map
     */
    public int size() {
        return size;
    }
    /**
     * @return  whether the map is empty
     */
    public boolean isEmpty() {
        return size == 0;
    }
    /**
     * Remove all elements in this map.
     * NOTE: calling to this method does not change the capacity of this map
     *
     */
    public void clear() {
        for (int i = nexts.length / 2 - 1; i >= 0; i --)
            nexts[i] = CURR_EMPTY;
        
        freeTop = keys.length / 2;  minHeap = freeTop;
        size = 0;
    }
    
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder(size * (8*2 + 2));
        str.append("[");
        LongLongHashMapIterator iter = iterator();
        boolean first = true;
        while (iter.hasNext()) {
            if (!first) {
                str.append(", ");
            } else {
                first = false;
            } // else
            iter.next();
            str.append(iter.getKey()).append("=").append(iter.getValue());
        } // while
        str.append("]");
        return "";
    }

    /**
     * The iterator class for CompactLongLongHashMap.
     * 
     * Usage:
     *   LongLongHashMapIterator iter = map.iterator();
     *   while (iter.hasNext()) {
     *       iter.next();
     *       
     *       iter.getKey();
     *       iter.getValue();
     *       
     *       iter.remove();
     *   } // while
     * 
     * @author david
     *
     */
    public class LongLongHashMapIterator {
        private int index;  // current slot
        private int current, next;
        
        public LongLongHashMapIterator() {
            current = NEXT_NULL;
            
            int[] n = nexts;
            index = keys.length / 2 - 1;
            if (size != 0) {
                while (n[index] == CURR_EMPTY)
                    index --;
                next = index;
                index --;
            } else {
                next = NEXT_NULL;
            } // else
        }

        /**
         * Returns <tt>true</tt> if the iteration has more elements. (In other
         * words, returns <tt>true</tt> if <tt>next</tt> would return an element
         * rather than throwing an exception.)
         *
         * @return <tt>true</tt> if the iterator has more elements.
         */
        public boolean hasNext() {
            return next != NEXT_NULL;
        }
        
        /**
         * Moves the iterator to the next element in the iteration.  Calling this method
         * repeatedly until the {@link #hasNext()} method returns false will
         * return each element in the underlying collection exactly once.
         *
         * @exception NoSuchElementException iteration has no more elements.
         */
        public void next() {
            int c = next;
            if (c == NEXT_NULL)
                throw new NoSuchElementException();
            
            next = nexts[next];
            if (next <= 0) {
                while (index >= 0 && nexts[index] == CURR_EMPTY)
                    index --;
                if (index >= 0) {
                    next = index;
                    index --;
                } else {
                    next = NEXT_NULL;
                } // else
            } // if
            current = c;
        }

        /**
         * Returns the current key.
         * @return the current key
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called.
         */
        public long getKey() {
            if (current == NEXT_NULL)
                throw new IllegalStateException();
            return keys[current];
        }
        /**
         * Returns the current value.
         * 
         * @return the current value
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called.
         */
        public long getValue() {
            if (current == NEXT_NULL)
                throw new IllegalStateException();
            
            return vals[current];
        }

        /**
         * 
         * Removes from the underlying collection the last element returned by the
         * iterator (optional operation).  This method can be called only once per
         * call to <tt>next</tt>.  The behavior of an iterator is unspecified if
         * the underlying collection is modified while the iteration is in
         * progress in any way other than by calling this method.
         *
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called, or the <tt>remove</tt> method has already
         *            been called after the last call to the <tt>next</tt>
         *            method.
         */
        public void remove() {
            if (current == NEXT_NULL) 
                throw new IllegalStateException();

            if (current >= keys.length / 2) {
                /*
                 * current not in main-table, remove it will not change
                 * the value of this.next
                 */
                CompactLongLongHashMap.this.remove(keys[current]);
            } else {
                int next = nexts[current];
                if (next == NEXT_NULL) {
                    nexts[current] = CURR_EMPTY;
                } else {
                    keys[current] = keys[next];
                    vals[current] = vals[next];
                    nexts[current] = nexts[next];
                    
                    freeEntry(next);
                    this.next = current;
                } // else
                size --;
            } // else
            
            current = NEXT_NULL;
        }
    }
}
