package toolbox.misc.collection;

import java.util.ArrayList;

/**
 * A map whose value is an ArrayList. See HashCollectionMap for more details.
 * 
 * @author david
 *
 * @param <K>  the type of the key
 * @param <V>  the type of the element of the array-list.
 * 
 * @see HashCollectionMap
 */
public class HashArrayListMap<K, V> extends 
        HashCollectionMap<K, V, ArrayList<V>> {
    public HashArrayListMap() {
        super((Class) ArrayList.class);
    }
    private static final long serialVersionUID = 2987671419942317669L;
}
