package toolbox.misc.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 实现一个根据出现次数排序的队列。
 * 
 * @author Feng Jiang
 */
public class FrequencePriorityQueue<E> implements Iterable<Entry<E, Integer>>{
    
    enum Order {
        /** 相同次数的两个，最近改变者认为MOST */
        MOST_PREFER,
        /** 相同次数的两个，最近改变者认为LEAST */
        LEAST_PREFER,
    }
    
    class Value implements Entry<E, Integer> {
        public Value(E e) { this.e = e; }
        public E e;
        public int count = 0;
        public Value prev = this;
        public Value next = this;
        public String toString() {
            return e + "=" + count;
        }
        public E getKey() {
            return e;
        }
        public Integer getValue() {
            return count;
        }
        public Integer setValue(Integer value) {
            int old = count;
            count = value;
            return old;
        }
    }
    
    private Order order;
    
    private Value head = new Value(null);
    
    private Map<E, Value> map = new HashMap<E, Value>();
    
    public FrequencePriorityQueue(){
        this(Order.LEAST_PREFER);
    }
    
    public FrequencePriorityQueue(Order order) {
        this.order = order;
    }
    
    public void add(E e) {
        add(e, 1);
    }
    
    public void add(E e, int count) {
        if(count < 0)
            throw new IllegalArgumentException("count = " + count + ", less than 0.");
        Value v = map.get(e);
        if(v != null) {
            assert(v!=null);
            v.count += count;
            shift(v);
        } else {
            v = new Value(e);
            v.count += count;
            map.put(e, v);
            insertAfter(head, v);
            shift(v);
        }
    }
    
    public int size() {
        return map.size();
    }
    
    /**
     * get the occurency count of this element. 
     * 
     * @param e
     * @return 0 if the this elements is not in the queue.
     */
    public int freq(E e) {
        if(!map.containsKey(e))
            return 0;
        return map.get(e).count;
    }
    
    public E pollLeastFreq() {
        Value first = head.next;
        if(first != head) {
            Value second = first.next;
            head.next = second;
            second.prev = head;
            map.remove(first.e);
            return first.e;
        } else
            return null;
    }
    
    public E peekLeastFreq() {
        Value first = head.next;
        if(first != head)
            return first.e;
        else
            return null;
    }
    
    public E pollMostFreq() {
        Value last = head.prev;
        if(last!=head) {
            Value lastlast = last.prev;
            head.prev = lastlast;
            lastlast.next = head;
            map.remove(last.e);
            return last.e;
        } else
            return null;
    }
    
    public E peekMostFreq() {
        Value last = head.prev;
        if(last!=head) 
            return last.e;
        else
            return null;
    }
    
    private void insertAfter(Value prev, Value value) {
        Value next = prev.next;
        prev.next = value;
        next.prev = value;
        
        value.prev = prev;
        value.next = next;
    }
    
    private void insertBefore(Value next, Value value) {
        Value prev = next.prev;
        insertAfter(prev, value);
    }
    
    private void delete(Value value) {
        Value prev = value.prev;
        Value next = value.next;
        prev.next = next;
        next.prev = prev;
    }

    private void shift(Value v) {
        Value next = v.next;
        if(order == Order.LEAST_PREFER) {
            while(next!=head && next.count < v.count)
                next = next.next;
        } else {
            while(next!=head && next.count <= v.count)
                next = next.next;
        }
        delete(v);
        insertBefore(next, v);
    }

    public Iterator<Entry<E, Integer>> iterator() {
        
        return new Iterator<Entry<E,Integer>>(){
            
            private Value cur = head;

            public boolean hasNext() {
                return cur.prev!=head;
            }

            public Entry<E, Integer> next() {
                cur = cur.prev;
                return cur;
            }

            public void remove() {
                cur = cur.next;
                delete(cur.prev);
            }
        };
    }
    
    public Iterator<Entry<E, Integer>> iteratorLeast2Most() {
        
        return new Iterator<Entry<E,Integer>>(){
            
            private Value cur = head;

            public boolean hasNext() {
                return cur.next!=head;
            }

            public Entry<E, Integer> next() {
                cur = cur.next;
                return cur;
            }

            public void remove() {
                cur = cur.prev;
                delete(cur.next);
            }
        };
    }

}
