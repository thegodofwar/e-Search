/**
 * @(#)Pair.java, 2008-7-30. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.misc.collection;

/**
 * Container to hold two objects. The first and second fields
 * can hold null value.
 * 
 * This class do deep compare in method {@link #equals(Object)}, that
 * is to say, the fields value should be compared, and the pairs hold
 * same value(for example, different string objects of same content)
 * should be regarded as same.
 * 
 * @author river
 */
public class Pair<V1, V2> {
    private static final int NULL_HASH = "NULL".hashCode();
    
    protected V1 first;
    protected V2 second;
    
    /**
     * Create pair instance by given values. This method is 
     * equal to call constructor {@link #Pair(Object, Object)}.
     * @param <V1>
     * @param <V2>
     * @param first
     * @param second
     * @return
     */
    public static <V1, V2> Pair<V1, V2> create(V1 first, V2 second) {
        return new Pair<V1, V2>(first, second);
    }
    
    /**
     * Create empty pair.
     */
    public Pair() {}
    
    /**
     * Create pair with initial values.
     * @param first
     * @param second
     */
    public Pair(V1 first, V2 second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Return the first value.
     * @return
     */
    public V1 getFirst() { return first; }
    
    /**
     * Set the first value.
     * @param v
     */
    public void setFirst(V1 v) { this.first = v; }
    
    /**
     * Return the second value.
     * @return
     */
    public V2 getSecond() { return second; }
    
    /**
     * Set the second value.
     * @param v
     */
    public void setSecond(V2 v) { this.second = v; }
    
    @Override
    public int hashCode() {
        return (first == null ? NULL_HASH : first.hashCode()) ^ 
        (second == null ? NULL_HASH : second.hashCode());
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == this) return true;
        if (o == null || o.getClass() != this.getClass()) return false;
        
        Pair that = (Pair) o;
        return ( (this.first == null && that.first == null) ||
                (this.first != null && this.first.equals(that.first)) ) &&
                ( (this.second == null && that.second == null) ||
                        (this.second != null && this.second.equals(that.second)) );
    }
    
    @Override
    public String toString() {
        return "<" + first + "," + second + ">";
    }
    
}
