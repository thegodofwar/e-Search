package toolbox.misc.collection.generic;

import java.util.Arrays;

/**
 * The StaticSet with long elements. See javadoc of StaticSet for more details.
 * 
 * @see toolbox.misc.collection.StaticSet
 * 
 * @author david
 *
 */
public class StaticLongSet {
    private static final int STATUS_READY  = 0;
    private static final int STATUS_SORTED = 1;
    private int status = STATUS_READY;
    
    public StaticLongSet() {
        reset();
    }
    
    private LongArrayList keys = new LongArrayList();
    
    private long[] keyList;
    /**
     * Adds a new key to the set. 
     *
     * @param key  the new key instance
     * @throws UnsupportedOperationException  if the set has been sorted.
     */
    public void add(long key) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        keys.add(key);
    }

    /**
     * Sorts the pairs. After calling this method, add()/addAll() can not be 
     * called unless this set is reset().
     */
    public void sort() {
        long[] keysArr = (long[]) keys.getArray();
        Arrays.sort(keysArr, 0, keys.size());
        int keyCount = 0;
        long lastKey = 0L;
        for (int i = 0; i < keys.size(); i ++) {
            long key = keys.get(i);
            if (i == 0 || key != lastKey) {
                /*
                 * A new key
                 */
                keyCount ++;
                lastKey = key;
            } // if
        } // for i
        keyList = new long[keyCount];
        
        keyCount = 0;
        for (int i = 0; i < keys.size(); i ++) {
            long key = keys.get(i);
            if (i == 0 || key != lastKey) {
                /*
                 * A new key
                 */
                keyList[keyCount] = key;
                keyCount ++;
                lastKey = key;
            } // if
        } // for i
        
        status = STATUS_SORTED;
        keys = null;
    }
    
    /**
     * Returns the number of keys in this set.
     *
     * @return the number of keys in this set.
     */
    public int size() {
        return keyList.length;
    }
    /**
     * Returns <tt>true</tt> if this set contains no keys.
     *
     * @return <tt>true</tt> if this set contains no keys.
     */
    public boolean isEmpty() {
        return size() == 0;
    }
    /**
     * Returns <tt>true</tt> if this set contains the specified element.  More
     * formally, returns <tt>true</tt> if and only if this set contains an
     * element <code>e</code> such that <code>(o==null ? e==null :
     * o.equals(e))</code>.
     * 
     * @param key  element whose presence in this set is to be tested.
     * @return <tt>true</tt> if this set contains the specified element.
     * @throws UnsupportedOperationException  if the set has not been sorted.
     */
    public boolean contains(long key) {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        return Arrays.binarySearch(keyList, key) >= 0;
    }
    
    /**
     * Resets the status of this map.
     */
    public void reset() {
        keys = new LongArrayList();
        status = STATUS_READY;
    }
}
