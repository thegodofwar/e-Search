package toolbox.misc.collection;

import java.util.HashSet;

public class HashSetMap<K, V> extends
        HashCollectionMap<K, V, HashSet<V>> {
    private static final long serialVersionUID = -6955924494985752255L;
    public HashSetMap() {
        super((Class) HashSet.class);
    }

}
