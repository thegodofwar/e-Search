package toolbox.misc.collection;

/**
 * An unbounded priority {@linkplain Queue queue} based on a priority
 * heap.  This queue orders elements according to an order specified
 * at construction time, which is specified either according to their
 * <i>natural order</i> (see {@link Comparable}), or according to a
 * {@link java.util.Comparator}, depending on which constructor is
 * used. A priority queue does not permit <tt>null</tt> elements.
 * A priority queue relying on natural ordering also does not
 * permit insertion of non-comparable objects (doing so may result
 * in <tt>ClassCastException</tt>). 
 *
 * <p>The <em>head</em> of this queue is the <em>least</em> element
 * with respect to the specified ordering.  If multiple elements are
 * tied for least value, the head is one of those elements -- ties are
 * broken arbitrarily.  The queue retrieval operations <tt>poll</tt>,
 * <tt>remove</tt>, <tt>peek</tt>, and <tt>element</tt> access the
 * element at the head of the queue.
 *
 * <p>A priority queue is unbounded, but has an internal
 * <i>capacity</i> governing the size of an array used to store the
 * elements on the queue.  It is always at least as large as the queue
 * size.  As elements are added to a priority queue, its capacity
 * grows automatically.  The details of the growth policy are not
 * specified.
 *
 * <p> <strong>Note that this implementation is not synchronized.</strong>
 * Multiple threads should not access a <tt>PriorityQueue</tt>
 * instance concurrently if any of the threads modifies the list
 * structurally. Instead, use the thread-safe {@link
 * java.util.concurrent.PriorityBlockingQueue} class.
 *
 * 
 * <p>Implementation note: this implementation provides O(log(n)) time
 * for the insertion methods (<tt>offer</tt>, <tt>poll</tt>,
 * <tt>remove()</tt> and <tt>add</tt>) methods; linear time for the
 * <tt>remove(Object)</tt> and <tt>contains(Object)</tt> methods; and
 * constant time for the retrieval methods (<tt>peek</tt>,
 * <tt>element</tt>, and <tt>size</tt>).
 *
 * <p>This class is a member of the
 * <a href="{@docRoot}/../guide/collections/index.html">
 * Java Collections Framework</a>.
 * @since 1.5
 * @version 1.6, 06/11/04
 * @author Josh Bloch, David
 * @param <E> the type of elements held in this collection
 */
public class IntPriorityQueue {
    private static final int DEFAULT_INITIAL_CAPACITY = 11;

    /**
     * Priority queue represented as a balanced binary heap: the two children
     * of queue[n] are queue[2*n] and queue[2*n + 1].  The priority queue is
     * ordered by comparator, or by the elements' natural ordering, if
     * comparator is null:  For each node n in the heap and each descendant d
     * of n, n <= d.
     *
     * The element with the lowest value is in queue[1], assuming the queue is
     * nonempty.  (A one-based array is used in preference to the traditional
     * zero-based array to simplify parent and child calculations.)
     *
     * queue.length must be >= 2, even if size == 0.
     */
    private transient int[] queue;

    /**
     * The number of elements in the priority queue.
     */
    private int size = 0;
    
    public static interface IntComparator {
        int compare(int o1, int o2);
    }
    
    public static IntComparator INT_COMPARATOR = new IntComparator() {
        public int compare(int o1, int o2) {
            return o1 < o2 ? -1 : o1 > o2 ? 1 : 0;
        }
    };

    /**
     * The comparator, or null if priority queue uses elements'
     * natural ordering.
     */
    private final IntComparator comparator;

    /**
     * The number of times this priority queue has been
     * <i>structurally modified</i>.  See AbstractList for gory details.
     */
    private transient int modCount = 0;

    /**
     * Creates a <tt>PriorityQueue</tt> with the default initial capacity
     * (11) that orders its elements according to their natural
     * ordering (using <tt>Comparable</tt>).
     */
    public IntPriorityQueue() {
        this(DEFAULT_INITIAL_CAPACITY, INT_COMPARATOR);
    }

    /**
     * Creates a <tt>PriorityQueue</tt> with the specified initial capacity
     * that orders its elements according to their natural ordering
     * (using <tt>Comparable</tt>).
     *
     * @param initialCapacity the initial capacity for this priority queue.
     * @throws IllegalArgumentException if <tt>initialCapacity</tt> is less
     * than 1
     */
    public IntPriorityQueue(int initialCapacity) {
        this(initialCapacity, INT_COMPARATOR);
    }

    /**
     * Creates a <tt>PriorityQueue</tt> with the specified initial capacity
     * that orders its elements according to the specified comparator.
     *
     * @param initialCapacity the initial capacity for this priority queue.
     * @param comparator the comparator used to order this priority queue.
     * If <tt>null</tt> then the order depends on the elements' natural
     * ordering.
     * @throws IllegalArgumentException if <tt>initialCapacity</tt> is less
     * than 1
     */
    public IntPriorityQueue(int initialCapacity, 
                         IntComparator comparator) {
        if (initialCapacity < 1)
            throw new IllegalArgumentException();
        this.queue = new int[initialCapacity + 1];
        this.comparator = comparator;
    }

    /**
     * Resize array, if necessary, to be able to hold given index
     */
    private void grow(int index) {
        int newlen = queue.length;
        if (index < newlen) // don't need to grow
            return;
        if (index == Integer.MAX_VALUE)
            throw new OutOfMemoryError();
        while (newlen <= index) {
            if (newlen >= Integer.MAX_VALUE / 2)  // avoid overflow
                newlen = Integer.MAX_VALUE;
            else
                newlen <<= 2;
        }
        int[] newQueue = new int[newlen];
        System.arraycopy(queue, 0, newQueue, 0, queue.length);
        queue = newQueue;
    }
            

    /**
     * Inserts the specified element into this priority queue.
     *
     * @return <tt>true</tt>
     * @throws ClassCastException if the specified element cannot be compared
     * with elements currently in the priority queue according
     * to the priority queue's ordering.
     * @throws NullPointerException if the specified element is <tt>null</tt>.
     */
    public boolean offer(int o) {
        modCount++;
        ++size;

        // Grow backing store if necessary
        if (size >= queue.length) 
            grow(size);

        queue[size] = o;
        fixUp(size);
        return true;
    }

    public int peek() {
        return queue[1];
    }

    // Collection Methods - the first two override to update docs

    /**
     * Adds the specified element to this queue.
     * @return <tt>true</tt> (as per the general contract of
     * <tt>Collection.add</tt>).
     *
     * @throws NullPointerException if the specified element is <tt>null</tt>.
     * @throws ClassCastException if the specified element cannot be compared
     * with elements currently in the priority queue according
     * to the priority queue's ordering.
     */
    public boolean add(int o) {
        return offer(o);
    }

    /**
     * Removes a single instance of the specified element from this
     * queue, if it is present.
     */
    public boolean remove(int o) {
        for (int i = 1; i <= size; i++) {
            if (comparator.compare(queue[i], o) == 0) {
                removeAt(i);
                return true;
            }
        }
        
        return false;
    }

    public int size() {
        return size;
    }

    /**
     * Removes all elements from the priority queue.
     * The queue will be empty after this call returns.
     */
    public void clear() {
        modCount++;

        size = 0;
    }

    public int poll() {
        if (size == 0)
            throw new ArrayIndexOutOfBoundsException(-1);
        modCount++;

        int result = queue[1];
        queue[1] = queue[size];
        size --;
        if (size > 1)
            fixDown(1);

        return result;
    }

    /**
     * Removes and returns the ith element from queue.  (Recall that queue
     * is one-based, so 1 <= i <= size.)
     *
     * Normally this method leaves the elements at positions from 1 up to i-1,
     * inclusive, untouched.  Under these circumstances, it returns null.
     * Occasionally, in order to maintain the heap invariant, it must move
     * the last element of the list to some index in the range [2, i-1],
     * and move the element previously at position (i/2) to position i.
     * Under these circumstances, this method returns the element that was
     * previously at the end of the list and is now at some position between
     * 2 and i-1 inclusive.
     */
    private int removeAt(int i) { 
        assert i > 0 && i <= size;
        modCount++;

        int moved = queue[size];
        queue[i] = moved;
        size --;
        if (i <= size) {
            fixDown(i);
            if (queue[i] == moved) {
                fixUp(i);
                if (queue[i] != moved)
                    return moved;
            }
        }
        throw new ArrayIndexOutOfBoundsException(i);
    }

    /**
     * Establishes the heap invariant (described above) assuming the heap
     * satisfies the invariant except possibly for the leaf-node indexed by k
     * (which may have a nextExecutionTime less than its parent's).
     *
     * This method functions by "promoting" queue[k] up the hierarchy
     * (by swapping it with its parent) repeatedly until queue[k]
     * is greater than or equal to its parent.
     */
    private void fixUp(int k) {
        while (k > 1) {
            int j = k >>> 1;
            if (comparator.compare(queue[j], queue[k]) <= 0)
                break;
            int tmp = queue[j];  queue[j] = queue[k]; queue[k] = tmp;
            k = j;
        } // while
    }

    /**
     * Establishes the heap invariant (described above) in the subtree
     * rooted at k, which is assumed to satisfy the heap invariant except
     * possibly for node k itself (which may be greater than its children).
     *
     * This method functions by "demoting" queue[k] down the hierarchy
     * (by swapping it with its smaller child) repeatedly until queue[k]
     * is less than or equal to its children.
     */
    private void fixDown(int k) {
        int j;
        while ((j = k << 1) <= size && (j > 0)) {
            if (j<size && 
                comparator.compare(queue[j], queue[j+1]) > 0)
                j++; // j indexes smallest kid
            if (comparator.compare(queue[k], queue[j]) <= 0)
                break;
            int tmp = queue[j];  queue[j] = queue[k]; queue[k] = tmp;
            k = j;
        } // while
    }

    /**
     * Returns the comparator used to order this collection, or <tt>null</tt>
     * if this collection is sorted according to its elements natural ordering
     * (using <tt>Comparable</tt>).
     *
     * @return the comparator used to order this collection, or <tt>null</tt>
     * if this collection is sorted according to its elements natural ordering.
     */
    public IntComparator comparator() {
        return comparator;
    }
}
