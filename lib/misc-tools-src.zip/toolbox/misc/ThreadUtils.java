package toolbox.misc;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Utility functions that are used when dealing with threads or executing 
 * in a thread.
 * 
 * Copyright (c) 2006, Outfox Team.
 *
 * Created on Mar 9, 2006
 * @author zf
 */

public class ThreadUtils {

    private static class WorkQueue extends Thread {
        LinkedList<Runnable> q = new LinkedList<Runnable>();

        public void run() {
            while (true) {
                Runnable job;
                synchronized(this) {
                    while (q.isEmpty()) {
                        try {
                            this.wait();
                        } catch (InterruptedException e) {
                        }
                    }
                    job = q.removeFirst();
                }
                try {
                    job.run();
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        }

        synchronized void exec(Runnable job) {
            q.add(job);
            if (q.size() == 1)
                notify();
        }

        WorkQueue() {
            this.setDaemon(true);
            this.setName("Queue runner (ThreadUtils)");
        }
    }
    private static WorkQueue workQueue;
    static {
        workQueue = new WorkQueue(); 
        workQueue.start();
    }

    /**
     * Return immediately and run the job in another thread. All jobs will be 
     * executed in a single thread.
     */
    public static void execLater(Runnable job) {
        workQueue.exec(job);
    }

    /**
     * Get all threads in current JVM
     */
    public static Thread[] getThreadsInCurrentVM() {
        // Find the root thread group
        ThreadGroup root = Thread.currentThread().getThreadGroup().getParent();
        while (root.getParent() != null) {
            root = root.getParent();
        }
        return getThreadsInGroup(root);
    }

    /**
     * Get all thread in a thread group
     * @param group
     */
    public static Thread[] getThreadsInGroup(ThreadGroup group) {

        ArrayList<Thread> all = new ArrayList<Thread>();

        // get the exact number of threads
        int numThreads = group.activeCount();
        Thread[] threads = new Thread[numThreads * 2];
        numThreads = group.enumerate(threads, false);
        while ((numThreads >= threads.length) && (numThreads != 0)) {
            threads = new Thread[numThreads * 2];
            numThreads = group.enumerate(threads, false);
        }
        for (int i = 0; i < numThreads; i++)
            all.add(threads[i]);

        // get the exact number of group 
        int numGroups = group.activeGroupCount();
        ThreadGroup[] groups = new ThreadGroup[numGroups * 2];
        numGroups = group.enumerate(groups, false);
        while ((numGroups >= groups.length) && (numGroups != 0)) {
            groups = new ThreadGroup[numGroups * 2];
            numThreads = group.enumerate(groups, false);
        }

        // get number threads from sub-groups    
        for (int i = 0; i < numGroups; i++) {
            Thread[] t = getThreadsInGroup(groups[i]); // recursive
            for (Thread tt : t)
                all.add(tt);
        }

        return all.toArray(new Thread[all.size()]);
    }
    
}
