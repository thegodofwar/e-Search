package toolbox.misc;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LinkedHashMap with size limit.
 * @author river
 *
 */
public class CacheMap<K, V> extends LinkedHashMap<K, V> {
    private static final long serialVersionUID = 7177261808110411817L;

    private int limit;

    public CacheMap(int limit) {
        this.limit = limit;
    }

    protected  boolean removeEldestEntry(Map.Entry<K,V> eldest)  {
        return (limit > 0 && size() >= limit);
    }

}
