package toolbox.misc.io;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

/**
 * Socket helper class for non-blocking input/output.
 * 
 * FIXME: how to use this?!
 * 
 * @author river
 *
 */
public class NIOSocketHelper {
    private SocketAddress remote;
    private SocketChannel channel;
    private long timeout;
    private boolean closed;
    
    private NIOInputStream in;
    private NIOOutputStream out;
    
    public NIOSocketHelper(String hostname, int port, long timeout) throws IOException {
        this(new InetSocketAddress(hostname, port), timeout);
    }
    
    public NIOSocketHelper(InetSocketAddress addr, long timeout) throws IOException {
        this.remote = addr;
        this.timeout = timeout;
        
        boolean connectSuccess = false;
        channel = SocketChannel.open();
        try {
            channel.configureBlocking(false);

            Selector connSelector = Selector.open();
            try {
                channel.connect(remote);
                channel.register(connSelector, SelectionKey.OP_CONNECT);
                int selected = connSelector.select(timeout);
                if (selected == 0) {
                    throw new SocketTimeoutException("Timeout(" + timeout + "ms) waiting to connect to " + remote);
                } else {
                    if (!channel.finishConnect()) {
                        throw new IOException("connection failed though OP_CONNECT selection key ready.");
                    } else {
                        connectSuccess = true;
                    }
                }
            } finally {
                connSelector.close();
            }
            closed = false;
        } finally {
            if (!connectSuccess) {
                channel.close();
            }
        }
    }
    
    public NIOSocketHelper(SocketChannel socketChannel, int timeout) throws IOException {
        if (socketChannel == null) {
            throw new NullPointerException("socket channel is null");
        }
        
        this.channel = socketChannel;
        this.timeout = timeout;
        this.remote = channel.socket().getRemoteSocketAddress();
        
        if (!this.channel.isConnected()) {
            throw new IOException("socket channel is not connected");
        }
        if (this.channel.isBlocking()) {
            this.channel.configureBlocking(false);
        }
        closed = false;
    }
    
    public Socket getSocket() {
        return channel.socket();
    }
    
    public SocketChannel getChannel() {
        return channel;
    }
    
    public long getTimeout() {
        return timeout;
    }
    
    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }
    
    public SocketAddress getRemoteAddress() {
        return remote;
    }
    
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        if (in != null) {
            in.selector.close();
        }
        
        if (out != null) {
            out.selector.close();
        }
        
        channel.close();
        closed = true;
    }
    
    private void assertOpened() throws IOException {
        if (closed) {
            throw new IOException("socket is closed in previous operation");
        }
    }
    
    public InputStream getInputStream() throws IOException {
        assertOpened();
        if (in == null) {
            in = new NIOInputStream();
        }
        return in;
    }
    
    public OutputStream getOutputStream() throws IOException {
        assertOpened();
        if (out == null) {
            out = new NIOOutputStream();
        }
        return out;
    }
    
    private class NIOInputStream extends InputStream {
        private ByteBuffer buffer;
        private Selector selector;
        
        public NIOInputStream() throws IOException {
            buffer = ByteBuffer.allocate(8192);
            buffer.flip();
            selector = Selector.open();
            channel.register(selector, SelectionKey.OP_READ);
        }
        
        @Override
        public void close() throws IOException {
            NIOSocketHelper.this.close();
            super.close();
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            assertOpened();
            
            // sanity check
            if (off < 0 || off + len > b.length) {
                throw new IOException("bad offset ( offset = " + off + ", len = " + len + ", buffer_size = " + b.length);
            }
            
            if (len == 0) return 0;
            
            int remaining = buffer.remaining();
            
            if (remaining > 0) {
                int leftover = Math.min(remaining, len);
                buffer.get(b, off, leftover);
                return leftover;
            }
     
            int toRead = len;
            int offset = off;
            int bytesCopied = 0;
            
            if(selector.select(timeout) > 0) {
                for (Iterator<SelectionKey> it = selector.selectedKeys().iterator(); it.hasNext(); ) {
                    SelectionKey key = it.next();
                    if(!key.isValid()) {
                        throw new EOFException("Connection from " + remote + " is invalid, maybe the remote socket is closed.");
                    }

                    if (key.isReadable()) {
                        it.remove();

                        buffer.clear();
                        int numBytesRead = channel.read(buffer);
                        buffer.flip();
                        if (numBytesRead == -1) {
                            throw new EOFException("Cannot read from " + remote + ", maybe the remote socket is closed.");
                        }

                        int toCopy = Math.min(toRead, numBytesRead);
                        buffer.get(b, offset, toCopy);
                        bytesCopied = toCopy;
                        break;
                    }
                }
            } else {
                throw new SocketTimeoutException("socket read from " + remote + " timeout(" + timeout + ")");
            }
            return bytesCopied;
        }

        @Override
        public int read(byte[] b) throws IOException {
            return read(b, 0, b.length);
        }

        byte [] singleByte = new byte[1];
        
        @Override
        public int read() throws IOException {
            int rvalue = read(singleByte, 0, 1);
            if (rvalue < 0) {
                return rvalue;
            } else {
                return (singleByte[0] & 0xff);
            }
        }
    }
    
    private class NIOOutputStream extends OutputStream {

        private ByteBuffer buffer;
        private Selector selector;
        
        public NIOOutputStream() throws IOException {
            buffer = null;
            selector = Selector.open();
            channel.register(selector, SelectionKey.OP_WRITE);
        }
        
        @Override
        public void close() throws IOException {
            NIOSocketHelper.this.close();
            super.close();
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            assertOpened();
            
            if (buffer == null || buffer.capacity() < len) {
                buffer = ByteBuffer.allocate(((len+1023)/1024) * 1024);
            }
            
            buffer.clear();
            buffer.put(b, off, len);
            buffer.flip();
            
            while (buffer.hasRemaining()) {
                if (selector.select(timeout)>0) {
                    for (Iterator<SelectionKey> it = selector.selectedKeys().iterator(); it.hasNext(); ) {
                        SelectionKey key = it.next();
                        if (key.isWritable()) {
                            it.remove();
                            channel.write(buffer);
                            break;
                        }
                    }
                } else {
                    throw new SocketTimeoutException("socket output to " + remote + " timeout(" + timeout+ ")");
                }
            }
        }

        @Override
        public void write(byte[] b) throws IOException {
            write(b, 0, b.length);
        }

        private byte [] singleByte = new byte[1];
        
        @Override
        public void write(int b) throws IOException {
            singleByte[0] = (byte)b;
            write(singleByte, 0, 1);
        }
        
    }
    
}
