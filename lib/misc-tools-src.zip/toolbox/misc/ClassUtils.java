package toolbox.misc;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Pattern;

public class ClassUtils {
    

    ////////////////////////////////////////////////////////////////////////////
    // load class and create class instance
    ////////////////////////////////////////////////////////////////////////////

    /**
     * get a class given name and interface class name
     */
    @SuppressWarnings("unchecked")
    public static Class getClass(String className, Class xface) {
        try {
            Class theClass = Class.forName(className);
            if (theClass != null && !xface.isAssignableFrom(theClass))
                throw new RuntimeException(theClass+" is not assignable to "
                        +xface.getName());
            return theClass; // might return null here
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Class " + className + " not found", e);
        }
    }

    /**
     * create a new instance of a class
     * @param theClass the class
     * @return new object instance
     */
    public static Object newInstance(Class theClass) {
        Object result;
        try {
            result = theClass.newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    /**
     * Cast variable v as given class. RuntimeException is thrown when v is null
     * or v cannot be casted to given class.
     * @param <T>
     * @param cls
     * @param v
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T safeCast(Class<? extends T> cls, Object v) {
        if (v == null || !cls.isAssignableFrom(v.getClass()) ) {
            throw new RuntimeException("cannot cast variable " + v + " to class " + cls);
        }
        return (T)v;
    }
    
    /**
     * Find classes in a package under class paths
     * @param packageName
     * @return The list of all the classes inside this package
     * @throws IOException
     */
    public static String[] findClassesInPackage(String packageName,
            List<String> included, List<String> excluded) throws IOException {
        String packageOnly = packageName;
        boolean recursive = false;
        if (packageName.endsWith(".*")) {
            packageOnly = packageName.substring(0, packageName.lastIndexOf(".*"));
            recursive = true;
        }

        List<String> vResult = new ArrayList<String>();
        String packageDirName = packageOnly.replace('.', '/');
        Enumeration<URL> dirs = ClassUtils.class.getClassLoader().getResources(
                packageDirName);
        while (dirs.hasMoreElements()) {
            URL url = dirs.nextElement();
            String protocol = url.getProtocol();
            if ("file".equals(protocol)) {
                findClassesInDirPackage(packageOnly, included, excluded, URLDecoder
                        .decode(url.getFile(), "UTF-8"), recursive, vResult);
            } else if ("jar".equals(protocol)) {
                JarFile jar = ((JarURLConnection) url.openConnection()).getJarFile();
                Enumeration<JarEntry> entries = jar.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (name.charAt(0) == '/') name = name.substring(1);
                    if (name.startsWith(packageDirName)) {
                        int idx = name.indexOf('/', packageDirName.length() + 1);
                        if ((idx == -1) || recursive)
                            //it's not inside a deeper dir
                            if (name.endsWith(".class") && !entry.isDirectory()) {
                                String className = name.substring(packageDirName.length() + 1,
                                        name.length() - 6).replace('/', '.');
                                String pkgName = packageOnly.replace('/', '.');
                                includeOrExcludeClass(url.toString(), pkgName, className, included, excluded,
                                        vResult);
                            }
                    }
                }  // while
            } // else if
        } // while

        String[] result = vResult.toArray(new String[vResult.size()]);
        return result;
    }

    private static String catPackageName(String parent, String name) {
        if (parent.length() > 0) {
            return parent + "." + name;
        } else {
            return name;
        }
    }
    
    private static void findClassesInDirPackage(String packageName,
            List<String> included, List<String> excluded, String packagePath,
            final boolean recursive, List<String> classes) {
        File dir = new File(packagePath);

        if (!dir.exists() || !dir.isDirectory()) return;

        File[] dirfiles = dir.listFiles(new FileFilter() {
            public boolean accept(File file) {
                return (recursive && file.isDirectory())
                || (file.getName().endsWith(".class"));
            }
        });

        for (File file : dirfiles) {
            if (file.isDirectory()) {
                findClassesInDirPackage(catPackageName(packageName, file.getName()), included,
                        excluded, file.getAbsolutePath(), recursive, classes);
            } else {
                String className = file.getName().substring(0,
                        file.getName().length() - 6);
                includeOrExcludeClass(file.getAbsolutePath(), packageName, className, included, excluded,
                        classes);
            }
        }
    }

    private static void includeOrExcludeClass(String from, String packageName,
            String className, List<String> included, List<String> excluded,
            List<String> classes) {
        if (isIncluded(className, included, excluded)) {
        	String fullName = catPackageName(packageName, className);
        	try {
        		Class.forName(fullName);
        	} catch(Throwable e) {
        		System.err.println("bad class def from " + from + " : " + fullName);
        		e.printStackTrace(System.err);
        		return;
        	}
            classes.add(packageName + '.' + className);
        }
    }

    /**
     * @return true if name should be included.
     */
    private static boolean isIncluded(String name, 
            List<String> included, List<String> excluded) {

        boolean result = false;    
        // If no includes nor excludes were specified, return true.
        if (included.size() == 0 && excluded.size() == 0) result = true;
        else {
            boolean isIncluded = find(name, included);
            boolean isExcluded = find(name, excluded);
            if (isIncluded && !isExcluded) result = true;
            else if (isExcluded) result = false;
            else { result = included.size() == 0; }
        }
        return result;
    }

    private static boolean find(String name, List<String> list) {
        for (String regexpStr : list) {
            if (Pattern.matches(regexpStr, name)) return true;
        }
        return false;
    }

    /**
     * Extract a contineous sub array.  The results is a new instance of array, 
     * and values are copied by calling System.arraycopy.
     * 
     * @param <T>  The type of the array.
     * @param arr  the source array
     * @param start  the start index of the sub array
     * @param len  the length of the sub array
     * @return  the copied sub array
     * @deprecated Use {@link ArrayUtils#subArray(T[],int,int)} instead
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] subArray(T[] arr, int start, int len) {
        return ArrayUtils.subArray(arr, start, len);
    }
    /**
     * Convert an object into its text presentation.
     * If the object is an array, Arrays.toString or Arrays.deepToString will
     * be called. Otherwise its toString will be called.
     * 
     * @param o  the object to be converted
     * @return  the converted text
     */
    public static String toString(Object o) {
        if (o != null) {
            Class eClass = o.getClass();
    
            if (eClass.isArray()) {
                if (eClass == byte[].class)
                    return Arrays.toString((byte[]) o);
                else if (eClass == short[].class)
                    return Arrays.toString((short[]) o);
                else if (eClass == int[].class)
                    return Arrays.toString((int[]) o);
                else if (eClass == long[].class)
                    return Arrays.toString((long[]) o);
                else if (eClass == char[].class)
                    return Arrays.toString((char[]) o);
                else if (eClass == float[].class)
                    return Arrays.toString((float[]) o);
                else if (eClass == double[].class)
                    return Arrays.toString((double[]) o);
                else if (eClass == boolean[].class)
                    return Arrays.toString((boolean[]) o);
                else
                    return Arrays.deepToString((Object[]) o);
            } // if
        } // if
        
        return "" + o;
    }
}
