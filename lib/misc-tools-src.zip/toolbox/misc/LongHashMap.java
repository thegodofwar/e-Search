package toolbox.misc;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * More space-efficient hashmap&lt; long,long &gt; implementation.
 * We have not implement the iteration interface.
 * 
 * XXX no java-doc for each method
 * 
 * @author river, David
 * Changed:
 *   1) use an expandSize to reduce the floating multiplication in each put
 *      action.
 *
 */
public class LongHashMap implements Iterable<LongHashMap.Entry> {
    private static final int MAX_CAPACITY = 1 << 30;
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 0.75f;
    
    private Entry [] table;
    private int size;
    private float loadFactor;
    private int expandSize;
    
    public LongHashMap() {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
    }
    
    public LongHashMap(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }
    
    public LongHashMap(int capacity, float loadFactor) {
        int realSize = 1;
        while (realSize < capacity) {
            realSize = realSize << 1;
        }
        if (realSize > MAX_CAPACITY) realSize = MAX_CAPACITY;
        
        table = new Entry[realSize];
        expandSize = (int) (table.length * loadFactor);
        size = 0;
        
        this.loadFactor = loadFactor;
    }
    
    private void resize(int capacity) {
        Entry [] newTable = new Entry[capacity];
        
        for (Entry entry : table) {
            while (entry != null) {
                Entry tmp = entry.next;
                int index = index(entry.key, capacity);
                entry.next = newTable[index];
                newTable[index] = entry;
                entry = tmp;
            }
        }
        
        table = newTable;
        expandSize = (int) (table.length * loadFactor);
    }
    
    /**
     * Calculate the index of a given long key. This code is migrated from 
     * jdk source.
     * @param key
     * @param size
     * @return
     */
    private int index(long key, long size) {
        int h = (int) (key ^ (key >>> 32));
        h += ( h << 9);
        h ^= ( h >>> 14);
        h += ( h << 4);
        h ^= ( h >> 10);
        return (int)(h & (size-1));
    }
    
    public long get(long key, long def) {
        int index = index(key, table.length);
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                return entry.value;
            }
            entry = entry.next;
        }
        return def;
    }
    
    public boolean containsKey(long key) {
        int index = index(key, table.length);
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                return true;
            }
            entry = entry.next;
        }
        return false;
    }
    
    public void put(long key, long value) {
        if (size > expandSize && table.length < MAX_CAPACITY) {
            resize(table.length << 1);
        }
        
        int index = index(key, table.length);
        
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                entry.value = value;
                return;
            }
            entry = entry.next;
        }
        entry = new Entry(key, value);
        entry.next = table[index];
        table[index] = entry;
        size ++;
    }
    
    public void remove(long key) {
        int index = index(key, table.length);
        Entry entry = table[index];
        if (entry != null) {
            if (entry.key == key) {
                table[index] = entry.next;
                size --;
            } else {
                while (entry.next != null)
                    if (entry.next.key == key) {
                        entry.next = entry.next.next;
                        size --;
                        break;
                    } else {
                        entry = entry.next;
                    }
            }
        }
    }
    
    public Iterator<Entry> iterator() {
        return new LongHashIterator();
    }
    
    public int size() {
        return size;
    }
    
    public void clear() {
        for (int i=0; i<table.length; i++) {
            table[i] = null;
        }
        size = 0;
    }
    
    public static class Entry {
        private long key;
        private long value;
        private Entry next;
        
        public Entry(long key, long value) {
            this.key = key;
            this.value = value;
            next = null;
        }
        
        public long getKey() { return key; }
        public long getValue() { return value; }
    }
    
    private class LongHashIterator implements Iterator<Entry> {
        private int index;  // current slot
        private Entry current, next;
        
        public LongHashIterator() {
            Entry[] t = table;
            int i = t.length;
            Entry n = null;
            if (size != 0) { // advance to first entry
                while (i > 0 && (n = t[--i]) == null)
                    ;
            }
            next = n;
            index = i;
        }

        public boolean hasNext() {
            return next != null;
        }
        
        public Entry next() {
            Entry e = next;
            if (e == null) throw new NoSuchElementException();
                
            Entry n = e.next;
            Entry[] t = table;
            int i = index;
            while (n == null && i > 0)
                n = t[--i];
            index = i;
            next = n;
            return current = e;
        }

        public void remove() {
            if (current == null) throw new IllegalStateException();
            long k = current.key;
            current = null;
            LongHashMap.this.remove(k);
        }

    }
    
}
