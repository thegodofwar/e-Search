package toolbox.misc;
/**
 * The interface for a notify event.
 * 
 * @author David
 *
 */
public interface INotifyEvent<T> {
    public void notify(T obj);
}
